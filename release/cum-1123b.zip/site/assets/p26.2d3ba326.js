
/* ===== مدخل الموقع: معلم / معلمة — تتغيّر صيغ المخاطبة في الموقع كله ===== */
(function(){
var GKEY="edu:gender",NKEY="edu:name",VKEY="edu:vid";
function NM(){try{return localStorage.getItem(NKEY)||"";}catch(e){return "";}}
window.EDU_NAME=NM;
function G(){if(window.EDU_G_TMP)return window.EDU_G_TMP;try{return localStorage.getItem(GKEY)||"";}catch(e){return "";}}
window.EDU_G=G;
/* صيغة المذكر ← صيغة المؤنث (للأوامر والمخاطبة فقط، لا يمسّ نصوص القرآن والقصص والإجابات) */
var F=[["يجيب الطالب وحده على جهازه ويحصل على درجته فورًا","تجيب الطالبة وحدها على جهازها وتحصل على درجتها فورًا"],
 ["يمسح الطلاب الباركود بجوالاتهم، ويكتبون أسماءهم، ثم يجيبون معًا في الوقت نفسه","تمسح الطالبات الباركود بجوالاتهن، ويكتبن أسماءهن، ثم يُجبن معًا في الوقت نفسه"],
 ["ويدخل الطلاب بأسمائهم ويجيبون معًا","وتدخل الطالبات بأسمائهن ويُجبن معًا"],["طالب انضمّ","طالبة انضمّت"],
 ["حتى يبدأ المعلم","حتى تبدأ المعلمة"],["حتى يكشف المعلم","حتى تكشف المعلمة"],["لتصل","لتصلي"],["وابدأ","وابدئي"],["واضغط","واضغطي"],["ربحته","ربحتِه"],
 ["مستفيدًا","مستفيدةً"],["معبّرًا","معبّرةً"],["موضحًا","موضحةً"],["مراعيًا","مراعيةً"],["مدلّلًا","مدلّلةً"],
 ["اضغط","اضغطي"],["حاول","حاولي"],["استفد","استفيدي"],["وحدّد","وحدّدي"],["وحدد","وحددي"],["وبيّن","وبيّني"],["ووضّح","ووضّحي"],["واكتب","واكتبي"],["اسحب","اسحبي"],["اقرأ","اقرئي"],["اكتب","اكتبي"],["أكمل","أكملي"],["استنتج","استنتجي"],["استخلص","استخلصي"],["استخرج","استخرجي"],
 ["رتّب","رتّبي"],["رتب","رتبي"],["ضع","ضعي"],["حدّد","حدّدي"],["حدد","حددي"],["علّل","علّلي"],["علل","عللي"],["دلّل","دلّلي"],["دلل","دللي"],["اختر","اختاري"],
 ["صِل","صِلي"],["وظّف","وظّفي"],["وظف","وظفي"],["وضّح","وضّحي"],["بيّن","بيّني"],["كوّن","كوّني"],["ارجع","ارجعي"],["صُغ","صوغي"],["غيّر","غيّري"],
 ["أعِد","أعيدي"],["أعد","أعيدي"],["اتلُ","اتلي"],["أجب","أجيبي"],["ابدأ","ابدئي"],["العب","العبي"],["انتظر","انتظري"],["افتح","افتحي"],["افقع","افقعي"],
 ["قرّر","قرّري"],["أدِر","أديري"],["أدر","أديري"],["ناقش","ناقشي"],["ادرس","ادرسي"],["افهم","افهمي"],["تأكد","تأكدي"],["جرّب","جرّبي"],["فكّر","فكّري"],
 ["أضف","أضيفي"],["أدخل","أدخلي"],["ادخل","ادخلي"],["استخدم","استخدمي"],["راجع","راجعي"],["تابع","تابعي"],["صدّر","صدّري"],["اجمع","اجمعي"],["اعرف","اعرفي"],
 ["صف هذا","صفي هذا"],["أنت","أنتِ"],["معك","معكِ"],["لديك","لديكِ"],["أحسنت","أحسنتِ"],["ربحت","ربحتِ"],["انسحبت","انسحبتِ"],["احتفظت","احتفظتِ"],["أجبت","أجبتِ"],
 ["وصلت","وصلتِ"],["لم تُجب","لم تُجيبي"],["تستطيع","تستطيعين"],["تريد","تريدين"],["زملائك","زميلاتك"],["لمشاركتك","لمشاركتكِ"],
 ["المعلم/ة","المعلمة"],["طالب/ة","طالبة"],["الطالب/ة","الطالبة"],["الطلاب","الطالبات"],["للطلاب","للطالبات"],["طلابًا","طالباتٍ"],["طلاب","طالبات"],["الطالب","الطالبة"],
 ["طالبًا","طالبةً"],["طالب","طالبة"],["المعلم","المعلمة"],["معلم","معلمة"],["فريقك","فريقكِ"]];
var M=[["المعلم/ة","المعلم"],["طالب/ة","طالب"],["الطالب/ة","الطالب"]];
var AL="\\u0621-\\u064A\\u066E-\\u06D3",DI="\\u064B-\\u0652\\u0670";
function rx(w){return new RegExp("(^|[^"+AL+DI+"])("+w.replace(/[\/]/g,"\\/")+")(?!["+AL+DI+"])","g");}
var RF=F.map(function(p){return [rx(p[0]),p[1]];}),RM=M.map(function(p){return [rx(p[0]),p[1]];});
function conv(t){var g=G(),R=g==="f"?RF:RM;if(!g||!/[\u0621-\u064A]/.test(t))return t;R.forEach(function(r){t=t.replace(r[0],function(_,a){return a+r[1];});});return t;}
window.EDU_GTXT=conv;
/* محتوى لا يُغيَّر: الآيات، القصص، الإجابات، الخيارات، أسماء الطلاب، الخرائط والبطاقات */
var SKIP=".sh-txt,.sh-bayt,.sh-exp,.sh-w,.ayah,.para,.q,.qr,.poem,.ra,.ch,.oi span,.mi span,.ml span,.vc,.fc-face,.mm-n,.mg-a,.tg-a,.wh-a,.qz-b,.lv-btn,.lv-o,.tf-a,.bl-in,.cl-card b,.cl-nm,.cl-rank span,.cl-pick h3,.cl-prof h2,.lv-chip,.lv-row span,.lv-p b,.gx-names,.cl-log span,.cl-sel,.el-crumbs,.cb div,.dlg,[data-nog],textarea,input,script,style,svg";
function walk(root){if(!G()||!root)return;if(root.nodeType===3){fix(root);return;}if(root.nodeType!==1||root.closest&&root.closest(SKIP))return;
  var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null),n,list=[];while(n=w.nextNode())list.push(n);list.forEach(fix);}
function fix(n){var p=n.parentElement;if(!p||p.closest(SKIP))return;var v=n.nodeValue,c=conv(v);if(c!==v)n.nodeValue=c;}
window.eduGApply=function(root){walk(root||document.body);};
var mo=new MutationObserver(function(ms){if(!G())return;ms.forEach(function(m){if(m.type==="characterData")fix(m.target);else m.addedNodes.forEach(walk);});});
mo.observe(document.body,{childList:true,subtree:true,characterData:true});
/* شاشة الدخول */
function beep(f){try{var a=window._gctx=window._gctx||new (window.AudioContext||window.webkitAudioContext)(),t=a.currentTime;[f,f*1.25,f*1.5].forEach(function(x,i){var o=a.createOscillator(),g=a.createGain();o.frequency.value=x;
  g.gain.setValueAtTime(.0001,t+i*.09);g.gain.exponentialRampToValueAtTime(.16,t+i*.09+.02);g.gain.exponentialRampToValueAtTime(.0001,t+i*.09+.3);o.connect(g);g.connect(a.destination);o.start(t+i*.09);o.stop(t+i*.09+.35);});}catch(e){}}
function gate(){if(document.getElementById("edu-gate"))return;var d=document.createElement("div");d.id="edu-gate";d.setAttribute("role","dialog");d.setAttribute("aria-label","الدخول إلى الموقع");
  d.innerHTML='<div class="gt-bg"><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="gt-box"><div class="gt-logo">📚</div><h1>أهلًا بك في المكتبة التعليمية</h1><p>اختر الدخول ليُخاطَب طلابك بالصيغة المناسبة في الأسئلة والألعاب والعروض</p>'+
    '<label class="gt-name"><span>✍️ اكتب اسمك</span><input data-nm maxlength="40" autocomplete="name" placeholder="مثال: أ. محمد"></label>'+
    '<label class="gt-name"><span>🏫 اختر الصف</span><select data-gr><option value="">— اختر الصف —</option>'+["","الأول","الثاني","الثالث","الرابع","الخامس","السادس","السابع","الثامن","التاسع","العاشر","الحادي عشر","الثاني عشر"].slice(1).map(function(g,i){return '<option value="'+(i+1)+'">الصف '+g+'</option>';}).join("")+'</select></label><p class="gt-err"></p>'+
    '<div class="gt-opts"><button data-g="m"><span class="gt-em">👨‍🏫</span><b>معلم</b><small>صيغة المذكّر للطلاب</small></button><button data-g="f"><span class="gt-em">👩‍🏫</span><b>معلمة</b><small>صيغة المؤنّث للطالبات</small></button></div>'+
    '<p class="gt-note">يمكنك تغيير الاسم والصف لاحقًا من الشارة أسفل الصفحة</p>'+
    '<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:stretch;justify-content:center;margin-top:12px"><button type="button" data-guest style="flex:1 1 200px;min-height:54px;border:0;border-radius:16px;background:linear-gradient(135deg,#f59e0b,#ea580c);color:#fff;font:800 18px Tajawal,sans-serif;cursor:pointer;box-shadow:0 8px 20px rgba(234,88,12,.35)">🚪 دخول زائر<small style="display:block;font-size:12px;font-weight:700;opacity:.95">بدون تسجيل أو اسم</small></button>'+
    '<a class="gt-acc" style="flex:1 1 260px;margin:0" href="'+(window.PORTAL_URL?PORTAL_URL():"portal/")+'">🔐 لديك حساب؟ <b>دخول المعلمين والطلاب وأولياء الأمور</b> • أو 📲 <b>اشترك عبر تليجرام</b></a></div></div>';
  document.body.appendChild(d);document.documentElement.classList.add("lp-lock");
  var nmI=d.querySelector("[data-nm]"),nmE=d.querySelector(".gt-err"),grI=d.querySelector("[data-gr]");nmI.value=NM();try{grI.value=localStorage.getItem("edu:grade")||"";}catch(e){}
  grI.onchange=function(){grI.parentNode.classList.remove("bad");nmE.textContent="";};setTimeout(function(){try{nmI.focus();}catch(e){}},400);
  nmI.oninput=function(){nmI.parentNode.classList.remove("bad");nmE.textContent="";};
  d.querySelector("[data-guest]").onclick=function(){try{localStorage.setItem(GKEY,"m");localStorage.setItem(NKEY,"زائر");localStorage.setItem("edu:grade",grI.value||"all");}catch(e){}if(location.hash.indexOf("#/")===0)location.hash="";beep(523);
    d.classList.add("out");setTimeout(function(){d.remove();document.documentElement.classList.remove("lp-lock");location.reload();},500);};
  d.querySelectorAll("[data-g]").forEach(function(b){b.onclick=function(){var g=b.getAttribute("data-g"),nm=nmI.value.replace(/\s+/g," ").trim();
    if(nm.length<2){nmI.parentNode.classList.remove("bad");void nmI.offsetWidth;nmI.parentNode.classList.add("bad");nmE.textContent="اكتب اسمك أولًا (حرفان على الأقل).";nmI.focus();return;}
    if(!grI.value){grI.parentNode.classList.remove("bad");void grI.offsetWidth;grI.parentNode.classList.add("bad");nmE.textContent="اختر الصف الذي تريد تصفّحه.";grI.focus();return;}
    try{localStorage.setItem(GKEY,g);localStorage.setItem(NKEY,nm.slice(0,40));localStorage.setItem("edu:grade",grI.value);}catch(e){}if(location.hash.indexOf("#/")===0)location.hash="";beep(g==="f"?660:523);
    b.classList.add("pick");d.classList.add("out");setTimeout(function(){d.remove();document.documentElement.classList.remove("lp-lock");location.reload();},650);};});}
window.EDU_GATE=gate;
/* شارة اسم الزائر: تظهر طوال التصفح، والضغط عليها يغيّر الاسم */
function meChip(){var n=NM();var c=document.getElementById("edu-me");if(!n){if(c)c.remove();return;}
  if(!c){c=document.createElement("button");c.type="button";c.id="edu-me";c.title="تغيير الاسم";c.onclick=function(){gate();};document.body.appendChild(c);}
  var gr="";try{gr=localStorage.getItem("edu:grade")||"";}catch(e){}var GNs=["","الأول","الثاني","الثالث","الرابع","الخامس","السادس","السابع","الثامن","التاسع","العاشر","الحادي عشر","الثاني عشر"];
  var _r=window.STP&&STP.me&&STP.me.role;c.textContent=(_r==="parent"?"👨‍👩‍👧 ":_r==="student"?"🎓 ":_r==="member"?"🙋 ":G()==="f"?"👩‍🏫 ":"👨‍🏫 ")+n+(gr&&GNs[+gr]&&!(window.STP&&STP.me)?" • الصف "+GNs[+gr]:"");}
window.EDU_ME=meChip;window.addEventListener("load",function(){if(window.STP&&STP.ready)STP.ready.then(function(){if(NM())meChip();});});
/* تسجيل الزيارة في البوابة (عدد الزوار وتنبيه المسؤول بالزائر الجديد) */
function vid(){var v="";try{v=localStorage.getItem(VKEY)||"";}catch(e){}if(!/^[a-z0-9]{16,40}$/.test(v)){var a=new Uint8Array(12);(window.crypto||{getRandomValues:function(x){for(var i=0;i<x.length;i++)x[i]=Math.random()*256|0;return x;}}).getRandomValues(a);
  v=Array.prototype.map.call(a,function(b){return ("0"+b.toString(16)).slice(-2);}).join("");try{localStorage.setItem(VKEY,v);}catch(e){}}return v;}
function ping(hb){if(location.protocol.indexOf("http")!==0||!NM()||!window.STP||!STP.ready)return;
  STP.ready.then(function(){var ns=false;try{ns=!sessionStorage.getItem("edu:sess");sessionStorage.setItem("edu:sess","1");}catch(e){}
    return STP.post("visit",{vid:vid(),name:NM(),gender:G()||"m",new_session:ns&&!hb,hb:!!hb});}).catch(function(){});}
window.EDU_PING=ping;
function startVisit(){meChip();ping(false);setInterval(function(){if(!document.hidden)ping(true);},120000);}
var NEEDG=function(){var g="";try{g=localStorage.getItem("edu:grade")||"";}catch(e){}return !g;};
if((!G()||!NM()||NEEDG())&&!/^#live=/.test(location.hash)){gate();
  /* المعلم المسجّل في البوابة: يُؤخذ اسمه وصيغته من حسابه مباشرة دون نافذة الاختيار */
  if(window.STP&&STP.ready)STP.ready.then(function(me){if(!me||!me.name||(G()&&NM()))return;try{localStorage.setItem(GKEY,me.gender==="f"?"f":"m");localStorage.setItem(NKEY,me.name);}catch(e){}
    var d=document.getElementById("edu-gate");if(d){d.remove();document.documentElement.classList.remove("lp-lock");}walk(document.body);startVisit();});
  /* أي حساب مسجّل (معلم، طالب، مشرف، مسؤول) لا يحتاج نافذة الزائر */
  if(window.STP&&STP.ready)STP.ready.then(function(me){if(!me)return;var d=document.getElementById("edu-gate");if(d){d.remove();document.documentElement.classList.remove("lp-lock");}});}
else{walk(document.body);if(!/^#live=/.test(location.hash))startVisit();}
})();
