/* EXP-BEGIN */
/* ===== تحميل «عرض الدرس» بوربوينت (بحركات) و PDF منسق بالإجابات – يُنشأ في المتصفح لكل درس ===== */
window.LEXP=(function(){
var BASE="exp/",AN="٠١٢٣٤٥٦٧٨٩",LET=["أ","ب","ج","د","هـ","و","ز","ح"];
function num(n){return String(n).replace(/[0-9]/g,function(d){return AN[d];});}
function clean(t){return String(t==null?"":t).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,"").replace(/_{3,}/g,"........").replace(/\s+/g," ").trim();}
function xe(s){return String(s==null?"":s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}

/* ---------- ١) قراءة محتوى العرض وتحويله إلى نموذج موحّد ---------- */
function mix(d,key){var SQ=[1,3,0,2,2,0,3,1,3,1,2,0,0,2,1,3],si=key.length;d.forEach(function(sl){if(sl.t!=="mcq"||sl.a!==0||!sl.choices||sl.choices.length<3||sl.big)return;
  var k=SQ[(si++)%SQ.length]%sl.choices.length;if(!k)return;var v=sl.choices.splice(0,1)[0];sl.choices.splice(k,0,v);sl.a=k;});}
function rowsOf(s){var R=[];
  function add(k,t,x){if(k!=="poem"){t=clean(t);if(!t)return null;}var o={k:k,t:t};if(x)for(var i in x)o[i]=x[i];R.push(o);return o;}
  function ay(t){t=clean(t);if(!t)return;add("ayah",/^﴿/.test(t)?t:"﴿ "+t+" ﴾");}
  function poem(p){if(p&&p.length)add("poem","",{s:[clean(p[0]),clean(p[1]||"")]});}
  var U=s.u||null;
  switch(s.t){
  case "info":add("p",s.body,{u:U});(s.ex||[]).forEach(function(e){add("p","• "+e);});break;
  case "text":(s.paras||[]).forEach(function(p){if(p&&typeof p==="object"){if(p.ayah)ay(p.ayah);else if(p.poem)poem(p.poem);else add("p",p.t||p.text||"",{just:1});}else add("p",p,{just:1});});if(s.ayah)ay(s.ayah);break;
  case "list":(s.items||[]).forEach(function(it){add("p","• "+it);});break;
  case "quran":if(s.basmala)add("ayah","بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",{c:1});
    var vs=(s.verses||[]).map(function(v){return clean(v[1])+" ﴿"+num(v[0])+"﴾";});
    for(var i=0;i<vs.length;i+=3)add("ayah",vs.slice(i,i+3).join(" "),{just:1});if(s.ref)add("p",s.ref);break;
  case "abyat":(s.verses||[]).forEach(poem);if(s.ref)add("p",s.ref);break;
  case "vocab":if(s.pairs&&s.pairs.length)R.push({k:"vocab",pairs:s.pairs.map(function(p){return [clean(p[0]),clean(p[1])];})});break;
  case "table":if(s.h)add("p",s.h);(s.head||[]).concat(s.rows||[]).forEach(function(r,ri){var hasA=false,t=r.map(function(c){if(c==null)return "";if(typeof c==="object"){if(c.a!=null){hasA=true;return "«"+c.a+"»";}return c.t||"";}return String(c);}).filter(Boolean).join(" | ");if(t)add(hasA?"a":"p",t);});break;
   case "cols":if(s.stem)add("p",s.stem);if(s.cols&&s.cols.length)R.push({k:"cols",rv:1,cols:s.cols.map(function(c){return {h:clean(c.h),items:(c.items||[]).map(clean)};})});break;
  case "open":
    if(s.qs){if(s.stem)add("p",s.stem);if(s.ayah)ay(s.ayah);poem(s.poem);
      s.qs.forEach(function(x){add("q",x.stem||x.q,{u:x.u||U});if(x.ayah)ay(x.ayah);poem(x.poem);if(x.a)add("a",x.a);if(x.b)add("a",[].concat(x.b).join(" • "));});}
    else{if(s.stem)add(s.q?"p":"q",s.stem,{u:s.q?null:U});if(s.ayah)ay(s.ayah);poem(s.poem);if(s.q)add("q",s.q,{u:U});
      if(s.a)add("a",s.a);if(s.b)add("a",[].concat(s.b).join(" • "));}
    break;
  case "mcq":if(s.stem)add("p",s.stem);if(s.ayah)ay(s.ayah);poem(s.poem);if(s.q)add("q",s.q,{u:U});
    if(s.choices&&s.choices.length){R.push({k:"ch",ch:s.choices.map(clean),a:s.a});
      if(s.a!=null&&s.choices[s.a]!=null)add("a","الإجابة الصحيحة: ("+LET[s.a]+") "+s.choices[s.a]);}
    if(s.why)add("a",s.why);break;
  case "match":if(s.stem)add("p",s.stem);
    R.push({k:"cols",cols:[{h:clean(s.lh||"العمود (أ)"),items:(s.left||[]).map(function(t,i){return "("+num(i+1)+") "+clean(t);})},{h:clean(s.rh||"العمود (ب)"),items:(s.right||[]).map(clean)}]});
    var pr=[];(s.left||[]).forEach(function(t,i){(s.ans||[]).forEach(function(v,j){if(v===i+1)pr.push("("+num(i+1)+") "+clean(t)+" ← "+clean(s.right[j]));});});
    if(pr.length)pr.forEach(function(t){add("a",t);});else if(s.why)add("a",s.why);break;
  case "order":if(s.stem)add("p",s.stem);(s.items||[]).forEach(function(t){add("p","• "+t);});
    if(s.ans&&s.ans.length){var o=(s.items||[]).map(function(t,i){return [s.ans[i],t];}).sort(function(a,b){return a[0]-b[0];});add("a","الترتيب الصحيح: "+o.map(function(x,i){return num(i+1)+"- "+clean(x[1]);}).join("   "));}
    if(s.why)add("a",s.why);break;
  case "diagram":if(s.stem)add("p",s.stem);(s.boxes||[]).forEach(function(b){add("q",b.h);if(b.s)add("p",b.s);if(b.a)add("a",b.a);});break;
  case "letter":add("big",s.l);add("p",s.name,{c:1});if(s.hv)add("p",s.hv.join("    "),{c:1});break;
  case "pics":(s.items||[]).forEach(function(it){add("p",(it[0]||"")+"  "+(it[1]||""));});break;
  }
  return R;}
function fromQD(key){var src=(window.QD_DATA||{})[key];if(!src)return null;var d=JSON.parse(JSON.stringify(src));if(!src.__mixed)mix(d,key);return d;}
function domText(e){var o=[];(function walk(n){[].forEach.call(n.childNodes,function(c){if(c.nodeType===3)o.push(c.nodeValue);else if(c.nodeType===1&&!/^svg$/i.test(c.tagName)){o.push(" ");walk(c);o.push(" ");}});})(e);return clean(o.join(""));}
function fromDom(id){var D=(window.EL_DECKS||{})[id]||document.getElementById(id);if(!D)return null;var out=[];
  [].forEach.call(D.querySelectorAll(".lp-slide"),function(sec){
    function tx(sel){var e=sec.querySelector(sel);return e?domText(e):"";}
    if(sec.classList.contains("s-title")){out.push({t:"title",tag:tx(".tag"),h:tx("h3,h2"),sub:tx(".sub")});return;}
    var rows=[],taken=[];
    [].forEach.call(sec.querySelectorAll("[data-step]"),function(e){if(e.matches(".tag,h2,h3")||e.closest("svg"))return;
      for(var i=0;i<taken.length;i++)if(taken[i].contains(e))return;taken.push(e);var t=domText(e);if(t)rows.push({k:+e.getAttribute("data-step")>0?"a":"p",t:t,dom:1});});
    out.push({t:"_dom",tag:tx(".tag"),h:tx("h3,h2"),rows:rows});});
  return out.length?out:null;}
function model(P,lessonName){var d=P.qd?fromQD(P.qd):P.deck?fromDom(P.deck):null;if(!d||!d.length)return null;
  var t0=d[0].t==="title"?d[0]:null,M={title:clean(t0&&t0.h||P.t||lessonName),sub:clean(t0&&t0.sub||P.meta||""),grade:clean(t0&&t0.tag||""),slides:[]};
  if(M.sub&&M.sub===M.title)M.sub="";
  d.forEach(function(s,i){if(s.t==="title"){if(i)M.slides.push({tag:clean(s.tag),h:clean(s.h),rows:s.sub?[{k:"p",t:clean(s.sub),c:1}]:[]});return;}
    var rows=s.t==="_dom"?s.rows:rowsOf(s);if(!rows.length&&!s.h)return;
    /* بطاقات المفردات الطويلة تُقسم على أكثر من شريحة */
    var vi=-1;rows.forEach(function(r,j){if(r.k==="vocab"&&r.pairs.length>10)vi=j;});
    if(vi>=0){var V=rows[vi].pairs;for(var k=0;k<V.length;k+=10)M.slides.push({tag:clean(s.tag),h:clean(s.h)+(k?" (تابع)":""),rows:[{k:"vocab",pairs:V.slice(k,k+10)}]});return;}
    M.slides.push({tag:clean(s.tag),h:clean(s.h),rows:rows});});
  return M;}

/* ---------- ٢) قياس النص ---------- */
var CV=document.createElement("canvas").getContext("2d");
/* يُقاس نص البوربوينت بخط «تجوّل» (أعرض قليلًا من Sakkal Majalla) ليبقى النص داخل الشريحة دائمًا */
var PFONT="Tajawal,Tahoma,sans-serif";
function wrap(text,size,width,font,weight){CV.font=(weight||700)+" "+size+"px "+(font||window.LEXP_MFONT||PFONT);width*=font?1:.97;
  var words=String(text).split(" "),lines=[],cur="";
  words.forEach(function(w){var t=cur?cur+" "+w:w;if(cur&&CV.measureText(t).width>width){lines.push(cur);cur=w;}else cur=t;});
  if(cur||!lines.length)lines.push(cur);return lines;}

/* ---------- ٣) البوربوينت ---------- */
var E=12700,SW=960,SH=540,LH=1.38,CT=142,CB=528;  /* الوحدات بالنقاط ثم تُحوّل إلى EMU */
var C={red:"C00000",blue:"0070C0",black:"000000",mag:"EC008C",pink:"E4CBC7",org:"F8B26A",pur:"9D65B9",grn:"00704A",poem:"7030A0",grey:"595959"};
function emu(v){return Math.round(v*E);}
function rpr(sz,col,x){x=x||{};return '<a:rPr lang="ar-KW" sz="'+Math.round(sz*100)+'" b="'+(x.b===0?0:1)+'"'+(x.u?' u="sng"':'')+' dirty="0"><a:solidFill><a:srgbClr val="'+col+'"/></a:solidFill><a:latin typeface="Sakkal Majalla" pitchFamily="2" charset="-78"/><a:cs typeface="Sakkal Majalla" pitchFamily="2" charset="-78"/></a:rPr>';}
function runs(t,sz,col,u){if(!u||!u.length)return '<a:r>'+rpr(sz,col)+'<a:t>'+xe(t)+'</a:t></a:r>';
  var parts=[{t:t,u:0}];u.forEach(function(w){w=clean(w);if(!w)return;var np=[];parts.forEach(function(p){if(p.u){np.push(p);return;}var s=p.t.split(w);s.forEach(function(x,i){if(x)np.push({t:x,u:0});if(i<s.length-1)np.push({t:w,u:1});});});parts=np;});
  return parts.map(function(p){return '<a:r>'+rpr(sz,col,{u:p.u})+'<a:t>'+xe(p.t)+'</a:t></a:r>';}).join("");}
function para(t,sz,col,x){x=x||{};var al=x.al||"r";
  return '<a:p><a:pPr algn="'+al+'" rtl="1"><a:lnSpc><a:spcPts val="'+Math.round(sz*(x.lh||LH)*100)+'"/></a:lnSpc><a:spcBef><a:spcPts val="'+(x.bef==null?600:x.bef)+'"/></a:spcBef><a:buNone/></a:pPr>'+runs(t,sz,col,x.u)+'</a:p>';}
function sp(id,name,x,y,w,h,paras,o){o=o||{};var fill=o.fill?'<a:solidFill><a:srgbClr val="'+o.fill+'"/></a:solidFill>':'<a:noFill/>',
  ln=o.ln?'<a:ln w="'+(o.lw||19050)+'"><a:solidFill><a:srgbClr val="'+o.ln+'"/></a:solidFill></a:ln>':'<a:ln><a:noFill/></a:ln>';
  return '<p:sp><p:nvSpPr><p:cNvPr id="'+id+'" name="'+name+' '+id+'"/><p:cNvSpPr'+(o.fill||o.ln?'':' txBox="1"')+'/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="'+emu(x)+'" y="'+emu(y)+'"/><a:ext cx="'+emu(w)+'" cy="'+emu(h)+'"/></a:xfrm><a:prstGeom prst="'+(o.geom||"rect")+'"><a:avLst/></a:prstGeom>'+fill+ln+
    (o.shadow?'<a:effectLst><a:outerShdw blurRad="76200" dist="25400" dir="5400000" algn="t" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="22000"/></a:srgbClr></a:outerShdw></a:effectLst>':'')+'</p:spPr>'+
    '<p:txBody><a:bodyPr wrap="square" lIns="91440" tIns="45720" rIns="91440" bIns="45720" rtlCol="1" anchor="'+(o.anchor||"t")+'"><a:noAutofit/></a:bodyPr><a:lstStyle/>'+(paras||'<a:p><a:endParaRPr lang="ar-KW"/></a:p>')+'</p:txBody></p:sp>';}
function pic(id,rid,x,y,w,h){return '<p:pic><p:nvPicPr><p:cNvPr id="'+id+'" name="صورة '+id+'"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="'+rid+'"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="'+emu(x)+'" y="'+emu(y)+'"/><a:ext cx="'+emu(w)+'" cy="'+emu(h)+'"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>';}
/* الحركات */
function Anim(){this.n=2;this.groups=[];this.bld={};}
Anim.prototype.id=function(){return ++this.n;};
/* mode: "auto" تظهر مع بداية الشريحة، "click" بالنقر، "with" مع آخر حركة نقر */
Anim.prototype.add=function(kind,spid,pr,mode,delay){var G=this.groups,f={k:kind,s:spid,p:pr,d:delay||0};
  if(mode===true)mode="click";if(!mode)mode="auto";
  if(mode==="click")G.push({click:true,fx:[f]});
  else if(mode==="with"&&G.length&&G[G.length-1].click)G[G.length-1].fx.push(f);
  else{if(!G.length||G[0].click)G.unshift({click:false,fx:[]});G[0].fx.push(f);}
  var b=this.bld[spid]||(this.bld[spid]={p:false});if(pr!=null)b.p=true;};
Anim.prototype.xml=function(){var A=this;if(!A.groups.length)return "";
  function tg(f){return '<p:tgtEl><p:spTgt spid="'+f.s+'">'+(f.p!=null?'<p:txEl><p:pRg st="'+f.p+'" end="'+f.p+'"/></p:txEl>':'')+'</p:spTgt></p:tgtEl>';}
  function set(f){return '<p:set><p:cBhvr><p:cTn id="'+A.id()+'" dur="1" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst></p:cTn>'+tg(f)+'<p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst></p:cBhvr><p:to><p:strVal val="visible"/></p:to></p:set>';}
  function an(f,attr,a,b,add){return '<p:anim calcmode="lin" valueType="num"><p:cBhvr'+(add?' additive="base"':'')+'><p:cTn id="'+A.id()+'" dur="500" fill="hold"/>'+tg(f)+'<p:attrNameLst><p:attrName>'+attr+'</p:attrName></p:attrNameLst></p:cBhvr><p:tavLst><p:tav tm="0"><p:val>'+a+'</p:val></p:tav><p:tav tm="100000"><p:val>'+b+'</p:val></p:tav></p:tavLst></p:anim>';}
  function ef(f,flt){return '<p:animEffect transition="in" filter="'+flt+'"><p:cBhvr><p:cTn id="'+A.id()+'" dur="500"/>'+tg(f)+'</p:cBhvr></p:animEffect>';}
  function sv(v){return '<p:strVal val="'+v+'"/>';}
  var P={fade:[10,0],zoom:[23,16],peek:[12,4],wipe:[22,2],fly:[2,4],wheel:[21,1]};
  function one(f,node){var p=P[f.k]||P.fade,id=A.id(),body;
    if(f.k==="zoom")body=set(f)+an(f,"ppt_w",'<p:fltVal val="0"/>',sv("#ppt_w"))+an(f,"ppt_h",'<p:fltVal val="0"/>',sv("#ppt_h"));
    else if(f.k==="peek")body=set(f)+an(f,"ppt_y",sv("#ppt_y+#ppt_h*1.125000"),sv("#ppt_y"),1)+ef(f,"wipe(up)");
    else if(f.k==="wipe")body=set(f)+ef(f,"wipe(left)");
    else if(f.k==="fly")body=set(f)+an(f,"ppt_x",sv("#ppt_x"),sv("#ppt_x"),1)+an(f,"ppt_y",sv("1+#ppt_h/2"),sv("#ppt_y"),1);
    else if(f.k==="wheel")body=set(f)+ef(f,"wheel(1)");
    else body=set(f)+ef(f,"fade");
    return '<p:par><p:cTn id="'+id+'" presetID="'+p[0]+'" presetClass="entr" presetSubtype="'+p[1]+'" fill="hold" grpId="0" nodeType="'+node+'"><p:stCondLst><p:cond delay="'+f.d+'"/></p:stCondLst><p:childTnLst>'+body+'</p:childTnLst></p:cTn></p:par>';}
  var seq=A.groups.map(function(g,gi){var id1=A.id(),id2=A.id(),auto=!g.click&&gi===0;
    var fx=g.fx.map(function(f,i){return one(f,g.click?(i?"withEffect":"clickEffect"):(i?"withEffect":"afterEffect"));}).join("");
    return '<p:par><p:cTn id="'+id1+'" fill="hold"><p:stCondLst><p:cond delay="indefinite"/>'+(auto?'<p:cond evt="onBegin" delay="0"><p:tn val="2"/></p:cond>':'')+'</p:stCondLst><p:childTnLst><p:par><p:cTn id="'+id2+'" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>'+fx+'</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>';}).join("");
  var bl=Object.keys(A.bld).map(function(s){return '<p:bldP spid="'+s+'" grpId="0"'+(A.bld[s].p?' build="p"':' animBg="1"')+'/>';}).join("");
  return '<p:timing><p:tnLst><p:par><p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst><p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>'+seq+
    '</p:childTnLst></p:cTn><p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst><p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst></p:seq></p:childTnLst></p:cTn></p:par></p:tnLst><p:bldLst>'+bl+'</p:bldLst></p:timing>';};
/* شكل كل فقرة */
function rowStyle(r,s){switch(r.k){
  case "h":return {sz:s+2,col:C.black};case "q":return {sz:s,col:C.red};case "a":return {sz:s,col:C.blue};
  case "ayah":return {sz:s+1,col:C.grn,al:r.just&&r.t.length>70?"just":"ctr"};case "big":return {sz:96,col:C.red,al:"ctr"};
  default:return {sz:s,col:C.black,al:r.c?"ctr":r.just?"just":"r"};}}
function rowText(r){return r.k==="poem"?r.s[0]+"   "+r.s[1]:r.t;}
function rowsH(rows,s,w){var h=0;rows.forEach(function(r){if(r.k==="ch"){r.ch.forEach(function(c,i){h+=wrap(LET[i]+") "+c,s,w).length*s*LH+5;});return;}
  var st=rowStyle(r,s);h+=wrap(rowText(r),st.sz,w*(r.k==="poem"?.98:1)).length*st.sz*LH+6;});return h;}
function flatRows(rows){var out=[];rows.forEach(function(r){if(r.k==="ch")r.ch.forEach(function(c,i){out.push({k:"p",t:LET[i]+") "+c});});else out.push(r);});return out;}
function units(rows){var U=[],cur=null;rows.forEach(function(r){if(!cur||r.k==="q"||r.k==="p"||r.k==="h"||r.k==="big"){cur=[];U.push(cur);}cur.push(r);});return U;}
var TR=['<p:fade/>','<p:push dir="l"/>','<p:wipe dir="l"/>','<p:cover dir="l"/>','<p:split orient="vert" dir="out"/>','<p:randomBar dir="vert"/>','<p:fade thruBlk="1"/>','<p:push dir="u"/>'];
var AFX=["wipe","peek","zoom","fly","wipe","fade"];
function header(M,sub,id0){var lines=String(sub||"").split(" • ").filter(Boolean),hs=lines.length>1?22:24;
  var tsz=M.title.length>26?24:M.title.length>16?28:32;
  return sp(id0,"العنوان",620,6,320,84,para(M.title,tsz,C.black,{al:"ctr",bef:0}),{anchor:"ctr"})+
    sp(id0+1,"الدرس",309,2,336,90,lines.map(function(l){return para(l,hs,C.black,{al:"ctr",bef:0,lh:1.15});}).join("")||para(M.title,hs,C.black,{al:"ctr",bef:0}),{fill:C.pink,ln:C.org,lw:9525,geom:"roundRect",anchor:"ctr"})+
    sp(id0+2,"التاريخ",24,6,280,84,para("اليوم:",26,C.black,{bef:0,lh:1.2})+para("التاريخ:",26,C.black,{bef:0,lh:1.2}),{anchor:"ctr"});}
function slideXml(body,anim,tr){return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'+
  body+'</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr><p:transition spd="'+(tr.s||"med")+'">'+tr.x+'</p:transition>'+anim.xml()+'</p:sld>';}
/* بناء الشرائح */
function buildSlides(M){var S=[],ti=0;
  /* شريحة العنوان */
  (function(){var A=new Anim(),L=M.sub.split(" • ").filter(Boolean),b="",y=70,tsz=M.title.length>30?54:M.title.length>18?64:76;
    var th=wrap(M.title,tsz,820).length*tsz*1.3+20;b+=sp(10,"عنوان الدرس",60,y,840,th,para(M.title,tsz,C.black,{al:"ctr",bef:0,lh:1.3}),{anchor:"ctr"});A.add("zoom",10,null,false,0);y+=th+6;
    L.forEach(function(l,i){var sz=i?40:46,h=wrap(l,sz,820).length*sz*1.3+16;b+=sp(11+i,"سطر",60,y,840,h,para(l+(i===0&&L.length>1?":":""),sz,i?C.pur:C.blue,{al:"ctr",bef:0,lh:1.3}),{anchor:"ctr"});A.add(i?"fade":"peek",11+i,null,false,i?0:200);y+=h;});
    if(M.grade){b+=sp(20,"الصف",160,470,640,46,para(M.grade,22,C.grey,{al:"ctr",bef:0}),{anchor:"ctr"});A.add("fade",20,null,false,300);}
    b+=pic(30,"rId3",22,14,96,112);A.add("fade",30,null,false,0);
    S.push({x:slideXml(b,A,{x:'<p:comb/>',s:"slow"}),logo:1});})();
  M.slides.forEach(function(sl,si){
    var sub=M.sub,rows=sl.rows.slice();if(sl.h)rows.unshift({k:"h",t:sl.h});
    var spec=null,si2=-1;rows.forEach(function(r,j){if(!spec&&(r.k==="vocab"||r.k==="cols")){spec=r;si2=j;}});
    var pages=[];
    if(spec){var pre=rows.slice(0,si2),post=rows.slice(si2+1),W=900-16,best=null;
      [30,28,26,24].some(function(s){var hp=pre.length?rowsH(pre,s,W)+8:0,hq=post.length?rowsH(post,s,W)+8:0;best={s:s,hp:hp,hq:hq};return CB-CT-hp-hq>=(spec.k==="vocab"?200:170);});
      if(best.hp>(CB-CT)*.45){paginate(pre);pre=[];best.hp=0;}
      if(CB-CT-best.hp-best.hq>=150)pages.push({s:best.s,pre:pre,spec:spec,post:post,hp:best.hp,hq:best.hq});
      else{pages.push({s:best.s,pre:pre,spec:spec,post:[],hp:best.hp,hq:0});if(post.length)paginate([{k:"h",t:(sl.h||sl.tag||"")+" (تابع)"}].concat(post));}}
    else paginate(rows);
    function paginate(rr){var W=900-16,boxH=CB-CT,fit=null;
      [32,30,28,26,24].some(function(s){if(rowsH(rr,s,W)<=boxH){fit=s;return true;}});
      if(fit){pages.push({s:fit,rows:rr});return;}
      var s=27,U=units(rr),cur=[],h=0;
      /* فقرة أطول من شريحة كاملة تُقسم إلى أجزاء */
      var U2=[];U.forEach(function(u){if(rowsH(u,s,W)<=boxH){U2.push(u);return;}u.forEach(function(r){if(r.k==="ch"||rowsH([r],s,W)<=boxH){U2.push([r]);return;}
        var st=rowStyle(r,s),L=wrap(r.t,st.sz,W),per=Math.max(1,Math.floor((boxH-10)/(st.sz*LH))-1);for(var i=0;i<L.length;i+=per){var o={};for(var k in r)o[k]=r[k];o.t=L.slice(i,i+per).join(" ");U2.push([o]);}});});
      U2.forEach(function(u){var uh=rowsH(u,s,W);if(cur.length&&h+uh>boxH){pages.push({s:s,rows:cur});cur=[{k:"h",t:(sl.h||sl.tag||"")+" (تابع)"}];h=rowsH(cur,s,W);}cur=cur.concat(u);h+=uh;});
      if(cur.length)pages.push({s:s,rows:cur});}
    pages.forEach(function(pg){var A=new Anim(),b=header(M,sub,2),id=10,fxA=AFX[ti%AFX.length];
      if(sl.tag){var tl=sl.tag.length>34?22:26;b+=sp(id,"القسم",470,94,470,46,para(sl.tag+":",tl,C.mag,{bef:0}),{anchor:"ctr"});A.add("fade",id,null,false,0);id++;}
      function box(rr,y,h,s){var P=flatRows(rr),bid=id++,xml=P.map(function(r){var st=rowStyle(r,s);return para(rowText(r),st.sz,st.col,{al:st.al,u:r.u,bef:r.k==="h"?0:600});}).join("");
        b+=sp(bid,"نص",30,y,900,h,xml,{});
        var d=0;P.forEach(function(r,i){if(r.k!=="a"){A.add("fade",bid,i,"auto",d);d=Math.min(d+120,900);}});
        P.forEach(function(r,i){if(r.k==="a")A.add(fxA,bid,i,true);});}
      if(pg.rows)box(pg.rows,CT,CB-CT,pg.s);
      else{var y=CT;if(pg.pre.length){box(pg.pre,y,pg.hp,pg.s);y+=pg.hp;}
        var sh=CB-y-pg.hq;if(pg.spec.k==="vocab")vocab(pg.spec,y,sh);else cols(pg.spec,y,sh);
        if(pg.post.length)box(pg.post,CB-pg.hq,pg.hq,pg.s);}
      function fitSz(texts,w,h,max,min){for(var s=max;s>=min;s-=1){if(texts.every(function(t){return wrap(t,s,w-16).length*s*LH+8<=h;}))return s;}return min;}
      function vocab(v,y,h){var P=v.pairs,n=P.length,bands=n>5?2:1,per=Math.ceil(n/bands),hw=96,gap=8,bw=(900-hw-gap*per)/per,bh=Math.min(200,(h-12*(bands-1))/bands),wh=bh*.4,mh=bh-wh-6;
        var ws=fitSz(P.map(function(p){return p[0];}),bw,wh,30,16),ms=fitSz(P.map(function(p){return p[1];}),bw,mh,28,14),ord=[];
        for(var bi=0;bi<bands;bi++){var yy=y+bi*(bh+12);
          b+=sp(id++,"الكلمة",930-hw,yy,hw,wh,para("الكلمة",22,C.black,{al:"ctr",bef:0}),{fill:C.pink,ln:C.org,lw:9525,geom:"roundRect",anchor:"ctr"});
          b+=sp(id++,"المعنى",930-hw,yy+wh+6,hw,mh,para("المعنى",22,C.black,{al:"ctr",bef:0}),{fill:C.pink,ln:C.org,lw:9525,geom:"roundRect",anchor:"ctr"});
          P.slice(bi*per,bi*per+per).forEach(function(p,j){var x=930-hw-gap-(j+1)*bw-j*gap;
            b+=sp(id,"كلمة",x,yy,bw,wh,para(p[0],ws,C.red,{al:"ctr",bef:0,lh:1.2}),{fill:"FFFFFF",ln:C.pink,lw:12700,geom:"roundRect",anchor:"ctr"});A.add("fade",id,null,false,60*j);id++;
            b+=sp(id,"معنى",x,yy+wh+6,bw,mh,para(p[1],ms,C.blue,{al:"ctr",bef:0,lh:1.2}),{fill:"FFFFFF",ln:C.pink,lw:12700,geom:"roundRect",anchor:"ctr"});ord.push(id);id++;});}
        ord.forEach(function(i){A.add("wipe",i,null,true);});}
      function cols(c,y,h){var n=c.cols.length,gap=12,cw=(900-gap*(n-1))/n,hh=Math.min(54,h*.2),bh=h-hh-6;
        var hs=fitSz(c.cols.map(function(x){return x.h;}),cw,hh,26,14),body=c.cols.map(function(x){return x.items.map(function(t){return (c.rv?"• ":"")+t;});});
        var bs=32;for(;bs>14;bs--){var ok=body.every(function(it){var hh2=8;it.forEach(function(t){hh2+=wrap(t,bs,cw-16).length*bs*LH+5;});return hh2<=bh;});if(ok)break;}
        c.cols.forEach(function(x,j){var xx=930-(j+1)*cw-j*gap,hid=id++,bid=id++;
          b+=sp(hid,"رأس",xx,y,cw,hh,para(x.h,hs,C.black,{al:"ctr",bef:0,lh:1.15}),{fill:C.pink,ln:C.org,lw:9525,geom:"roundRect",anchor:"ctr"});
          b+=sp(bid,"عمود",xx,y+hh+6,cw,bh,body[j].map(function(t){return para(t,bs,c.rv?C.black:C.red,{bef:500});}).join("")||para(" ",bs,C.black),{fill:"FFFFFF",ln:C.pink,lw:12700,geom:"roundRect"});
          if(c.rv){A.add("zoom",hid,null,"click");A.add("fade",bid,null,"with",250);}
          else{A.add("fade",hid,null,false,j*150);A.add("fade",bid,null,false,j*150);}});}
      S.push({x:slideXml(b,A,{x:TR[ti%TR.length]})});ti++;});});
  /* شريحة الختام */
  (function(){var A=new Anim(),b=header(M,"انتهى الدرس",2);
    b+=pic(10,"rId2",180,130,600,294);A.add("zoom",10,null,false,0);
    b+=sp(11,"ختام",180,440,600,70,para("انتهى الدرس، أتمنى لكم وقتًا ممتعًا 🌟",34,C.pur,{al:"ctr",bef:0}),{anchor:"ctr"});A.add("peek",11,null,false,300);
    b+=pic(30,"rId3",24,430,82,96);
    S.push({x:slideXml(b,A,{x:'<p:fade/>',s:"slow"}),end:1,logo:1});})();
  return S;}
/* حزمة zip بسيطة (بدون ضغط) */
var CRC=(function(){var t=[];for(var n=0;n<256;n++){var c=n;for(var k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;})();
function crc(u){var c=0xFFFFFFFF;for(var i=0;i<u.length;i++)c=CRC[(c^u[i])&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0;}
function zip(files){var enc=new TextEncoder(),parts=[],cd=[],off=0;
  function h(n,l){var a=[];for(var i=0;i<l;i++){a.push(n&255);n=Math.floor(n/256);}return a;}
  files.forEach(function(f){var nm=enc.encode(f.n),d=typeof f.d==="string"?enc.encode(f.d):f.d,c=crc(d);
    var lh=[].concat(h(0x04034b50,4),h(20,2),h(0x0800,2),h(0,2),h(0,2),h(0x21,2),h(c,4),h(d.length,4),h(d.length,4),h(nm.length,2),h(0,2));
    parts.push(new Uint8Array(lh),nm,d);
    cd.push(new Uint8Array([].concat(h(0x02014b50,4),h(20,2),h(20,2),h(0x0800,2),h(0,2),h(0,2),h(0x21,2),h(c,4),h(d.length,4),h(d.length,4),h(nm.length,2),h(0,2),h(0,2),h(0,2),h(0,2),h(0,4),h(off,4))),nm);
    off+=lh.length+nm.length+d.length;});
  var cs=cd.reduce(function(a,x){return a+x.length;},0);
  return new Blob(parts.concat(cd,[new Uint8Array([].concat(h(0x06054b50,4),h(0,2),h(0,2),h(files.length,2),h(files.length,2),h(cs,4),h(off,4),h(0,2)))]),{type:"application/vnd.openxmlformats-officedocument.presentationml.presentation"});}
function bin(u){return fetch(u,{cache:"force-cache"}).then(function(r){if(!r.ok)throw new Error(u);return r.arrayBuffer();}).then(function(b){return new Uint8Array(b);});}
var TPL=null;
function pptx(M){return fonts().then(function(){return Promise.all([TPL||fetch(BASE+"pptx-tpl.json").then(function(r){return r.json();}).then(function(j){return TPL=j;}),bin(BASE+"ppt-bg.jpg"),bin(BASE+"ppt-end.png"),Promise.resolve(null)]).then(function(R){
  var T=R[0],S=buildSlides(M),F=[],R0='http://schemas.openxmlformats.org/officeDocument/2006/relationships/',X='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
  function rels(a){return X+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+a.map(function(r){return '<Relationship Id="'+r[0]+'" Type="'+R0+r[1]+'" Target="'+r[2]+'"/>';}).join("")+'</Relationships>';}
  var CTp='application/vnd.openxmlformats-officedocument.presentationml.';
  F.push({n:"[Content_Types].xml",d:X+'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="jpg" ContentType="image/jpeg"/><Default Extension="png" ContentType="image/png"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'+
    '<Override PartName="/ppt/presentation.xml" ContentType="'+CTp+'presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="'+CTp+'slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="'+CTp+'slideLayout+xml"/>'+
    S.map(function(s,i){return '<Override PartName="/ppt/slides/slide'+(i+1)+'.xml" ContentType="'+CTp+'slide+xml"/>';}).join("")+
    '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/><Override PartName="/ppt/presProps.xml" ContentType="'+CTp+'presProps+xml"/><Override PartName="/ppt/viewProps.xml" ContentType="'+CTp+'viewProps+xml"/><Override PartName="/ppt/tableStyles.xml" ContentType="'+CTp+'tableStyles+xml"/>'+
    '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>'});
  F.push({n:"_rels/.rels",d:X+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'+R0+'officeDocument" Target="ppt/presentation.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="'+R0+'extended-properties" Target="docProps/app.xml"/></Relationships>'});
  var now=new Date().toISOString().replace(/\.\d+Z$/,"Z");
  F.push({n:"docProps/core.xml",d:X+'<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>'+xe(M.title)+'</dc:title><dc:creator>المعلم الذكي</dc:creator><cp:lastModifiedBy>المعلم الذكي</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">'+now+'</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">'+now+'</dcterms:modified></cp:coreProperties>'});
  F.push({n:"docProps/app.xml",d:X+'<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Microsoft Office PowerPoint</Application><Slides>'+S.length+'</Slides><PresentationFormat>شاشة عريضة</PresentationFormat></Properties>'});
  F.push({n:"ppt/presentation.xml",d:T.__pres_head+'<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>'+S.map(function(s,i){return '<p:sldId id="'+(256+i)+'" r:id="rId'+(10+i)+'"/>';}).join("")+'</p:sldIdLst>'+T.__pres_tail});
  F.push({n:"ppt/_rels/presentation.xml.rels",d:rels([["rId1","slideMaster","slideMasters/slideMaster1.xml"],["rId2","theme","theme/theme1.xml"],["rId3","presProps","presProps.xml"],["rId4","viewProps","viewProps.xml"],["rId5","tableStyles","tableStyles.xml"]].concat(S.map(function(s,i){return ["rId"+(10+i),"slide","slides/slide"+(i+1)+".xml"];})))});
  Object.keys(T).forEach(function(k){if(k.indexOf("__")!==0)F.push({n:k,d:T[k]});});
  F.push({n:"ppt/media/bg.jpg",d:R[1]},{n:"ppt/media/end.png",d:R[2]});var LG=R[3];if(LG)F.push({n:"ppt/media/logo.png",d:LG});
  S.forEach(function(s){if(s.logo&&!LG)s.x=s.x.replace(/<p:pic><p:nvPicPr><p:cNvPr id="30"[\s\S]*?<\/p:pic>/,"").replace(/<p:par><p:cTn id="\d+" presetID="10"[^>]*><p:stCondLst><p:cond delay="0"\/><\/p:stCondLst><p:childTnLst><p:set><p:cBhvr><p:cTn id="\d+" dur="1" fill="hold"><p:stCondLst><p:cond delay="0"\/><\/p:stCondLst><\/p:cTn><p:tgtEl><p:spTgt spid="30">[\s\S]*?<\/p:par>/,"").replace('<p:bldP spid="30" grpId="0" animBg="1"/>',"");});
  S.forEach(function(s,i){F.push({n:"ppt/slides/slide"+(i+1)+".xml",d:s.x},{n:"ppt/slides/_rels/slide"+(i+1)+".xml.rels",d:rels([["rId1","slideLayout","../slideLayouts/slideLayout1.xml"]].concat(s.end?[["rId2","image","../media/end.png"]]:[]).concat(s.logo&&LG?[["rId3","image","../media/logo.png"]]:[]))});});
  return zip(F);});});}

/* ---------- ٤) ملف PDF منسق بالإجابات (يُرسم صفحة صفحة ثم يُجمع) ---------- */
var PW=1240,PH=1754,MX=92,TOP=96,BOT=120,FT="Tajawal,Tahoma,sans-serif",FA="Amiri,'Traditional Arabic',serif";
function rr(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}
function pwrap(t,sz,w,f,wt){return wrap(t,sz,w,f||FT,wt||700);}
function blocks(M){var B=[],W=PW-2*MX;
  function txt(t,o){o=o||{};var sz0=o.sz||29,L0=pwrap(t,sz0,W-2*(o.pad||0)-(o.inset||0),o.f||FT,o.wt||600);
    if(L0.length>18){for(var q=0;q<L0.length;q+=16)B.push(txt1(L0.slice(q,q+16).join(" "),o));return {h:0,draw:function(){}};}
    return txt1(t,o);}
  function txt1(t,o){var sz=o.sz||29,f=o.f||FT,wt=o.wt||600,pad=o.pad||0,L=pwrap(t,sz,W-2*pad-(o.inset||0),f,wt),lh=sz*(o.lh||1.62);
    return {h:L.length*lh+(o.box?2*pad:0)+(o.mb==null?10:o.mb),draw:function(c,y){var x=PW-MX,yy=y;
      if(o.box){c.fillStyle=o.box;rr(c,MX,y,W,L.length*lh+2*pad,16);c.fill();if(o.bar){c.fillStyle=o.bar;c.fillRect(PW-MX-7,y+8,7,L.length*lh+2*pad-16);}yy+=pad;}
      c.font=wt+" "+sz+"px "+f;c.fillStyle=o.col||"#1f2937";c.direction="rtl";
      L.forEach(function(l,i){var by=yy+i*lh+lh*.72,xr=x-pad-(o.inset||0);
        if(o.c){c.textAlign="center";c.fillText(l,PW/2,by);}else{c.textAlign="right";c.fillText(l,xr,by);
          if(o.u)o.u.forEach(function(w){w=clean(w);var k=l.indexOf(w);if(!w||k<0)return;var a=c.measureText(l.slice(0,k)).width,b=c.measureText(w).width;c.fillRect(xr-a-b,by+8,b,3);});}});}};}
  M.slides.forEach(function(sl,si){
    var head=sl.tag||sl.h;if(head){var tg=clean(sl.tag),hh=clean(sl.h);
      B.push({h:(tg?66:0)+(hh?pwrap(hh,36,W,FT,800).length*54:0)+14,keep:1,draw:function(c,y){c.direction="rtl";
        if(tg){c.font="800 26px "+FT;var tw=Math.min(W,c.measureText(tg).width+48);c.fillStyle="#fce7f3";rr(c,PW-MX-tw,y,tw,50,25);c.fill();c.fillStyle="#be185d";c.textAlign="right";c.fillText(tg,PW-MX-24,y+35);y+=66;}
        if(hh){c.font="800 36px "+FT;c.fillStyle="#111827";c.textAlign="right";pwrap(hh,36,W,FT,800).forEach(function(l,i){c.fillText(l,PW-MX,y+40+i*54);});}}});}
    sl.rows.forEach(function(r){
      switch(r.k){
      case "p":B.push(txt(r.t,{c:r.c,u:r.u}));break;
      case "q":var qb=txt(r.t,{col:"#b91c1c",wt:700,u:r.u});qb.keep=1;B.push(qb);break;
      case "a":B.push(txt(r.t,{col:"#1d4ed8",wt:700,box:"#eff6ff",bar:"#2563eb",pad:16,inset:14,mb:16}));break;
      case "ayah":B.push(txt(r.t,{f:FA,sz:34,wt:700,col:"#065f46",c:!r.just,box:"#ecfdf5",pad:14,lh:1.75,mb:14}));break;
      case "big":B.push({h:190,draw:function(c,y){c.font="800 150px "+FA;c.fillStyle="#b91c1c";c.textAlign="center";c.direction="rtl";c.fillText(r.t,PW/2,y+150);}});break;
      case "poem":(function(){var half=W/2-30,L1=pwrap(r.s[0],32,half,FA,700),L2=pwrap(r.s[1],32,half,FA,700),n=Math.max(L1.length,L2.length),lh=52;
        B.push({h:n*lh+14,draw:function(c,y){c.font="700 32px "+FA;c.fillStyle="#6b21a8";c.textAlign="center";c.direction="rtl";
          L1.forEach(function(l,i){c.fillText(l,PW-MX-half/2,y+38+i*lh);});L2.forEach(function(l,i){c.fillText(l,MX+half/2,y+38+i*lh);});
          c.fillStyle="#d8b4fe";c.fillRect(PW/2-1,y+10,2,n*lh-10);}});})();break;
      case "ch":r.ch.forEach(function(t,i){var ok=i===r.a;var cb=txt(LET[i]+") "+t+(ok?"  ✔":""),{col:ok?"#047857":"#1f2937",wt:ok?800:600,box:ok?"#d1fae5":"#f8fafc",pad:10,mb:8});cb.keep=1;B.push(cb);});break;
      case "vocab":(function(){var P=r.pairs,c1=W*.36,c2=W-c1,rows=P.map(function(p){var a=pwrap(p[0],28,c1-28,FT,800),b=pwrap(p[1],28,c2-28,FT,600);return {a:a,b:b,h:Math.max(a.length,b.length)*44+20};});
        var th=56+rows.reduce(function(s,x){return s+x.h;},0);
        B.push({h:th+16,draw:function(c,y){c.direction="rtl";c.save();rr(c,MX,y,W,th,14);c.clip();c.fillStyle="#E4CBC7";c.fillRect(MX,y,W,56);
          c.font="800 28px "+FT;c.fillStyle="#111827";c.textAlign="center";c.fillText("الكلمة",PW-MX-c1/2,y+38);c.fillText("المعنى",MX+c2/2,y+38);
          var yy=y+56;rows.forEach(function(x,i){c.fillStyle=i%2?"#fff7f5":"#ffffff";c.fillRect(MX,yy,W,x.h);
            c.font="800 28px "+FT;c.fillStyle="#b91c1c";x.a.forEach(function(l,k){c.fillText(l,PW-MX-c1/2,yy+40+k*44);});
            c.font="700 28px "+FT;c.fillStyle="#1d4ed8";x.b.forEach(function(l,k){c.fillText(l,MX+c2/2,yy+40+k*44);});yy+=x.h;});
          c.restore();c.strokeStyle="#F8B26A";c.lineWidth=2;rr(c,MX,y,W,th,14);c.stroke();c.beginPath();c.moveTo(PW-MX-c1,y);c.lineTo(PW-MX-c1,y+th);c.stroke();}});})();break;
      case "cols":(function(){var n=r.cols.length,cw=W/n;
        var H=r.cols.map(function(x){return pwrap(x.h,27,cw-24,FT,800);}),hh=Math.max.apply(null,H.map(function(l){return l.length;}))*40+22;
        var Bd=r.cols.map(function(x){return x.items.map(function(t){return pwrap((r.rv?"• ":"")+t,26,cw-28,FT,600);});}),bh=Math.max.apply(null,Bd.map(function(it){return it.reduce(function(s,l){return s+l.length*40+10;},0);}))+18;
        B.push({h:hh+bh+16,draw:function(c,y){c.direction="rtl";c.save();rr(c,MX,y,W,hh+bh,14);c.clip();c.fillStyle="#E4CBC7";c.fillRect(MX,y,W,hh);c.fillStyle="#fff";c.fillRect(MX,y+hh,W,bh);
          r.cols.forEach(function(x,j){var xr=PW-MX-j*cw;c.font="800 27px "+FT;c.fillStyle="#111827";c.textAlign="center";H[j].forEach(function(l,k){c.fillText(l,xr-cw/2,y+36+k*40);});
            var yy=y+hh+12;c.font="600 26px "+FT;c.fillStyle=r.rv?"#1f2937":"#b91c1c";c.textAlign="right";Bd[j].forEach(function(L){L.forEach(function(l){c.fillText(l,xr-14,yy+30);yy+=40;});yy+=10;});
            if(j){c.fillStyle="#F8B26A";c.fillRect(xr-1,y,2,hh+bh);}});
          c.restore();c.strokeStyle="#F8B26A";c.lineWidth=2;rr(c,MX,y,W,hh+bh,14);c.stroke();}});})();break;
      }});
    B.push({h:26,gap:1,draw:function(c,y){c.fillStyle="#f1d5cf";c.fillRect(MX+W*.3,y+11,W*.4,2);}});});
  return B;}
function pdfPages(M,bg,logo){var B=blocks(M).filter(function(b){return b.h>0;}),pages=[],cur=null,y=0,FULL=PH-BOT-(TOP+70);
  var LW=logo?230*logo.width/logo.height:0,TW0=logo?PW-2*MX-LW-90:PW-2*MX-60,TL=pwrap(M.title,58,TW0,FT,800).slice(0,2),TS=TL.length>1?50:58;TL=pwrap(M.title,TS,TW0,FT,800).slice(0,2);
  var HB=Math.max(logo?270:0,46+TL.length*(TS+12)+(M.sub?50:0)+(M.grade?42:0)+64);
  function np(first){cur={first:first,items:[]};pages.push(cur);y=first?TOP+HB+30:TOP+70;}
  np(true);
  B.forEach(function(b,i){var avail=PH-BOT-y;
    if(b.gap){if(b.h<=avail){cur.items.push({b:b,y:y});y+=b.h;}return;}
    var need=b.h;for(var j=i;B[j].keep&&B[j+1]&&j<i+7;j++){var nh=B[j+1].h;if(need+nh>FULL*.7){need+=Math.min(nh,160);break;}need+=nh;}
    if(need>avail){if(b.h<=FULL)np(false);
      else{if(avail<260)np(false);var off=0;while(off<b.h){var r2=PH-BOT-y,u=Math.min(r2,b.h-off);cur.items.push({b:b,y:y,off:off,clip:u});off+=u;y+=u;if(off<b.h)np(false);}return;}}
    cur.items.push({b:b,y:y});y+=b.h;});
  var host=location.hostname||"";
  return pages.map(function(pg,pi){var cv=document.createElement("canvas");cv.width=PW;cv.height=PH;var c=cv.getContext("2d");
    c.fillStyle="#fff";c.fillRect(0,0,PW,PH);if(bg){c.globalAlpha=.55;c.drawImage(bg,0,0,PW,PH);c.globalAlpha=1;}
    c.fillStyle="rgba(255,255,255,.86)";rr(c,MX-34,TOP-34,PW-2*MX+68,PH-TOP-BOT+70,28);c.fill();
    c.direction="rtl";
    if(pg.first){var hy=TOP-6;c.fillStyle="#E4CBC7";rr(c,MX,hy,PW-2*MX,HB,26);c.fill();c.strokeStyle="#F8B26A";c.lineWidth=3;c.stroke();
      var CX=PW/2;if(logo){var lh2=230,lw2=LW;c.drawImage(logo,PW-MX-24-lw2,hy+(HB-lh2)/2,lw2,lh2);CX=(MX+PW-MX-48-lw2)/2;}
      c.textAlign="center";c.fillStyle="#111";c.font="800 "+TS+"px "+FT;TL.forEach(function(l,i){c.fillText(l,CX,hy+28+TS+i*(TS+12));});
      var yy=hy+28+TS+TL.length*(TS+12)-4;if(M.sub){c.font="800 36px "+FT;c.fillStyle="#0070C0";c.fillText(M.sub,CX,yy+4);yy+=50;}
      if(M.grade){c.font="700 27px "+FT;c.fillStyle="#7e22ce";c.fillText(M.grade,CX,yy+4);}
      c.font="700 24px "+FT;c.fillStyle="#9d174d";c.textAlign="center";c.fillText("✍️ الدرس منسّقًا مع الإجابات النموذجية",CX,hy+HB-20);}
    else{var ox=0;if(logo){var eh=52,ew=eh*logo.width/logo.height;c.drawImage(logo,PW-MX-ew,TOP-30,ew,eh);ox=ew+12;}c.font="700 24px "+FT;c.fillStyle="#6b7280";c.textAlign="right";c.fillText(M.title+(M.sub?" • "+M.sub:""),PW-MX-ox,TOP+12);c.fillStyle="#f1d5cf";c.fillRect(MX,TOP+30,PW-2*MX,3);}
    pg.items.forEach(function(it){c.save();if(it.clip!=null){c.beginPath();c.rect(0,it.y,PW,it.clip);c.clip();c.translate(0,-it.off);}it.b.draw(c,it.y);c.restore();});
    c.font="700 22px "+FT;c.fillStyle="#6b7280";c.textAlign="center";c.fillText("صفحة "+num(pi+1)+" من "+num(pages.length)+(host?"   •   "+host:""),PW/2,PH-62);
    return cv;});}
function jpg(cv){return new Promise(function(res){cv.toBlob(function(b){b.arrayBuffer().then(function(a){res(new Uint8Array(a));});},"image/jpeg",.86);});}
function pdfBlob(imgs,title){var enc=new TextEncoder(),parts=[],len=0,offs=[];
  function w(x){var u=typeof x==="string"?enc.encode(x):x;parts.push(u);len+=u.length;}
  function obj(n,body,stream){offs[n]=len;w(n+" 0 obj\n"+body);if(stream){w("\nstream\n");w(stream);w("\nendstream");}w("\nendobj\n");}
  function u16(s){var h="FEFF";for(var i=0;i<s.length;i++)h+=("000"+s.charCodeAt(i).toString(16)).slice(-4);return "<"+h.toUpperCase()+">";}
  var n=imgs.length,kids=[];for(var i=0;i<n;i++)kids.push((4+i*3)+" 0 R");
  w("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
  obj(1,"<< /Type /Catalog /Pages 2 0 R >>");obj(2,"<< /Type /Pages /Count "+n+" /Kids ["+kids.join(" ")+"] >>");
  obj(3,"<< /Title "+u16(title)+" /Creator "+u16("المعلم الذكي")+" /Producer (smartteacher) >>");
  imgs.forEach(function(im,i){var p=4+i*3,cs="q 595.28 0 0 841.89 0 0 cm /Im0 Do Q";
    obj(p,"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im0 "+(p+2)+" 0 R >> >> /Contents "+(p+1)+" 0 R >>");
    obj(p+1,"<< /Length "+cs.length+" >>",cs);
    obj(p+2,"<< /Type /XObject /Subtype /Image /Width "+PW+" /Height "+PH+" /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length "+im.length+" >>",im);});
  var x=len,tot=4+n*3;w("xref\n0 "+tot+"\n0000000000 65535 f \n");for(var k=1;k<tot;k++)w(("000000000"+offs[k]).slice(-10)+" 00000 n \n");
  w("trailer\n<< /Size "+tot+" /Root 1 0 R /Info 3 0 R >>\nstartxref\n"+x+"\n%%EOF");
  return new Blob(parts,{type:"application/pdf"});}
function img(u){return new Promise(function(res){var i=new Image();i.onload=function(){res(i);};i.onerror=function(){res(null);};i.src=u;});}
function fonts(){if(!document.fonts||!document.fonts.load)return Promise.resolve();
  return Promise.race([Promise.all(["600 30px Tajawal","700 30px Tajawal","800 30px Tajawal","700 30px Amiri"].map(function(f){return document.fonts.load(f).catch(function(){});})),new Promise(function(r){setTimeout(r,5000);})]);}
function pdf(M){return Promise.all([fonts(),img(BASE+"ppt-bg.jpg")]).then(function(R){var cvs=pdfPages(M,R[1],null);
  return cvs.reduce(function(p,cv){return p.then(function(a){return jpg(cv).then(function(j){a.push(j);return a;});});},Promise.resolve([])).then(function(J){return pdfBlob(J,M.title+(M.sub?" – "+M.sub:""));});});}

/* ---------- ٥) الواجهة ---------- */
function toast(msg,busy){var t=document.getElementById("lexp-t");if(!t){t=document.createElement("div");t.id="lexp-t";t.setAttribute("role","status");document.body.appendChild(t);}
  t.innerHTML=(busy?'<i class="lexp-sp"></i>':'')+'<span></span>';t.querySelector("span").textContent=msg;t.className="on";clearTimeout(t._h);if(!busy)t._h=setTimeout(function(){t.className="";},3500);}
function fname(M,ext){return (M.title+(M.sub?" - "+M.sub.replace(/ • /g," - "):"")).replace(/[\\\/:*?"<>|]+/g," ").replace(/\s+/g," ").trim().slice(0,120)+"."+ext;}
function save(blob,name){var u=URL.createObjectURL(blob),a=document.createElement("a");a.href=u;a.download=name;a.rel="noopener";document.body.appendChild(a);a.click();
  setTimeout(function(){a.remove();URL.revokeObjectURL(u);},60000);}
var busy=false;
function run(kind,P,lessonName){if(busy)return;var M=model(P,lessonName);if(!M)return alert("لا يوجد عرض لهذا الدرس بعد.");busy=true;
  toast(kind==="ppt"?"⏳ جارٍ تجهيز ملف البوربوينت بالحركات…":"⏳ جارٍ تجهيز ملف PDF منسّق بالإجابات…",true);
  setTimeout(function(){(kind==="ppt"?pptx(M):pdf(M)).then(function(b){save(b,fname(M,kind==="ppt"?"pptx":"pdf"));toast("✔ تم تجهيز الملف وبدأ التحميل");})
    .catch(function(e){console.warn("lexp",e);toast("تعذّر تجهيز الملف، حاول مرة أخرى");}).then(function(){busy=false;});},30);}
return {ppt:function(P,n){run("ppt",P,n);},pdf:function(P,n){run("pdf",P,n);},model:model,_pptx:pptx,_pdf:pdf,_pages:pdfPages};
})();
/* EXP-END */