/* UI4-BEGIN */
/* ===== UI4: شريط الألعاب السينمائي + التشكيل في اللغة العربية ===== */
(function(){
/* ---------- قسم الألعاب: شريط سينمائي يُسحب يمينًا ويسارًا ---------- */
window.GHCINE=function(el){var list=el.querySelector(".gh-list");if(!list)return;
  var cards=[].slice.call(list.querySelectorAll(".gh-card"));if(!cards.length)return;
  var stage=document.createElement("div");stage.className="gc-stage";
  stage.innerHTML='<div class="gc-film top"></div><button type="button" class="gc-arw next" aria-label="اللعبة التالية">‹</button><div class="gc-track" tabindex="0"></div><button type="button" class="gc-arw prev" aria-label="اللعبة السابقة">›</button><div class="gc-film bot"></div>';
  var track=stage.querySelector(".gc-track");
  cards.forEach(function(c,i){c.classList.add("gc-card");c.style.setProperty("--i",i);var ic=c.querySelector(".gh-ic");
    if(ic){var cs=ic.getAttribute("style")||"";var m=cs.match(/--c1:\s*([^;]+)/),m2=cs.match(/--c2:\s*([^;]+)/);if(m)c.style.setProperty("--a",m[1]);if(m2)c.style.setProperty("--b",m2[1]);}
    if(c.classList.contains("gh-mk")){c.style.setProperty("--a","#14b8a6");c.style.setProperty("--b","#0f6b5f");}
    var no=document.createElement("span");no.className="gc-no";no.textContent=String(i+1).replace(/\d/g,function(d){return "٠١٢٣٤٥٦٧٨٩"[d];});c.insertBefore(no,c.firstChild);
    track.appendChild(c);});
  var dots=document.createElement("div");dots.className="gc-dots";dots.innerHTML=cards.map(function(c,i){return '<button type="button" aria-label="'+(i+1)+'" data-i="'+i+'"></button>';}).join("");
  var hint=document.createElement("p");hint.className="gc-hint";hint.textContent="اسحب الشريط يمينًا ويسارًا لاختيار اللعبة، ثم اضغط عليها";
  list.innerHTML="";list.classList.add("gc-on");list.appendChild(stage);list.appendChild(dots);list.appendChild(hint);
  var cur=0;
  function center(i,smooth){i=Math.max(0,Math.min(cards.length-1,i));var c=cards[i],tr=track.getBoundingClientRect(),r=c.getBoundingClientRect();
    track.scrollBy({left:(r.left+r.width/2)-(tr.left+tr.width/2),behavior:smooth===false?"auto":"smooth"});}
  function mark(){var tr=track.getBoundingClientRect(),mid=tr.left+tr.width/2,best=0,bd=1e9;
    cards.forEach(function(c,i){var r=c.getBoundingClientRect(),d=Math.abs(r.left+r.width/2-mid);if(d<bd){bd=d;best=i;}
      var k=Math.min(1,Math.abs(r.left+r.width/2-mid)/(r.width*1.1));c.style.setProperty("--k",k.toFixed(3));});
    if(best!==cur||!cards[cur].classList.contains("act")){cards.forEach(function(c,i){c.classList.toggle("act",i===best);});cur=best;
      dots.querySelectorAll("button").forEach(function(d,i){d.classList.toggle("on",i===best);});}}
  var raf=0;track.addEventListener("scroll",function(){if(!raf)raf=requestAnimationFrame(function(){raf=0;mark();});},{passive:true});
  /* سحب بالفأرة (اللمس يعمل تلقائيًا) */
  var dg=null,moved=false;
  track.addEventListener("pointerdown",function(e){if(e.pointerType!=="mouse"||e.button!==0)return;dg={x:e.clientX,s:track.scrollLeft};moved=false;});
  window.addEventListener("pointermove",function(e){if(!dg)return;var dx=e.clientX-dg.x;if(Math.abs(dx)>6){moved=true;track.classList.add("drag");}if(moved)track.scrollLeft=dg.s-dx;});
  window.addEventListener("pointerup",function(){if(!dg)return;dg=null;track.classList.remove("drag");if(moved){var i=cur;setTimeout(function(){center(i);},10);}});
  /* الضغط على بطاقة جانبية يجعلها في المنتصف، والضغط على البطاقة الوسطى يفتح اللعبة */
  track.addEventListener("click",function(e){var c=e.target.closest(".gc-card");if(moved){e.stopPropagation();e.preventDefault();moved=false;return;}
    if(!c)return;var i=cards.indexOf(c);if(i!==cur){e.stopPropagation();e.preventDefault();center(i);}},true);
  stage.querySelector(".next").onclick=function(){center(cur+1);};stage.querySelector(".prev").onclick=function(){center(cur-1);};
  dots.onclick=function(e){var d=e.target.closest("[data-i]");if(d)center(+d.getAttribute("data-i"));};
  el.addEventListener("keydown",function(e){if(e.target.tagName==="INPUT")return;if(e.key==="ArrowLeft"){e.preventDefault();center(cur+1);}else if(e.key==="ArrowRight"){e.preventDefault();center(cur-1);}
    else if(e.key==="Enter"&&document.activeElement===track){cards[cur].click();}});
  track.addEventListener("wheel",function(e){if(Math.abs(e.deltaY)>Math.abs(e.deltaX)){e.preventDefault();track.scrollBy({left:-e.deltaY,behavior:"auto"});}},{passive:false});
  var first=cards.findIndex(function(c){return !c.classList.contains("off")&&!c.classList.contains("gh-more");});
  var f0=Math.max(0,first);requestAnimationFrame(function(){center(f0,false);mark();track.focus({preventScroll:true});});setTimeout(function(){center(f0,false);mark();},420);
  window.addEventListener("resize",function(){if(document.body.contains(el)){center(cur,false);mark();}});
};

/* ---------- إظهار التشكيل وإخفاؤه في مادة اللغة العربية ---------- */
var K="ar:tsk",OFF=false;try{OFF=localStorage.getItem(K)==="0";}catch(e){}
var RE=/[ً-ْٰ]/,REG=/[ً-ْٰ]/g,ORIG=new Map(),busy=false,obs=null,on=false;
var SKIP=".qr,.q,.ayah,.sh-g.quran,.sh-txt,.vn,.bs,.qd-fig,script,style,textarea,input,select,[contenteditable],.no-tsk,.tsk-pill";
var ROOTS="#qd,#sh,#edu-lib";
function isAr(){return /^#\/arabic(\/|$)/.test(location.hash);}
function strip(node){var w=document.createTreeWalker(node,NodeFilter.SHOW_TEXT,null),t,L=[];while((t=w.nextNode()))L.push(t);
  busy=true;L.forEach(function(t){var v=t.nodeValue;if(!RE.test(v))return;var p=t.parentElement;if(!p||p.closest(SKIP))return;ORIG.set(t,v);t.nodeValue=v.replace(REG,"");});busy=false;}
function restore(){busy=true;ORIG.forEach(function(v,t){if(t.isConnected)t.nodeValue=v;});ORIG.clear();busy=false;}
function inRoot(n){var e=n.nodeType===1?n:n.parentElement;return !!(e&&e.closest&&e.closest(ROOTS));}
function sync(){var want=OFF&&isAr();
  if(want){document.querySelectorAll(ROOTS).forEach(strip);
    if(!obs){obs=new MutationObserver(function(rs){if(busy)return;rs.forEach(function(r){
      if(r.type==="characterData"){ORIG.delete(r.target);if(inRoot(r.target))strip(r.target.parentNode||r.target);}
      else r.addedNodes.forEach(function(n){if(n.nodeType===3||n.nodeType===1){if(inRoot(n)||(n.nodeType===1&&n.matches&&n.matches(ROOTS)))strip(n.nodeType===3?n.parentNode:n);}});});});
      obs.observe(document.body,{childList:true,subtree:true,characterData:true});}}
  else{if(obs){obs.disconnect();obs=null;}restore();}
  on=want;document.documentElement.classList.toggle("tsk-off",want);pill();}
function pill(){document.querySelectorAll("[data-tsk]").forEach(function(b){b.classList.toggle("on",OFF);var t=b.querySelector("span");if(t)t.textContent=OFF?"إظهار التشكيل":"إخفاء التشكيل";});
  document.querySelectorAll('[data-a="tsk"],[data-d2="tsk"]').forEach(function(b){b.classList.toggle("on",OFF);});}
window.TSK={toggle:function(){OFF=!OFF;try{localStorage.setItem(K,OFF?"0":"1");}catch(e){}sync();},off:function(){return OFF;},sync:sync,label:pill};
window.addEventListener("hashchange",function(){setTimeout(sync,30);});
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",sync);else setTimeout(sync,0);
})();
/* ===== المهارات النحوية في عرض الدرس (اللغة العربية) ===== */
(function(){
var SK=[
{id:"ish",t:"أسماء الإشارة",ic:"👉",intro:"أسماءٌ مبنيّةٌ يُشار بها إلى شخصٍ أو شيءٍ أو مكانٍ، وتختلف بحسب القُرب والبُعد والعدد والنوع.",
 g:[{h:"أسماء الإشارة للقريب",c:["المُشار إليه","اسم الإشارة","مثال"],q:[1,2],r:[
  ["المفرد المذكّر","هذا – ذا","هذا كتابٌ مفيدٌ."],
  ["المفرد المؤنّث","هذه – هذي – ذي – تي – ذِهْ – تِهْ","هذه حديقةٌ جميلةٌ."],
  ["المثنّى المذكّر","هذانِ (رفعًا) – هذينِ (نصبًا وجرًّا)","هذانِ طالبانِ مجتهدانِ. / كرّمتُ هذينِ الطالبينِ."],
  ["المثنّى المؤنّث","هاتانِ (رفعًا) – هاتينِ (نصبًا وجرًّا)","هاتانِ زهرتانِ. / قطفتُ هاتينِ الزهرتينِ."],
  ["الجمع بنوعيه (المذكّر والمؤنّث)","هؤلاءِ – أُولاءِ","هؤلاءِ أبطالٌ. / هؤلاءِ معلّماتٌ."]]},
 {h:"أسماء الإشارة للبعيد",c:["المُشار إليه","اسم الإشارة","مثال"],q:[1,2],r:[
  ["المفرد المذكّر","ذلكَ – ذاكَ","﴿ذَلِكَ الْكِتَابُ لَا رَيْبَ فِيهِ﴾"],
  ["المفرد المؤنّث","تلكَ – تِيكَ","﴿تِلْكَ الْجَنَّةُ الَّتِي نُورِثُ مِنْ عِبَادِنَا﴾"],
  ["المثنّى المذكّر","ذانِكَ (رفعًا) – ذَيْنِكَ (نصبًا وجرًّا)","﴿فَذَانِكَ بُرْهَانَانِ مِن رَّبِّكَ﴾"],
  ["المثنّى المؤنّث","تانِكَ (رفعًا) – تَيْنِكَ (نصبًا وجرًّا)","تانِكَ مدينتانِ عريقتانِ."],
  ["الجمع بنوعيه","أولئكَ – أُولالِكَ","﴿أُولَئِكَ عَلَى هُدًى مِّن رَّبِّهِمْ﴾"]]},
 {h:"أسماء الإشارة للمكان",c:["المكان","اسم الإشارة","مثال"],q:[1,2],r:[
  ["القريب","هُنا – ها هُنا","اجلسْ هنا."],
  ["البعيد","هُناكَ – هُنالِكَ – ثَمَّ","﴿وَأَزْلَفْنَا ثَمَّ الْآخَرِينَ﴾"]]}],
 note:"«ها» في أوّل اسم الإشارة للتنبيه، و«الكاف» في آخره للخطاب، و«اللام» للبُعد. وأسماء الإشارة كلّها مبنيّة إلّا المثنّى (هذانِ/هذينِ، هاتانِ/هاتينِ) فيُعرب إعراب المثنّى."},
{id:"maws",t:"الأسماء الموصولة",ic:"🔗",intro:"أسماءٌ مبنيّةٌ تحتاج إلى جملةٍ بعدها تُوضّح معناها تُسمّى «صلة الموصول»، وفيها ضميرٌ يعود على الاسم الموصول. وجملة الصلة لا محلّ لها من الإعراب.",
 g:[{h:"الأسماء الموصولة الخاصّة",c:["الاسم الموصول","يُستعمل لـ","مثال"],q:[0,2],r:[
  ["الذي","المفرد المذكّر","فاز الطالبُ الذي اجتهد."],
  ["التي","المفرد المؤنّث","نجحت الطالبةُ التي ثابرت."],
  ["اللذانِ (رفعًا) – اللذَيْنِ (نصبًا وجرًّا)","المثنّى المذكّر","جاء اللذانِ فازا. / كرّمتُ اللذَيْنِ فازا."],
  ["اللتانِ (رفعًا) – اللتَيْنِ (نصبًا وجرًّا)","المثنّى المؤنّث","حضرت اللتانِ تفوّقتا."],
  ["الذينَ – الأُلى","جمع المذكّر","﴿قَدْ أَفْلَحَ الْمُؤْمِنُونَ ۝ الَّذِينَ هُمْ فِي صَلَاتِهِمْ خَاشِعُونَ﴾"],
  ["اللاتي – اللائي – اللواتي","جمع المؤنّث","أقبلت الأمّهاتُ اللاتي ربّينَ أبناءهنّ."]]},
 {h:"الأسماء الموصولة المشتركة (تصلح للمفرد والمثنّى والجمع بنوعيه)",c:["الاسم الموصول","يُستعمل لـ","مثال"],q:[0,2],r:[
  ["مَنْ","العاقل غالبًا","أحبُّ مَنْ يصدُقُ."],
  ["ما","غير العاقل غالبًا","﴿مَا عِندَكُمْ يَنفَدُ وَمَا عِندَ اللَّهِ بَاقٍ﴾"],
  ["أيّ","العاقل وغير العاقل (بحسب ما يُضاف إليه)","سأكرّمُ أيَّهم أجاب."],
  ["ذا","بعد «ما» أو «مَن» الاستفهاميّتين","ماذا قرأتَ؟ (أي: ما الذي قرأتَه؟)"]]}],
 note:"الأسماء الموصولة كلّها مبنيّة إلّا المثنّى (اللذانِ/اللذَيْنِ، اللتانِ/اللتَيْنِ) فيُعرب إعراب المثنّى، و«أيّ» فهي معربة."},
{id:"dam",t:"الضمائر بأنواعها",ic:"🧑‍🤝‍🧑",intro:"الضمير اسمٌ مبنيٌّ يدلّ على متكلّمٍ أو مخاطَبٍ أو غائبٍ، وهو بارزٌ (منفصل أو متّصل) أو مستتر.",
 g:[{h:"الضمائر المنفصلة",c:["الدلالة","ضمائر الرفع","ضمائر النصب"],q:[1,2],r:[
  ["المتكلّم","أنا – نحنُ","إيّايَ – إيّانا"],
  ["المخاطَب","أنتَ – أنتِ – أنتما – أنتم – أنتنَّ","إيّاكَ – إيّاكِ – إيّاكما – إيّاكم – إيّاكنَّ"],
  ["الغائب","هو – هي – هما – هم – هنَّ","إيّاهُ – إيّاها – إيّاهما – إيّاهم – إيّاهنَّ"]]},
 {h:"الضمائر المتّصلة",c:["الضمير","محلّه الإعرابي","مثال"],q:[1,2],r:[
  ["تاء الفاعل","رفع (فاعل)","كتبتُ الدرسَ."],
  ["ألف الاثنين","رفع (فاعل)","الطالبانِ كتبا الدرسَ."],
  ["واو الجماعة","رفع (فاعل)","الطلّابُ كتبوا الدرسَ."],
  ["نون النسوة","رفع (فاعل)","الطالباتُ كتبْنَ الدرسَ."],
  ["ياء المخاطبة","رفع (فاعل)","أنتِ تكتبينَ الدرسَ."],
  ["نا الدالّة على الفاعلين","رفع / نصب / جرّ","كتبْنا – أكرمَنا المعلّمُ – كتابُنا"],
  ["ياء المتكلّم","نصب / جرّ","أكرمَني المعلّمُ – كتابِي"],
  ["كاف الخطاب","نصب / جرّ","أكرمَكَ المعلّمُ – كتابُكَ"],
  ["هاء الغائب","نصب / جرّ","أكرمَهُ المعلّمُ – كتابُهُ"]]},
 {h:"الضمير المستتر",c:["النوع","تقديره","مثال"],q:[1,2],r:[
  ["مستتر وجوبًا","أنا","أكتبُ الدرسَ."],
  ["مستتر وجوبًا","نحنُ","نكتبُ الدرسَ."],
  ["مستتر وجوبًا","أنتَ (المضارع للمخاطَب والأمر للمفرد)","تكتبُ – اكتبْ الدرسَ."],
  ["مستتر جوازًا","هو / هي (للغائب والغائبة)","الطالبُ يكتبُ – الطالبةُ كتبتْ."]]}],
 note:"الضمائر كلّها مبنيّة، ويكون إعرابها «في محلّ» رفعٍ أو نصبٍ أو جرٍّ بحسب موقعها في الجملة."},
{id:"inna",t:"الحروف الناسخة",ic:"✳️",intro:"«إنَّ وأخواتها» تدخل على الجملة الاسميّة فتنصب المبتدأ ويُسمّى اسمها، وترفع الخبر ويُسمّى خبرها.",
 g:[{h:"إنَّ وأخواتها ومعانيها",c:["الحرف","معناه","مثال"],q:[1,2],r:[
  ["إنَّ","التوكيد","إنَّ العلمَ نورٌ."],
  ["أنَّ","التوكيد","علمتُ أنَّ الصدقَ منجاةٌ."],
  ["كأنَّ","التشبيه","كأنَّ القمرَ مصباحٌ."],
  ["لكنَّ","الاستدراك","الجوُّ حارٌّ لكنَّ النسيمَ عليلٌ."],
  ["ليتَ","التمنّي","ليتَ الشبابَ يعودُ."],
  ["لعلَّ","الترجّي","لعلَّ الفرجَ قريبٌ."],
  ["لا النافية للجنس","نفي الخبر عن جنس اسمها","لا كسولَ ناجحٌ."]]}],
 note:"إذا اتّصلت «ما» الزائدة بإنّ وأخواتها كفّتها عن العمل (إنّما، كأنّما…) إلّا «ليتَما» فيجوز فيها الإعمال والإهمال."},
{id:"kana",t:"الأفعال الناسخة",ic:"🔁",intro:"«كان وأخواتها» تدخل على الجملة الاسميّة فترفع المبتدأ ويُسمّى اسمها، وتنصب الخبر ويُسمّى خبرها.",
 g:[{h:"كان وأخواتها ومعانيها",c:["الفعل","معناه","مثال"],q:[1,2],r:[
  ["كانَ","اتّصاف الاسم بالخبر في الماضي","كان الجوُّ صحوًا."],
  ["أصبحَ","في وقت الصباح","أصبح الطالبُ نشيطًا."],
  ["أضحى","في وقت الضحى","أضحى العاملُ مجتهدًا."],
  ["ظلَّ","طوال النهار","ظلَّ الطفلُ مسرورًا."],
  ["أمسى","في وقت المساء","أمسى المسافرُ متعبًا."],
  ["باتَ","في وقت الليل","بات الحارسُ يقظًا."],
  ["صارَ","التحوّل","صار الماءُ ثلجًا."],
  ["ليسَ","النفي","ليس الكذبُ مفيدًا."],
  ["ما زالَ – ما برِحَ – ما فتِئَ – ما انفكَّ","الاستمرار (بشرط أن يسبقها نفي)","ما زال المطرُ غزيرًا."],
  ["ما دامَ","بيان المدّة (بشرط «ما» المصدريّة الظرفيّة)","﴿وَأَوْصَانِي بِالصَّلَاةِ وَالزَّكَاةِ مَا دُمْتُ حَيًّا﴾"]]},
 {h:"كاد وأخواتها (أفعال المقاربة والرجاء والشروع) – خبرها جملة فعليّة فعلها مضارع",c:["النوع","الأفعال","مثال"],q:[1,2],r:[
  ["المقاربة","كادَ – كرَبَ – أوشكَ","كاد القطارُ يصلُ."],
  ["الرجاء","عسى – حرى – اخلولقَ","عسى الكربُ أن ينفرجَ."],
  ["الشروع","شرعَ – أخذَ – بدأَ – طفِقَ – جعلَ – أنشأَ","أخذ الطالبُ يكتبُ."]]},
 {h:"ظنّ وأخواتها – تنصب مفعولين أصلهما مبتدأ وخبر",c:["النوع","الأفعال","مثال"],q:[1,2],r:[
  ["أفعال اليقين","علِمَ – رأى – وجدَ – ألفى – درى – تعلَّمْ","وجدتُ العلمَ نافعًا."],
  ["أفعال الرجحان","ظنَّ – حسِبَ – خالَ – زعمَ – جعلَ – عدَّ – حجا – هَبْ","ظننتُ الامتحانَ سهلًا."],
  ["أفعال التحويل","صيَّرَ – جعلَ – اتّخذَ – تخِذَ – تركَ – ردَّ – وهبَ","جعلتُ الخشبَ بابًا."]]}],
 note:"الأفعال الناسخة نوعان: تامّة التصرّف (كان، أصبح…)، وناقصة التصرّف (ما زال، ما دام)، وجامدة (ليس)."},
{id:"jarr",t:"حروف الجرّ ومعانيها",ic:"⬇️",intro:"حروف الجرّ تجرّ الاسم الذي بعدها، ولكلّ حرفٍ معنًى أو أكثر يُفهم من سياق الجملة.",
 g:[{h:"حروف الجرّ ومعانيها",c:["الحرف","معناه","مثال"],q:[1,2],r:[
  ["مِنْ","ابتداء الغاية","سافرتُ من الكويتِ."],
  ["مِنْ","التبعيض","أنفقتُ من مالي."],
  ["مِنْ","بيان الجنس","هذا خاتمٌ من ذهبٍ."],
  ["إلى","انتهاء الغاية","سافرتُ إلى مكّةَ."],
  ["عَنْ","المجاوزة","رميتُ السهمَ عن القوسِ."],
  ["على","الاستعلاء","جلستُ على الكرسيِّ."],
  ["في","الظرفيّة (مكانيّة أو زمانيّة)","الماءُ في الكوبِ. / سافرتُ في الصباحِ."],
  ["في","السببيّة","«دخلت امرأةٌ النارَ في هرّةٍ»"],
  ["الباء","الإلصاق","أمسكتُ بالحبلِ."],
  ["الباء","الاستعانة","كتبتُ بالقلمِ."],
  ["الباء","السببيّة","﴿فَكُلًّا أَخَذْنَا بِذَنبِهِ﴾"],
  ["الباء","المصاحبة","خرج الجنودُ بأسلحتِهم."],
  ["اللام","الملك","المالُ لمحمّدٍ."],
  ["اللام","الاستحقاق","﴿الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ﴾"],
  ["اللام","التعليل","جئتُ للعلمِ."],
  ["الكاف","التشبيه","العلمُ كالنورِ."],
  ["حتّى","انتهاء الغاية","﴿سَلَامٌ هِيَ حَتَّى مَطْلَعِ الْفَجْرِ﴾"],
  ["رُبَّ","التقليل أو التكثير","رُبَّ أخٍ لك لم تلدْه أمُّك."],
  ["مُذْ – مُنذُ","ابتداء الغاية في الزمان","ما رأيتُه منذُ يومِ الجمعةِ."],
  ["الواو – التاء","القسم","واللهِ – تاللهِ لأجتهدنَّ."],
  ["خلا – عدا – حاشا","الاستثناء","حضر الطلّابُ عدا خالدٍ."]]}],
 note:"الاسم بعد حرف الجرّ يُعرب «اسمًا مجرورًا»، ويُسمّى الحرف والاسم معًا «شبه جملة» (جارّ ومجرور)."},
{id:"atf",t:"حروف العطف",ic:"➕",intro:"حروف العطف تُشرك ما بعدها (المعطوف) مع ما قبلها (المعطوف عليه) في الإعراب، وهي تسعة أحرف.",
 g:[{h:"حروف العطف ومعانيها",c:["الحرف","معناه","مثال"],q:[1,2],r:[
  ["الواو","مطلق الجمع والاشتراك","جاء محمّدٌ وعليٌّ."],
  ["الفاء","الترتيب والتعقيب","دخل المعلّمُ فالطلّابُ."],
  ["ثُمَّ","الترتيب مع التراخي","زرع الفلّاحُ القمحَ ثمّ حصدَه."],
  ["حتّى","الغاية","أكلتُ السمكةَ حتّى رأسَها."],
  ["أو","التخيير أو الشكّ","خذْ كتابًا أو قصّةً."],
  ["أمْ","طلب التعيين (بعد همزة الاستفهام)","أمحمّدٌ عندك أم عليٌّ؟"],
  ["بلْ","الإضراب","ما جاء محمّدٌ بل عليٌّ."],
  ["لكنْ","الاستدراك (بعد نفيٍ أو نهي)","ما قرأتُ القصّةَ لكنِ المجلّةَ."],
  ["لا","النفي (بعد إثبات)","جاء محمّدٌ لا عليٌّ."]]}],
 note:"المعطوف يتبع المعطوف عليه في الرفع والنصب والجرّ والجزم."},
{id:"nida",t:"أدوات النداء",ic:"📣",intro:"النداء طلبُ الإقبال بحرفٍ من حروف النداء، والاسم بعده يُسمّى «المنادى».",
 g:[{h:"أدوات النداء واستعمالها",c:["الأداة","تُستعمل لـ","مثال"],q:[1,2],r:[
  ["يا","نداء القريب والبعيد (أكثرها استعمالًا)","يا محمّدُ، أقبِلْ."],
  ["الهمزة (أ)","نداء القريب","أمحمّدُ، أقبِلْ."],
  ["أَيْ","نداء القريب","أَيْ بُنيَّ، اجتهدْ."],
  ["أيا – هيا","نداء البعيد","أيا جبلَيْ نعمانَ باللهِ خلِّيا"],
  ["آ – آيْ","نداء البعيد","آيْ أخي، انتظرْني."],
  ["وا","الندبة (نداء المتفجَّع عليه أو المتوجَّع منه)","وا معتصماه!"]]},
 {h:"أنواع المنادى وحكمه",c:["نوع المنادى","حكمه","مثال"],q:[1,2],r:[
  ["العلم المفرد","مبنيّ على ما يُرفع به في محلّ نصب","يا خالدُ – يا محمّدانِ"],
  ["النكرة المقصودة","مبنيّ على ما يُرفع به في محلّ نصب","يا طالبُ، انتبهْ."],
  ["النكرة غير المقصودة","منصوب","يا غافلًا، تنبّهْ."],
  ["المضاف","منصوب","يا طالبَ العلمِ، اجتهدْ."],
  ["الشبيه بالمضاف","منصوب","يا طالعًا جبلًا، تمهّلْ."]]}],
 note:"قد يُحذف حرف النداء، ولا يُحذف إلّا «يا»: ﴿يُوسُفُ أَعْرِضْ عَنْ هَذَا﴾."},
{id:"istf",t:"أدوات الاستفهام",ic:"❓",intro:"الاستفهام طلبُ العلم بشيءٍ لم يكن معلومًا، وأدواته حرفان (الهمزة وهل) والباقي أسماء.",
 g:[{h:"أدوات الاستفهام واستعمالها",c:["الأداة","يُسأل بها عن","مثال"],q:[1,2],r:[
  ["الهمزة (أ)","التصديق (نعم/لا) أو التصوّر (التعيين)","أحضرَ محمّدٌ؟ / أمحمّدٌ حضرَ أم عليٌّ؟"],
  ["هلْ","التصديق فقط (الجواب نعم أو لا)","هل نجحتَ في الامتحانِ؟"],
  ["مَنْ","العاقل","مَن فاز بالسباقِ؟"],
  ["ما – ماذا","غير العاقل أو حقيقة الشيء","ما اسمُك؟ / ماذا قرأتَ؟"],
  ["متى","الزمان","متى تسافرُ؟"],
  ["أينَ","المكان","أين تسكنُ؟"],
  ["كيفَ","الحال","كيف حالُك؟"],
  ["كمْ","العدد","كم كتابًا قرأتَ؟"],
  ["أيّ","يُحدَّد بحسب ما تُضاف إليه","أيُّ كتابٍ قرأتَ؟"],
  ["أنّى","بمعنى: كيف، أو من أين، أو متى","﴿أَنَّىٰ لَكِ هَٰذَا﴾"],
  ["أيّانَ","الزمان المستقبل (في مواضع التفخيم والتهويل)","﴿يَسْأَلُ أَيَّانَ يَوْمُ الْقِيَامَةِ﴾"],
  ["لِمَ – لماذا","السبب","لماذا تأخّرتَ؟"]]}],
 note:"أدوات الاستفهام كلّها مبنيّة إلّا «أيّ» فهي معربة، والهمزة وهل حرفان لا محلّ لهما من الإعراب."}
];
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
function tx(s){return esc(s).replace(/﴿([^﴾]+)﴾/g,'<span class="q">﴿$1﴾</span>');}
window.ARSK={open:function(host,first){var old=host.querySelector(".sk-ov");if(old)old.remove();
  var el=document.createElement("div");el.className="sk-ov";el.setAttribute("role","dialog");el.setAttribute("aria-label","المهارات النحوية");
  el.innerHTML='<div class="sk-top"><button type="button" class="sk-x" aria-label="إغلاق">✕</button><h2>🧩 المهارات النحوية</h2><label class="sk-quiz"><input type="checkbox"> وضع التدريب</label></div>'+
    '<div class="sk-tabs">'+SK.map(function(s,i){return '<button type="button" data-i="'+i+'"><span>'+s.ic+'</span>'+s.t+'</button>';}).join("")+'</div><div class="sk-body"></div>';
  host.appendChild(el);var body=el.querySelector(".sk-body"),quiz=false,cur=0;
  function show(i){cur=i;var s=SK[i];el.querySelectorAll(".sk-tabs button").forEach(function(b,j){b.classList.toggle("on",j===i);if(j===i)b.scrollIntoView({inline:"center",block:"nearest",behavior:"smooth"});});
    body.innerHTML='<h3>'+s.ic+' '+esc(s.t)+'</h3><p class="sk-intro">'+tx(s.intro)+'</p>'+s.g.map(function(g){
      return '<section><h4>'+esc(g.h)+(quiz?'<button type="button" class="sk-all">إظهار الكل</button>':'')+'</h4><div class="sk-tw"><table class="sk-t"><thead><tr>'+g.c.map(function(c){return '<th>'+esc(c)+'</th>';}).join("")+'</tr></thead><tbody>'+
        g.r.map(function(r){return '<tr>'+r.map(function(v,k){var hid=quiz&&g.q.indexOf(k)>-1;
          return '<td'+(k===0?' class="k"':'')+(hid?' data-h>'+'<span>'+tx(v)+'</span>':'>'+tx(v))+'</td>';}).join("")+'</tr>';}).join("")+'</tbody></table></div></section>';}).join("")+
      (s.note?'<p class="sk-note">💡 '+tx(s.note)+'</p>':'');body.scrollTop=0;
    body.querySelectorAll("[data-h]").forEach(function(c){c.onclick=function(){c.classList.toggle("open");};});
    body.querySelectorAll(".sk-all").forEach(function(b){b.onclick=function(){var cs=b.closest("section").querySelectorAll("[data-h]"),any=[].some.call(cs,function(c){return !c.classList.contains("open");});cs.forEach(function(c){c.classList.toggle("open",any);});b.textContent=any?"إخفاء الكل":"إظهار الكل";};});}
  el.querySelector(".sk-tabs").onclick=function(e){var b=e.target.closest("[data-i]");if(b)show(+b.getAttribute("data-i"));};
  el.querySelector(".sk-quiz input").onchange=function(){quiz=this.checked;show(cur);};
  function close(){el.remove();document.removeEventListener("keydown",kd,true);}
  function kd(e){if(e.key==="Escape"){e.stopPropagation();close();}else if(e.key==="ArrowLeft"||e.key==="ArrowRight"||e.key===" "){e.stopPropagation();}}
  document.addEventListener("keydown",kd,true);
  ["click","pointerdown","pointerup","keydown","wheel","touchstart","touchend"].forEach(function(t){el.addEventListener(t,function(e){e.stopPropagation();},{passive:true});});
  el.querySelector(".sk-x").onclick=close;show(first||0);}};
})();
/* UI4-END */