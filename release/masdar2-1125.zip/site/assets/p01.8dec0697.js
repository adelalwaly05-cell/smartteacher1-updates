
(function(){
  var root=document.getElementById("lp-deck"),wrap=root.querySelector(".lp-wrap"),canvas=root.querySelector(".lp-canvas"),
      slides=[].slice.call(root.querySelectorAll(".lp-slide")),bar=document.getElementById("lp-bar"),
      count=document.getElementById("lp-count"),badge=document.getElementById("lp-badge"),idx=0,step=0;

  function frags(s){return [].slice.call(s.querySelectorAll("[data-step]"));}
  function maxStep(s){return frags(s).reduce(function(m,f){return Math.max(m,+f.getAttribute("data-step"));},0);}
  function paint(){
    slides.forEach(function(s,i){frags(s).forEach(function(f){f.classList.toggle("on",i===idx&&+f.getAttribute("data-step")<=step);});});
    count.textContent=(idx+1)+" من "+slides.length;badge.textContent=count.textContent;
    var total=slides.reduce(function(a,s){return a+maxStep(s)+1;},0),done=0;
    for(var i=0;i<idx;i++)done+=maxStep(slides[i])+1;done+=step+1;
    bar.style.width=(done/total*100)+"%";
  }
  function go(n,st,dir){
    var old=slides[idx],nw=slides[n];
    old.classList.remove("active");old.classList.add(dir>0?"leave-fwd":"leave-back");
    setTimeout(function(){old.classList.remove("leave-fwd","leave-back");},700);
    if(dir<0){nw.classList.add("from-back");void nw.offsetWidth;nw.classList.remove("from-back");}
    nw.classList.add("active");idx=n;step=st;
    // عند الرجوع تظهر عناصر الشريحة مباشرة دون حركة
    if(dir<0){frags(nw).forEach(function(f){f.style.transition="none";});paint();void nw.offsetWidth;frags(nw).forEach(function(f){f.style.transition="";});}
    else setTimeout(paint,80);
  }
  function next(){if(step<maxStep(slides[idx])){step++;paint();}else if(idx<slides.length-1)go(idx+1,0,1);}
  function prev(){if(step>0){step--;paint();}else if(idx>0)go(idx-1,maxStep(slides[idx-1]),-1);}

  // يحسب المساحة المتاحة (العرض والارتفاع) ويختار التصميم الأفقي أو الطولي بلا سكرول
  var ctrl=root.querySelector(".lp-ctrl"),lastKey="";
  function nativeFull(){return (document.fullscreenElement||document.webkitFullscreenElement)===root;}
  function isFull(){return nativeFull()||root.classList.contains("lp-full");}
  // يملأ المساحة المتاحة كلها: يتغيّر عرض الشريحة (أفقي) أو طولها (طولي) حسب الشاشة
  function fit(){
    var fs=isFull(),cs=getComputedStyle(root),vv=window.visualViewport,
        padX=parseFloat(cs.paddingLeft)+parseFloat(cs.paddingRight),
        padY=parseFloat(cs.paddingTop)+parseFloat(cs.paddingBottom),
        W=(root.clientWidth||innerWidth)-(fs?padX:0),
        H=fs?root.clientHeight-padY:(vv?vv.height:innerHeight)-16,
        side=W>H*1.25&&H<600,key=[W,H,fs,side].join("|");
    if(key===lastKey)return; lastKey=key;
    root.classList.toggle("side",side);
    var aw=side?W-ctrl.offsetWidth-14:W, ah=side?H-(fs?0:4):H-ctrl.offsetHeight-12,
        portrait=aw/ah<0.95,cw,ch;
    if(portrait){cw=720;ch=Math.round(Math.min(1560,Math.max(1100,720*ah/aw)));}
    else{ch=720;cw=Math.round(Math.min(1900,Math.max(1100,720*aw/ah)));}
    var s=Math.max(0.1,Math.min(aw/cw,ah/ch));
    root.classList.toggle("portrait",portrait);
    canvas.style.width=cw+"px";canvas.style.height=ch+"px";canvas.style.transform="scale("+s+")";
    wrap.style.width=(cw*s)+"px";wrap.style.height=(ch*s)+"px";
  }
  function setPseudo(on){root.classList.toggle("lp-full",on);document.documentElement.classList.toggle("lp-lock",on);lastKey="";setTimeout(fit,30);wrap.focus();}
  function toggleFull(){
    if(nativeFull()){(document.exitFullscreen||document.webkitExitFullscreen).call(document);return;}
    if(root.classList.contains("lp-full")){setPseudo(false);return;}
    var req=root.requestFullscreen||root.webkitRequestFullscreen;
    if(req&&(document.fullscreenEnabled||document.webkitFullscreenEnabled)){
      try{var p=req.call(root);if(p&&p.catch)p.catch(function(){setPseudo(true);});return;}catch(e){}
    }
    setPseudo(true); // الآيفون: ملء الشاشة البديل
  }
  wrap.addEventListener("click",function(){next();});
  root.querySelectorAll(".lp-btn").forEach(function(b){b.addEventListener("click",function(e){
    e.stopPropagation();var a=b.getAttribute("data-act");
    if(a==="next")next();else if(a==="prev")prev();
    else if(a==="restart"){slides.forEach(function(s){s.classList.remove("active");});idx=0;step=0;slides[0].classList.add("active");setTimeout(paint,80);}
    else if(a==="full")toggleFull();
  });});
  root.addEventListener("keydown",function(e){
    if(e.key==="Escape"&&root.classList.contains("lp-full")){setPseudo(false);return;}
    if(["ArrowLeft"," ","Enter","PageDown"].indexOf(e.key)>-1){e.preventDefault();next();}
    else if(["ArrowRight","Backspace","PageUp"].indexOf(e.key)>-1){e.preventDefault();prev();}
  });
  var tx=null;
  wrap.addEventListener("touchstart",function(e){tx=e.touches[0].clientX;},{passive:true});
  wrap.addEventListener("touchend",function(e){if(tx===null)return;var dx=e.changedTouches[0].clientX-tx;tx=null;
    if(Math.abs(dx)>45){e.preventDefault();dx>0?next():prev();}},{passive:false});
  function onFs(){lastKey="";setTimeout(fit,60);wrap.focus();}
  document.addEventListener("fullscreenchange",onFs);document.addEventListener("webkitfullscreenchange",onFs);
  var rafId=0;function fitSoon(){if(rafId)return;rafId=requestAnimationFrame(function(){rafId=0;fit();});}
  if(window.ResizeObserver)new ResizeObserver(fitSoon).observe(root);
  window.addEventListener("resize",fit);window.addEventListener("orientationchange",function(){setTimeout(fit,250);});
  if(window.visualViewport)visualViewport.addEventListener("resize",fit);
  slides[0].classList.add("active","nofx");fit();setTimeout(function(){slides[0].classList.remove("nofx");paint();},120);
})();
