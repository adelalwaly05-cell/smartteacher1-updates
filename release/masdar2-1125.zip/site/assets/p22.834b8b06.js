
(function(){
var root=document.getElementById("qd");if(!root)return;
var wrap=root.querySelector(".lp-wrap"),canvas=root.querySelector(".qd-canvas"),ctrl=root.querySelector(".lp-ctrl"),cnt=root.querySelector(".lp-count");
var secs=[],maxs=[],rvs=[],asts=[],idx=0,step=0,cw=1280,ch=720;
var AR="٠١٢٣٤٥٦٧٨٩";function an(n){return String(n).replace(/\d/g,function(d){return AR[d];});}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
// ﴿...﴾ بخط المصحف، و ___ فراغ للكتابة
function nBl(s){return ((s||"").match(/_{3,}/g)||[]).length;}
function txb(s,ans,st){var i=0;return emo(esc(s)).replace(/﴿([^﴾]+)﴾/g,'<span class="q">﴿$1﴾</span>').replace(/_{3,}/g,function(){var a=ans[i],n=st[0]+(++i);
  return a===undefined?'<span class="blank"></span>':'<span class="blank fill"><b class="chip st" data-s="'+n+'">'+esc(a)+'</b></span>';});}
function emo(h){return h.replace(window.__EMO(),'<span class="emo">$1</span>');}
function tx(s){return emo(esc(s)).replace(/﴿([^﴾]+)﴾/g,'<span class="q">﴿$1﴾</span>').replace(/_{3,}/g,'<span class="blank"></span>');}
function st(n,d){return ' class="st" data-s="'+n+'"'+(d?' style="--d:'+d+'s"':'');}
function stc(c,n,d){return ' class="'+c+' st" data-s="'+n+'"'+(d?' style="--d:'+d+'s"':'');}
var ICON='<svg viewBox="0 0 300 170" aria-hidden="true"><path d="M10 120c40-14 70 14 110 0s70-14 110 0 50 10 60 6v44H10Z" fill="#dff6f3"/><path d="M10 138c40-12 70 12 110 0s70-12 110 0 50 8 60 4" fill="none" stroke="#13a59a" stroke-width="5" stroke-linecap="round"/>'+
 '<path d="M95 92h110l-14 34H109Z" fill="#c98a3c"/><path d="M95 92h110" stroke="#9c6626" stroke-width="7" stroke-linecap="round"/><path d="M110 104h80M114 115h72" stroke="#9c6626" stroke-width="3" opacity=".6"/>'+
 '<ellipse cx="150" cy="86" rx="32" ry="12" fill="#fff3d6"/><circle cx="235" cy="40" r="20" fill="#f6bb55"/><path d="M40 70l8-22 8 22M60 60l8-26 8 26" stroke="#3b4fc4" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round" opacity=".5"/></svg>';

function ra(t,n,nl){return t?'<div class="ra ra-box'+(nl?' nolbl':'')+' st" data-s="'+n+'">'+tx(t)+'</div>':'';}
function badge(v,n){return v?'<em class="st" data-s="'+n+'">'+an(v)+'</em>':'';}
function head(sl){return (sl.tag?'<span'+stc("tag",0)+'>'+esc(sl.tag)+'</span>':'')+(sl.h?'<h3'+(/[؟?]\s*$/.test(String(sl.h))?stc("qh",0,.08):st(0,.08))+'>'+tx(sl.h)+'</h3>':'');}
function ayah(a,n){return a?'<div'+stc("ayah",n||0,.15)+'>﴿ '+esc(a)+' ﴾</div>':'';}
function poem(p,n){return p?'<div'+stc("poem",n||0,.15)+'><span>'+esc(p[0])+'</span><span>'+esc(p[1])+'</span></div>':'';}
var B={
 title:function(sl){return {h:'<div'+st(0,.2)+'>'+(sl.kid?'<span class="k-title">'+esc(sl.kid)+'</span>':ICON)+'</div><span'+stc("tag",0)+'>'+esc(sl.tag||"")+'</span><h3'+st(0,.1)+'>'+tx(sl.h)+'</h3><p'+stc("sub",0,.3)+'>'+tx(sl.sub||"")+'</p>',m:0,c:"s-title"};},
 text:function(sl){var h=head(sl)+(sl.say?'<button type="button"'+stc("k-sayb",0)+' data-say="'+esc(sl.say)+'">🔊 استمع</button>':''),n=0;(sl.paras||[]).forEach(function(p,i){n=sl.together?1:i+1;
     if(typeof p==="object"){h+='<div'+stc("ayah",n)+'>﴿ '+esc(p.ayah)+' ﴾</div>';return;}
     var dl=/^[–-]\s/.test(p);h+='<p'+stc("para"+(dl?" dlg":""),n,sl.together?i*.12:0)+'>'+tx(p)+'</p>';});
   if(sl.ayah)h+=ayah(sl.ayah,0);return {h:h,m:n};},
 list:function(sl){var h=head(sl)+'<div class="lst">';(sl.items||[]).forEach(function(t,i){var k=sl.together?1:i+1;h+='<div'+stc("li",k,sl.together?i*.1:0)+'><i>'+an(i+1)+'</i><span>'+tx(t).replace(/^([^:：]{2,40}):/,'<b>$1:</b>')+'</span></div>';});
   return {h:h+'</div>',m:sl.together?1:(sl.items||[]).length};},
 vocab:function(sl){var P=sl.pairs||[],n=P.length,two=n>6,rows=two?Math.ceil(n/2):n;
   var h=head(sl)+'<table class="qtb vt'+(two?' two':'')+' st" data-s="0"><thead><tr><th>الكلمة</th><th data-all="m" title="إظهار كل المعاني أو إخفاؤها">المعنى 👁</th>'+(two?'<th>الكلمة</th><th data-all="m" title="إظهار كل المعاني أو إخفاؤها">المعنى 👁</th>':'')+'</tr></thead><tbody>';
   function cell(p){return p?'<td class="w">'+tx(p[0])+'</td><td class="qa" data-c="m"><span>'+tx(p[1])+'</span></td>':'<td></td><td></td>';}
   for(var r=0;r<rows;r++)h+='<tr>'+cell(P[r])+(two?cell(P[r+rows]):'')+'</tr>';
   return {h:h+'</tbody></table><p'+stc("note",0,.4)+'>اضغط على خانة المعنى لإظهاره، واضغط مرة أخرى لإخفائه</p>',m:0};},
 quran:function(sl){var h=head(sl)+'<div class="qr">'+(sl.basmala?'<span class="bs st" data-s="0">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</span>':'');
   sl.verses.forEach(function(v,i){h+='<span class="st" data-s="'+i+'">'+esc(v[1])+' <span class="vn">﴿'+an(v[0])+'﴾</span> </span>';});
   return {h:h+'</div>'+(sl.ref?'<p'+stc("note",0)+'>'+tx(sl.ref)+'</p>':''),m:sl.verses.length-1};},
 letter:function(sl){var l=sl.l,b=l,Z="\u200D",nj="ادذرزوأإآ".indexOf(l)>-1,F=nj?[[b,"منفصل"],[Z+b,"متصل في الآخر"]]:[[b+Z,"أول"],[Z+b+Z,"وسط"],[Z+b,"آخر متصل"],[b,"آخر منفصل"]];
   var h=head(sl)+'<div class="kl"><button type="button"'+stc("kl-big",0,.1)+' data-say="حرف ال'+esc((sl.name||"").replace(/^ال/,""))+'">'+esc(l)+'</button>'+
     '<div'+stc("kl-row",1)+'>'+(sl.hv||[]).map(function(x){return '<button type="button" class="kl-hv" data-say="'+esc(x)+'">'+esc(x)+'</button>';}).join("")+'</div>'+
     '<div'+stc("kl-row",2)+'>'+F.map(function(f){return '<div class="kl-fm">'+f[0]+'<small>'+f[1]+'</small></div>';}).join("")+'</div></div>';return {h:h,m:2};},
 img:function(sl){return {h:head(sl)+'<figure class="qd-fig"><img src="'+esc(sl.src)+'" alt="'+esc(sl.h||"")+'"><figcaption>'+esc(sl.cap||"")+'</figcaption></figure>',m:0};},
 pics:function(sl){var h=head(sl)+'<div class="kp">';(sl.items||[]).forEach(function(it,i){var w=esc(it[1]);
     h+='<button type="button"'+stc("",1,i*.08)+' data-say="'+esc(it[1].replace(/\.\.\./g,""))+'"><i>'+esc(it[0])+'</i><b>'+w+'</b></button>';});return {h:h+'</div>',m:1};},
 abyat:function(sl){var h=head(sl)+'<div class="abx">';(sl.verses||[]).forEach(function(v,i){h+='<div class="st ab-b" data-s="'+i+'"><i>'+an((sl.from||1)+i)+'</i><span>'+esc(v[0])+'</span><span>'+esc(v[1])+'</span></div>';});
   return {h:h+'</div>'+(sl.ref?'<p'+stc("note",0)+'>'+tx(sl.ref)+'</p>':''),m:Math.max(0,(sl.verses||[]).length-1)};},
 mcq:function(sl){var fillA=sl.a!==undefined?[sl.choices[sl.a]]:[];var h=head(sl)+(sl.stem?'<p'+stc("stem",0,.12)+'>'+tx(sl.stem)+'</p>':'')+ayah(sl.ayah)+poem(sl.poem)+(sl.q?'<p'+stc("stem sub",0,.2)+'>'+(nBl(sl.q)&&fillA.length?txb(sl.q,fillA,[1]):tx(sl.q))+'</p>':'');
   var L="أبجد";h+='<div class="chs'+(sl.qa||sl.long?' long':'')+(sl.big?' big':'')+'">';sl.choices.forEach(function(c,i){h+='<button type="button"'+stc("ch"+(sl.qa?" qa":""),1,i*.08)+' data-i'+(sl.a===i?' data-ok':'')+'><i>'+L[i]+'</i><span>'+(sl.qa?'﴿ '+esc(c)+' ﴾':tx(c))+'</span></button>';});
   var has=sl.a!==undefined;return {h:h+'</div>'+(has?'<div class="mcq-fb" aria-live="polite"></div>'+ra(sl.why,2):''),m:has?2:1,rv:has?2:0};},
 order:function(sl){var h=head(sl)+(sl.stem?'<p'+stc("stem",0,.12)+'>'+tx(sl.stem)+'</p>':'')+'<div class="ord'+(sl.items.length>4?' two':'')+'" data-ord>';sl.items.forEach(function(t,i){h+='<button type="button"'+stc("oi",1,i*.06)+' data-i><b></b><span>'+tx(t)+'</span>'+badge(sl.ans&&sl.ans[i],sl.ans?1+sl.ans[i]:0)+'</button>';});
   var mx=sl.ans?1+Math.max.apply(null,sl.ans):1,m=sl.why?mx+1:mx;
   return {h:h+'</div>'+(sl.note?'<p'+stc("note",1,.5)+'>'+tx(sl.note)+'</p>':'')+ra(sl.why,mx+1)+'<button type="button"'+stc("qd-reset",1,.5)+' data-i>إعادة الترتيب</button>',m:m};},
 match:function(sl){var L=sl.left||[],Rr=sl.right||[],n=Math.max(L.length,Rr.length),has=!!sl.ans;
   var h=head(sl)+(sl.stem?'<p'+stc("stem",0,.12)+'>'+tx(sl.stem)+'</p>':'')+'<table class="qtb mtb st" data-s="0"><thead><tr><th class="n">م</th><th>'+esc(sl.lh||"العمود (أ)")+'</th><th>'+esc(sl.rh||"العمود (ب)")+'</th><th'+(has?' data-all="a" title="إظهار كل الإجابات أو إخفاؤها"':'')+'>الرقم'+(has?' 👁':'')+'</th></tr></thead><tbody>';
   for(var i=0;i<n;i++){var a=has?sl.ans[i]:null;
     h+='<tr><td class="n">'+(i<L.length?an(i+1):'')+'</td><td>'+(i<L.length?tx(L[i]):'')+'</td><td>'+(i<Rr.length?tx(Rr[i]):'')+'</td>'+
       (i>=Rr.length?'<td></td>':has?'<td class="qa num" data-c="a"><span>'+(a?an(a):'—')+'</span></td>':'<td class="qn" data-cy="'+L.length+'"><b></b></td>')+'</tr>';}
   return {h:h+'</tbody></table><p'+stc("note",0,.4)+'>'+(has?'اضغط على خانة الرقم لإظهار الإجابة، واضغط مرة أخرى لإخفائها':'اضغط على الخانة لتضع الرقم المناسب')+'</p>'+ra(sl.why,1),m:sl.why?1:0};},
 open:function(sl){var h=head(sl)+(sl.qs&&sl.stem?'<p'+stc("stem",0,.1)+'>'+tx(sl.stem)+'</p>':''),k=0;
   (sl.qs||[sl]).forEach(function(q,i){if(i>0)k++;
     // الفراغات: تظهر إجابة كل فراغ بطاقةً صغيرة فوقه عند الضغط
     var nb=nBl(q.stem)+nBl(q.q),ans=null,rest=q.a;
     if(nb){if(q.b){ans=q.b;}else if(q.a){var pp=String(q.a).split(/\s*•\s*/);if(pp.length===nb){ans=pp;rest=null;}}}
     var base=[k],stemH=q.stem?(ans?txb(q.stem,ans,base):tx(q.stem)):'';var used=ans?Math.min(nBl(q.stem),ans.length):0;
     var qH=q.q?(ans?txb(q.q,ans.slice(used),[k+used]):tx(q.q)):'';if(ans)k+=Math.min(nb,ans.length);
     h+='<div'+stc("oneq",i>0?base[0]:0,.12)+'>'+(stemH?'<p class="stem">'+stemH+'</p>':'')+(q.ayah?'<div class="ayah">﴿ '+esc(q.ayah)+' ﴾</div>':'')+(q.poem?'<div class="poem"><span>'+esc(q.poem[0])+'</span><span>'+esc(q.poem[1])+'</span></div>':'')+(qH?'<p class="stem sub">'+qH+'</p>':'');
     if(!ans)for(var j=0;j<(q.lines===undefined?1:q.lines);j++)h+='<div class="ans"></div>';if(rest){k++;h+=ra(rest,k);}h+='</div>';});
   return {h:h,m:k};},
 info:function(sl){var h=head(sl)+'<div'+stc("info",0,.15)+'>'+tx(sl.body)+'</div>';if(sl.ex){h+='<div'+stc("exs",1)+'>'+sl.ex.map(function(e){return '<span>'+esc(e)+'</span>';}).join("")+'</div>';}
   return {h:h,m:sl.ex?1:0};},
 cols:function(sl){var C=["#3b4fc4","#13a59a","#e2557a","#d98b0c"],cs=sl.cols||[],q=!!(sl.stem||/[؟?]\s*$/.test(String(sl.h||""))),n=0;
   cs.forEach(function(c){n=Math.max(n,(c.items||[]).length);});
   var h=head(sl)+(sl.stem?'<p'+stc("stem",0,.12)+'>'+tx(sl.stem)+'</p>':'')+'<table class="qtb ctb st" data-s="0"><thead><tr>'+cs.map(function(c,i){return '<th style="--c:'+(c.c||C[i%4])+'"'+(q?' data-all="'+i+'" title="إظهار العمود أو إخفاؤه"':'')+'>'+tx(c.h)+(q?' 👁':'')+'</th>';}).join("")+'</tr></thead><tbody>';
   for(var r=0;r<n;r++)h+='<tr>'+cs.map(function(c,i){var t=(c.items||[])[r];return t===undefined?'<td></td>':q?'<td class="qa" data-c="'+i+'"><span>'+tx(t)+'</span></td>':'<td>'+tx(t)+'</td>';}).join("")+'</tr>';
   return {h:h+'</tbody></table>'+(q?'<p'+stc("note",0,.4)+'>اضغط على الخانة لإظهار الإجابة، واضغط مرة أخرى لإخفائها • اضغط عنوان العمود لإظهاره كله</p>':''),m:0};},
 diagram:function(sl){var h=head(sl)+(sl.stem?'<p'+stc("stem",0,.12)+'>'+tx(sl.stem)+'</p>':'')+'<div class="dg" style="--n:'+(sl.n||3)+'">';
   var k=0,has=sl.boxes.some(function(b){return b.a;});
   sl.boxes.forEach(function(b,i){k=has?k+1:1;h+='<div'+stc("db",k,has?0:i*.08)+'><h4>'+tx(b.h)+'</h4>'+(b.s?'<small>'+tx(b.s)+'</small>':'')+'<div class="ans"></div>'+(b.l>1?'<div class="ans"></div>':'');
     if(b.a){k++;h+=ra(b.a,k,1);}h+='</div>';});
   return {h:h+'</div>',m:k};}
};
function build(slides){
  canvas.innerHTML="";secs=[];maxs=[];rvs=[];asts=[];
  slides.forEach(function(sl){var r=(B[sl.t]||B.text)(sl);var s=document.createElement("section");s.className="qs"+(r.c?" "+r.c:"");
    if(r.rv){r.m=Math.max(r.m,r.rv);}s.innerHTML='<div class="qi">'+r.h+'</div><div class="rv-hint">اضغط لإظهار الإجابة</div>';canvas.appendChild(s);secs.push(s);maxs.push(r.m);rvs.push(r.rv||0);
    var at={};if(r.rv)at[r.rv]=1;s.querySelectorAll(".ra[data-s],em[data-s],.chip[data-s]").forEach(function(e){at[e.getAttribute("data-s")]=1;});asts.push(at);});
  var badge=document.createElement("div");badge.className="qd-badge";canvas.appendChild(badge);
  var bar=document.createElement("div");bar.className="qd-bar";canvas.appendChild(bar);
  calcHid(slides);bindInteractive();idx=firstVis();step=0;paint(0);updBtns();
}
var _ac=null;function beep(ok){try{_ac=_ac||new (window.AudioContext||window.webkitAudioContext)();var t=_ac.currentTime;
  (ok?[[660,0],[880,.09],[1175,.18]]:[[220,0],[180,.14]]).forEach(function(n){var o=_ac.createOscillator(),g=_ac.createGain();o.type=ok?"triangle":"sawtooth";o.frequency.value=n[0];
    g.gain.setValueAtTime(.0001,t+n[1]);g.gain.exponentialRampToValueAtTime(.15,t+n[1]+.02);g.gain.exponentialRampToValueAtTime(.0001,t+n[1]+(ok?.22:.3));o.connect(g);g.connect(_ac.destination);o.start(t+n[1]);o.stop(t+n[1]+.35);});}catch(e){}}
function bindInteractive(){
  secs.forEach(function(sec){
    sec.querySelectorAll("[data-say]").forEach(function(b){b.onclick=function(e){e.stopPropagation();if(window.kSay)kSay(b.getAttribute("data-say"));b.classList.remove("bop");void b.offsetWidth;b.classList.add("bop");};});
    var fb=sec.querySelector(".mcq-fb"),known=!!sec.querySelector(".ch[data-ok]");
    function resetCh(){sec.querySelectorAll(".ch").forEach(function(x){x.classList.remove("sel","good","bad","dim");});if(fb){fb.className="mcq-fb";fb.innerHTML="";}}
    sec.querySelectorAll(".ch").forEach(function(b){b.onclick=function(e){e.stopPropagation();if(!b.classList.contains("on"))return;
      if(!known){var was=b.classList.contains("sel");b.parentNode.querySelectorAll(".ch").forEach(function(x){x.classList.remove("sel");});if(!was)b.classList.add("sel");return;}
      if(b.classList.contains("bad")||sec.querySelector(".ch.good"))return;
      var ok=b.hasAttribute("data-ok");
      if(ok){b.classList.add("good");sec.querySelectorAll(".ch:not(.good)").forEach(function(x){x.classList.add("dim");});beep(true);
        fb.className="mcq-fb ok";fb.innerHTML='<span>✔ إجابة صحيحة، أحسنت!</span><button type="button" class="fb-re">↺ إعادة المحاولة</button>';}
      else{b.classList.add("bad");beep(false);var tries=sec.querySelectorAll(".ch.bad").length,left=sec.querySelectorAll(".ch:not(.bad)").length;
        fb.className="mcq-fb no";fb.innerHTML='<span>✘ إجابة غير صحيحة'+(left>1?'، حاول مرة أخرى':'')+'</span><button type="button" class="fb-re">↺ إعادة المحاولة</button>';}
      var r=fb.querySelector(".fb-re");r.onclick=function(ev){ev.stopPropagation();resetCh();};};});
    sec.querySelectorAll(".vc").forEach(function(b){b.onclick=function(e){e.stopPropagation();if(b.classList.contains("on"))b.classList.toggle("open");};});
    sec.querySelectorAll(".qtb [data-c]").forEach(function(c){c.onclick=function(e){e.stopPropagation();c.classList.toggle("open");if(c.classList.contains("open")&&typeof sfx==="function")sfx("a");};});
    sec.querySelectorAll(".qtb [data-all]").forEach(function(th){th.onclick=function(e){e.stopPropagation();var k=th.getAttribute("data-all"),cs=sec.querySelectorAll('.qtb [data-c="'+k+'"]'),any=[].some.call(cs,function(c){return !c.classList.contains("open");});
      cs.forEach(function(c){c.classList.toggle("open",any);});if(any&&typeof sfx==="function")sfx("a");};});
    sec.querySelectorAll(".qtb [data-cy]").forEach(function(c){var n=+c.getAttribute("data-cy"),v=0;c.onclick=function(e){e.stopPropagation();v=(v+1)%(n+1);c.classList.toggle("set",v>0);c.querySelector("b").textContent=v?an(v):"";};});
    var ord=sec.querySelector("[data-ord]");
    if(ord){var seq=[],draw=function(){ord.querySelectorAll(".oi").forEach(function(b){var k=seq.indexOf(b);b.classList.toggle("set",k>-1);b.querySelector("b").textContent=k>-1?an(k+1):"";});};
      ord.querySelectorAll(".oi").forEach(function(b){b.onclick=function(e){e.stopPropagation();if(!b.classList.contains("on"))return;var k=seq.indexOf(b);if(k>-1)seq.splice(k,1);else seq.push(b);draw();};});
      var rs=sec.querySelector(".qd-reset");if(rs)rs.onclick=function(e){e.stopPropagation();seq=[];draw();};}
    sec.querySelectorAll(".mi").forEach(function(b){var n=+b.parentNode.getAttribute("data-n"),v=0;b.onclick=function(e){e.stopPropagation();v=(v+1)%(n+1);b.classList.toggle("set",v>0);b.querySelector("b").textContent=v?an(v):"";};});
  });
}
function paint(dir){
  secs.forEach(function(s,i){var a=i===idx;s.classList.toggle("back",!a&&i>idx);s.classList.toggle("active",a);
    if(a)s.querySelectorAll(".st").forEach(function(el){el.classList.toggle("on",+el.getAttribute("data-s")<=step);});
    var rv=a&&rvs[i]&&step>=rvs[i];s.classList.toggle("rv",!!rv);var hn=s.querySelector(".rv-hint");if(hn)hn.style.display=(a&&asts[i]&&asts[i][step+1])?"":"none";
    else if(Math.abs(i-idx)>1)s.querySelectorAll(".st.on").forEach(function(el){el.classList.remove("on");});});
  var vp=visPos(),t=an(vp[0])+" من "+an(vp[1]);cnt.textContent=t;var bd=canvas.querySelector(".qd-badge");if(bd)bd.textContent=t;
  var bar=canvas.querySelector(".qd-bar");if(bar)bar.style.width=(vp[0]/vp[1]*100)+"%";
}
/* مؤثرات صوتية: نغمة عند ظهور سؤال/شريحة جديدة، ورنين عند ظهور الإجابة */
var sndOn=true;try{sndOn=localStorage.getItem("qd:snd")!=="0";}catch(e){}
function sfx(kind){if(!sndOn)return;try{_ac=_ac||new (window.AudioContext||window.webkitAudioContext)();var t=_ac.currentTime,N;
  if(kind==="q")N=[[392,0,.16,"sine",.13],[587,.1,.22,"sine",.13]];
  else if(kind==="a")N=[[1047,0,.12,"triangle",.12],[1319,.08,.14,"triangle",.12],[1568,.16,.3,"triangle",.11]];
  else N=[[660,0,.06,"sine",.07]];
  N.forEach(function(n){var o=_ac.createOscillator(),g=_ac.createGain();o.type=n[3];o.frequency.value=n[0];g.gain.setValueAtTime(.0001,t+n[1]);
    g.gain.exponentialRampToValueAtTime(n[4],t+n[1]+.02);g.gain.exponentialRampToValueAtTime(.0001,t+n[1]+n[2]);o.connect(g);g.connect(_ac.destination);o.start(t+n[1]);o.stop(t+n[1]+n[2]+.05);});}catch(e){}}
function stepSound(){var sec=secs[idx];if(!sec)return;var nw=[].slice.call(sec.querySelectorAll('[data-s="'+step+'"]'));
  var ans=(rvs[idx]&&step===rvs[idx])||nw.some(function(e){return e.matches(".ra,.chip,em");});
  var q=nw.some(function(e){return e.matches(".oneq,.db,.stem,.ch,.chs")||e.querySelector&&e.querySelector(".stem,.ch");});
  sfx(ans?"a":q?"q":"p");}
function next(){if(step<maxs[idx]){step++;paint();stepSound();}else{var n=nv(idx,1);if(n>=0){idx=n;step=0;paint(1);sfx("q");}}}
function prev(){var n=nv(idx,-1);if(n>=0){idx=n;step=maxs[idx];paint(-1);}else{step=0;paint();}}
// خطوة للخلف: يُخفي آخر عنصر ظهر، وإذا كانت الشريحة في بدايتها يرجع إلى السابقة
function back(){if(step>0){step--;paint();}else{var n=nv(idx,-1);if(n>=0){idx=n;step=maxs[idx];paint(-1);}}}
function restart(){idx=firstVis();step=0;paint();}
// يصغّر الخط تلقائياً إذا زاد محتوى الشريحة عن مساحتها
function shrink(sec){var qi=sec.firstChild,cs=getComputedStyle(sec),had=sec.classList.contains("rv"),
    av=sec.clientHeight-parseFloat(cs.paddingTop)-parseFloat(cs.paddingBottom);
  function kFor(rv){sec.classList.toggle("rv",rv);sec.classList.toggle("meas",rv);var k=1,g=0;qi.style.setProperty("--k",1);
    while(qi.offsetHeight>av&&k>.42&&g++<28){k*=.94;qi.style.setProperty("--k",k);}return k;}
  var k=Math.min(kFor(false),sec.querySelector(".ra,em[data-s]")?kFor(true):1);sec.classList.toggle("rv",had);sec.classList.remove("meas");qi.style.setProperty("--k",k);}
function fit(){
  if(!root.classList.contains("lp-full"))return;
  var cs=getComputedStyle(root),W=root.clientWidth-parseFloat(cs.paddingLeft)-parseFloat(cs.paddingRight),
      H=root.clientHeight-parseFloat(cs.paddingTop)-parseFloat(cs.paddingBottom),side=W>H*1.25&&H<600;
  root.classList.toggle("side",side);
  var aw=side?W-ctrl.offsetWidth-12:W,ah=side?H:H-ctrl.offsetHeight-14,portrait=aw/ah<.95;
  if(portrait){cw=720;ch=Math.round(Math.min(1560,Math.max(1100,720*ah/aw)));}else{ch=720;cw=Math.round(Math.min(1900,Math.max(1100,720*aw/ah)));}
  var s=Math.max(.1,Math.min(aw/cw,ah/ch));root.classList.toggle("portrait",portrait);
  canvas.style.width=cw+"px";canvas.style.height=ch+"px";canvas.style.setProperty("--ch",ch+"px");canvas.style.transform="scale("+s+")";
  wrap.style.width=(cw*s)+"px";wrap.style.height=(ch*s)+"px";secs.forEach(shrink);
}
var fitT;function fitSoon(){clearTimeout(fitT);fitT=setTimeout(fit,60);}
window.addEventListener("resize",fitSoon);window.addEventListener("orientationchange",function(){setTimeout(fit,300);});
if(window.visualViewport)visualViewport.addEventListener("resize",fitSoon);
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(fitSoon);
new MutationObserver(function(){if(root.classList.contains("lp-full"))fitSoon();}).observe(root,{attributes:true,attributeFilter:["class"]});
// السحب بالإصبع (أو بالفأرة): يمين = إظهار الخطوة التالية، يسار = إخفاء آخر خطوة
var sx=null,sy=0,swiped=false;
function sStart(x,y){sx=x;sy=y;}
function sEnd(x,y){if(sx===null)return;var dx=x-sx,dy=y-sy;sx=null;
  if(Math.abs(dx)>40&&Math.abs(dx)>Math.abs(dy)*1.2){swiped=true;if(dx>0)next();else back();setTimeout(function(){swiped=false;},400);}}
if(window.PointerEvent){
  wrap.addEventListener("pointerdown",function(e){sStart(e.clientX,e.clientY);});
  wrap.addEventListener("pointerup",function(e){sEnd(e.clientX,e.clientY);});
  wrap.addEventListener("pointercancel",function(){sx=null;});
}else{
  wrap.addEventListener("touchstart",function(e){sStart(e.touches[0].clientX,e.touches[0].clientY);},{passive:true});
  wrap.addEventListener("touchend",function(e){sEnd(e.changedTouches[0].clientX,e.changedTouches[0].clientY);});
}
// بعد السحب لا يُحسب الإفلات ضغطةً (حتى لا يتقدّم مرتين أو يختار خيارًا بالخطأ)
wrap.addEventListener("click",function(e){if(swiped){e.stopPropagation();e.preventDefault();swiped=false;}},true);
wrap.addEventListener("click",function(){next();});
ctrl.addEventListener("click",function(e){var b=e.target.closest("[data-act]");if(!b)return;var a=b.getAttribute("data-act");
  if(a==="next")next();else if(a==="prev")prev();else if(a==="restart")restart();wrap.focus();});
root.addEventListener("keydown",function(e){var k=e.key;
  if(k==="Escape"){root.classList.remove("lp-full");return;}
  if(k==="ArrowLeft"||k===" "||k==="Enter"||k==="PageDown"){e.preventDefault();next();}
  else if(k==="ArrowRight"||k==="PageUp"||k==="Backspace"){e.preventDefault();back();}});
(function(){var c=root.querySelector(".lp-ctrl");if(!c||c.querySelector("[data-snd]"))return;var b=document.createElement("button");b.type="button";b.className="lp-btn";b.setAttribute("data-snd","");b.setAttribute("aria-label","المؤثرات الصوتية");
  function ic(){b.innerHTML=sndOn?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9v6h4l5 4V5L8 9Z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/></svg>':'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9v6h4l5 4V5L8 9Z"/><path d="m17 9 5 6M22 9l-5 6"/></svg>';}
  ic();b.onclick=function(e){e.stopPropagation();sndOn=!sndOn;try{localStorage.setItem("qd:snd",sndOn?"1":"0");}catch(_){}ic();if(sndOn)sfx("a");};c.appendChild(b);})();
/* إعدادات خط الإجابات (الحجم والنوع): مشتركة بين عرض الدرس والشرح، تُحفظ على الجهاز وتُطبَّق تلقائيًا */
window.AFSET=window.AFSET||(function(){
  var FONTS=[["","تجوال",""],["Cairo","القاهرة","Cairo:wght@400;700;800"],["Almarai","المراعي","Almarai:wght@400;700;800"],["Amiri","أميري",""],["Noto Naskh Arabic","نسخ","Noto+Naskh+Arabic:wght@400;700"],["Reem Kufi","كوفي","Reem+Kufi:wght@400;700"]];
  var PRE=[[1,"عادي"],[1.2,"كبير"],[1.4,"أكبر"],[1.65,"ضخم"]],DEF=1.2,st={sz:DEF,ff:""},subs=[];
  function fdef(f){for(var i=0;i<FONTS.length;i++)if(FONTS[i][0]===f)return FONTS[i];return null;}
  try{var v=localStorage.getItem("qd:afsv");if(v)st.sz=+v;else{var o=localStorage.getItem("qd:afs");if(o!==null&&PRE[+o])st.sz=PRE[+o][0];}st.ff=localStorage.getItem("qd:aff")||"";}catch(e){}
  if(!(st.sz>=.8&&st.sz<=2.2))st.sz=DEF;if(!fdef(st.ff))st.ff="";
  function loadFont(f){var d=fdef(f);if(!d||!d[2])return;var id="qdf-"+f.replace(/\s+/g,"");if(document.getElementById(id))return;
    var l=document.createElement("link");l.id=id;l.rel="stylesheet";l.href="https://fonts.googleapis.com/css2?family="+d[2]+"&display=swap";l.onload=emit;document.head.appendChild(l);}
  function fam(f){return f?"'"+f+"','Tajawal',Tahoma,sans-serif":"";}
  function save(){try{localStorage.setItem("qd:afsv",String(st.sz));localStorage.setItem("qd:aff",st.ff);}catch(_){}}
  function emit(){subs.slice().forEach(function(f){try{f(st);}catch(e){}});}
  function on(f){subs.push(f);f(st);}function off(f){subs=subs.filter(function(x){return x!==f;});}
  function set(sz,ff){if(sz!=null)st.sz=Math.max(.8,Math.min(2.2,Math.round(sz*20)/20));if(ff!=null){st.ff=ff;loadFont(ff);}save();emit();}
  /* يطبّق الإعداد على عنصر: --afs للحجم و--aff لنوع الخط */
  function applyTo(el){el.style.setProperty("--afs",st.sz);if(st.ff)el.style.setProperty("--aff",fam(st.ff));else el.style.removeProperty("--aff");}
  if(st.ff)loadFont(st.ff);
  function panel(host,btn){
    var p=document.createElement("div");p.className="afs-set";p.hidden=true;p.setAttribute("role","dialog");p.setAttribute("aria-label","إعدادات خط الإجابات");
    p.innerHTML='<div class="h"><b>✍️ خط الإجابات</b><button type="button" class="x" aria-label="إغلاق">✕</button></div>'
      +'<div class="lbl">الحجم</div><div class="row pre">'+PRE.map(function(x){return '<button type="button" data-v="'+x[0]+'">'+x[1]+'</button>';}).join("")+'</div>'
      +'<div class="row" style="margin-top:8px"><button type="button" data-d="-1" aria-label="تصغير">أ−</button><input type="range" min="0.8" max="2.2" step="0.05" aria-label="حجم الخط"><button type="button" data-d="1" aria-label="تكبير">أ+</button><output></output></div>'
      +'<div class="lbl">نوع الخط</div><div class="fonts">'+FONTS.map(function(x){return '<button type="button" data-f="'+x[0]+'" style="font-family:'+(x[0]?"\'"+x[0]+"\',":"")+'Tajawal,Tahoma,sans-serif">'+x[1]+'</button>';}).join("")+'</div>'
      +'<div class="prev">هذه معاينة لشكل الإجابة.</div>'
      +'<div class="foot"><small>تُحفظ تلقائيًا على هذا الجهاز.</small><button type="button" class="rs">استعادة الافتراضي</button></div>';
    var rg=p.querySelector("input"),out=p.querySelector("output"),pv=p.querySelector(".prev");
    function ui(){rg.value=st.sz;out.textContent=Math.round(st.sz*100)+"%";pv.style.fontSize=(15*1.08*st.sz)+"px";pv.style.fontFamily=fam(st.ff)||"";
      p.querySelectorAll("[data-v]").forEach(function(x){x.classList.toggle("on",Math.abs(+x.getAttribute("data-v")-st.sz)<.001);});
      p.querySelectorAll("[data-f]").forEach(function(x){x.classList.toggle("on",x.getAttribute("data-f")===st.ff);});}
    p.querySelectorAll("[data-v]").forEach(function(x){x.onclick=function(){set(+x.getAttribute("data-v"));};});
    p.querySelectorAll("[data-d]").forEach(function(x){x.onclick=function(){set(st.sz+.05*x.getAttribute("data-d"));};});
    rg.oninput=function(){set(+rg.value);};
    p.querySelectorAll("[data-f]").forEach(function(x){x.onclick=function(){set(null,x.getAttribute("data-f"));};});
    p.querySelector(".rs").onclick=function(){set(DEF,"");};
    function show(v){p.hidden=!v;if(v){ui();FONTS.forEach(function(x){loadFont(x[0]);});}}
    p.querySelector(".x").onclick=function(){show(false);};
    p.addEventListener("keydown",function(e){e.stopPropagation();if(e.key==="Escape")show(false);});
    ["click","pointerdown","pointerup","mousedown","mouseup","touchstart","touchend"].forEach(function(t){p.addEventListener(t,function(e){e.stopPropagation();});});
    host.addEventListener("click",function(e){if(!p.hidden&&!p.contains(e.target)&&!(btn&&btn.contains(e.target))){show(false);e.stopPropagation();e.preventDefault();}},true);
    on(ui);host.appendChild(p);
    return {el:p,show:show,toggle:function(){show(p.hidden);},destroy:function(){off(ui);p.remove();}};}
  return {st:st,on:on,off:off,set:set,fam:fam,applyTo:applyTo,loadFont:loadFont,panel:panel};
})();
(function(){var c=root.querySelector(".lp-ctrl");if(!c||c.querySelector("[data-afs]"))return;
  var b=document.createElement("button");b.type="button";b.className="lp-btn lp-afs";b.setAttribute("data-afs","");b.setAttribute("aria-label","إعدادات خط الإجابات");b.title="إعدادات خط الإجابات (الحجم والنوع)";
  b.innerHTML='<span style="font-size:20px;line-height:1">أ<span style="font-size:.6em">أ</span></span><small>الخط</small>';
  var P=AFSET.panel(root,b),rt;
  AFSET.on(function(){AFSET.applyTo(root);clearTimeout(rt);rt=setTimeout(function(){window.dispatchEvent(new Event("resize"));},80);});
  b.onclick=function(e){e.stopPropagation();P.toggle();};c.appendChild(b);})();
/* خلفية عرض الدرس: لون أو صورة من الجهاز، تُحفظ على هذا الجهاز */
(function(){var c=root.querySelector(".lp-ctrl");if(!c||c.querySelector("[data-qbg]"))return;
  var K="qd:bg",st={t:"",v:"",paper:1};try{var j=JSON.parse(localStorage.getItem(K)||"null");if(j&&typeof j==="object")st=j;}catch(e){}
  var canvas=root.querySelector(".qd-canvas");
  var PRE=[["#ffffff","أبيض"],["#fef9e7","كريمي"],["#e0f2fe","سماوي"],["#dcfce7","نعناعي"],["#fce7f3","وردي"],["#ede9fe","بنفسجي"],["#fef3c7","ليموني"],["#1f4d3a","سبورة خضراء"],["#1e293b","كحلي"],
    ["linear-gradient(135deg,#e0f2fe,#fce7f3)","سماء وردية"],["linear-gradient(135deg,#fef3c7,#fde68a 40%,#fca5a5)","غروب"],["linear-gradient(135deg,#d1fae5,#a7f3d0 50%,#6ee7b7)","ربيع"],["linear-gradient(135deg,#1e3a8a,#6d28d9)","ليلي"],["radial-gradient(circle at 30% 20%,#fff,#e2e8f0)","فضّي"]];
  function apply(){root.classList.toggle("cbg",!!st.t);root.classList.toggle("cbg-paper",!!st.t&&!!st.paper);
    if(!st.t){canvas.style.removeProperty("background");return;}
    if(st.t==="img")canvas.style.background="#000 url("+st.v+") center/cover no-repeat";else canvas.style.background=st.v;}
  function save(){try{localStorage.setItem(K,JSON.stringify(st));return true;}catch(e){return false;}}
  var b=document.createElement("button");b.type="button";b.className="lp-btn lp-afs";b.setAttribute("data-qbg","");b.setAttribute("aria-label","خلفية العرض");b.title="تغيير خلفية عرض الدرس (لون أو صورة)";
  b.innerHTML='<span style="font-size:19px;line-height:1">🎨</span><small>الخلفية</small>';
  var p=document.createElement("div");p.className="afs-set qbg-set";p.hidden=true;p.setAttribute("role","dialog");p.setAttribute("aria-label","خلفية العرض");
  p.innerHTML='<div class="h"><b>🎨 خلفية عرض الدرس</b><button type="button" class="x" aria-label="إغلاق">✕</button></div>'
    +'<div class="lbl">ألوان جاهزة</div><div class="qbg-sw">'+PRE.map(function(x){return '<button type="button" data-c="'+x[0]+'" title="'+x[1]+'" style="background:'+x[0]+'"></button>';}).join("")+'</div>'
    +'<div class="row" style="margin-top:10px"><label class="qbg-pick">🖌️ لون من اختيارك<input type="color" value="#dbeafe"></label>'
    +'<label class="qbg-pick">🖼️ صورة من الجهاز<input type="file" accept="image/*" hidden></label></div>'
    +'<label class="qbg-ppr"><input type="checkbox"> ورقة بيضاء خلف الكتابة (لوضوح النص)</label>'
    +'<div class="qbg-msg"></div>'
    +'<div class="foot"><small>تُحفظ تلقائيًا على هذا الجهاز.</small><button type="button" class="rs">الخلفية الأصلية</button></div>';
  var msg=p.querySelector(".qbg-msg"),ppr=p.querySelector(".qbg-ppr input");
  function ui(){p.querySelectorAll("[data-c]").forEach(function(x){x.classList.toggle("on",st.t==="c"&&x.getAttribute("data-c")===st.v);});ppr.checked=!!st.paper;msg.textContent="";}
  function set(t,v){st.t=t;st.v=v;apply();if(!save()){msg.textContent="الصورة كبيرة جدًّا للحفظ الدائم، ستظهر الآن فقط.";}else ui();}
  p.querySelectorAll("[data-c]").forEach(function(x){x.onclick=function(){set("c",x.getAttribute("data-c"));};});
  p.querySelector('input[type=color]').oninput=function(){set("c",this.value);};
  p.querySelector('input[type=file]').onchange=function(){var f=this.files[0];this.value="";if(!f)return;msg.textContent="جارٍ تجهيز الصورة…";
    var fr=new FileReader();fr.onload=function(){var img=new Image();img.onload=function(){var k=Math.min(1,1920/Math.max(img.width,img.height)),cv=document.createElement("canvas");
      cv.width=Math.round(img.width*k);cv.height=Math.round(img.height*k);cv.getContext("2d").drawImage(img,0,0,cv.width,cv.height);
      var q=.85,d=cv.toDataURL("image/jpeg",q);while(d.length>2400000&&q>.4){q-=.1;d=cv.toDataURL("image/jpeg",q);}set("img",d);};
      img.onerror=function(){msg.textContent="تعذّر فتح الصورة.";};img.src=fr.result;};fr.readAsDataURL(f);};
  ppr.onchange=function(){st.paper=ppr.checked?1:0;apply();save();};
  p.querySelector(".rs").onclick=function(){st={t:"",v:"",paper:st.paper};apply();save();ui();};
  function show(v){p.hidden=!v;if(v)ui();}
  p.querySelector(".x").onclick=function(){show(false);};
  p.addEventListener("keydown",function(e){e.stopPropagation();if(e.key==="Escape")show(false);});
  ["click","pointerdown","pointerup","mousedown","mouseup","touchstart","touchend"].forEach(function(t){p.addEventListener(t,function(e){e.stopPropagation();});});
  root.addEventListener("click",function(e){if(!p.hidden&&!p.contains(e.target)&&!b.contains(e.target)){show(false);e.stopPropagation();e.preventDefault();}},true);
  root.appendChild(p);b.onclick=function(e){e.stopPropagation();show(p.hidden);};c.appendChild(b);apply();})();
/* QED-JS-BEGIN */
/* ===== أدوات المعلم في عرض الدرس: حجم السؤال وتعديل النصوص (تُحفظ في حساب المعلم وتظهر له وحده) ===== */
var QE=(function(){
  var c=root.querySelector(".lp-ctrl"),curKey="",ovr={},cand=[],orig=[],origH=[],editing=false,dirty=false,prefs={q:1,c:1},seq=0;
  function C(){return window.CUST;}
  var b=document.createElement("button");b.type="button";b.className="lp-btn lp-afs";b.setAttribute("data-qed","");b.hidden=true;
  b.title="أدوات المعلم: حجم السؤال وتعديل نصوص العرض";b.setAttribute("aria-label","أدوات المعلم");
  b.innerHTML='<span style="font-size:19px;line-height:1">✏️</span><small>المعلم</small>';
  function zrow(k,t){return '<div class="lbl">'+t+'</div><div class="row"><button type="button" data-z="'+k+'" data-d="-1" aria-label="تصغير">−</button><input type="range" min="70" max="220" step="5" data-r="'+k+'"><output data-o="'+k+'"></output><button type="button" data-z="'+k+'" data-d="1" aria-label="تكبير">+</button></div>';}
  var p=document.createElement("div");p.className="afs-set qed-set";p.hidden=true;p.setAttribute("role","dialog");p.setAttribute("aria-label","أدوات المعلم");
  p.innerHTML='<div class="h"><b>✏️ أدوات المعلم</b><button type="button" class="x" aria-label="إغلاق">✕</button></div>'
    +zrow("q","🔠 حجم خط السؤال")+zrow("c","🔡 حجم خط الخيارات")
    +'<div class="qed-only"><div class="lbl">📝 تعديل نصوص هذا العرض</div><div class="row"><button type="button" class="ed" style="flex:1">✏️ ابدأ تعديل الأسئلة والإجابات</button></div>'
    +'<div class="row" style="margin-top:6px"><button type="button" class="rs" style="flex:1">↩️ استعادة النص الأصلي لهذا العرض</button></div></div>'
    +'<div class="qed-msg"></div>'
    +'<div class="foot"><small class="qed-note">🔒 الإعدادات والتعديلات تُحفظ في حسابك أنت فقط، ولا تظهر لأي معلم آخر أو للطلاب.</small><button type="button" class="rz">الحجم الأصلي</button></div>';
  var msg=p.querySelector(".qed-msg");
  var bar=document.createElement("div");bar.className="qed-bar";bar.hidden=true;
  bar.innerHTML='<span>✏️ وضع التعديل: اضغط على أي نص مُحاط بإطار لتعديله</span><button type="button" class="sv">💾 حفظ</button><button type="button" class="dn">إنهاء</button>';
  var dlg=document.createElement("div");dlg.className="afs-set qed-dlg";dlg.hidden=true;
  dlg.innerHTML='<div class="h"><b>تعديل النص</b><button type="button" class="x" aria-label="إغلاق">✕</button></div><textarea rows="5" dir="rtl"></textarea>'
    +'<small class="qed-tip">اكتب <b>____</b> لفراغ، و <b>[[الإجابة]]</b> لإجابة تظهر داخل الفراغ.</small>'
    +'<div class="foot"><button type="button" class="og">النص الأصلي</button><span style="flex:1"></span><button type="button" class="cn">إلغاء</button><button type="button" class="ok on">تم ✔</button></div>';
  var ta=dlg.querySelector("textarea"),cur=null;
  function say(t,bad){msg.textContent=t||"";msg.style.color=bad?"#b91c1c":"#15803d";}
  function toast(t){var x=document.createElement("div");x.className="qed-toast";x.textContent=t;root.appendChild(x);setTimeout(function(){x.remove();},2600);}
  /* ---- حجم الخط ---- */
  function applyP(){root.style.setProperty("--qfs",prefs.q||1);root.style.setProperty("--cfs",prefs.c||1);
    ["q","c"].forEach(function(k){var v=Math.round((prefs[k]||1)*100);p.querySelector('[data-r="'+k+'"]').value=v;p.querySelector('[data-o="'+k+'"]').textContent=v+"٪";});}
  var pt;function setP(k,v){prefs[k]=Math.max(.7,Math.min(2.2,v));applyP();window.dispatchEvent(new Event("resize"));
    clearTimeout(pt);pt=setTimeout(function(){if(!(C()&&C().ok())){try{localStorage.setItem("qd:fs",JSON.stringify(prefs));say("✔ حُفظ الحجم على هذا الجهاز.");}catch(e){}return;}C().save("qdprefs",prefs).then(function(){say("✔ حُفظ الحجم في حسابك.");},function(e){say(e.message,1);});},700);}
  p.querySelectorAll("[data-r]").forEach(function(r){r.oninput=function(){setP(r.getAttribute("data-r"),r.value/100);};});
  p.querySelectorAll("[data-z]").forEach(function(x){x.onclick=function(){var k=x.getAttribute("data-z");setP(k,(prefs[k]||1)+.1*x.getAttribute("data-d"));};});
  p.querySelector(".rz").onclick=function(){setP("q",1);setP("c",1);};
  /* ---- النصوص القابلة للتعديل ---- */
  var SKIP="svg,[data-say],.qd-reset,.mcq-fb,.emo-only,.k-sayb,script,style";
  function pick(qi){var out=[];(function walk(n){[].forEach.call(n.children,function(e){if(e.matches(SKIP))return;
      if(e.matches(".chip")||[].some.call(e.childNodes,function(t){return t.nodeType===3&&/\S/.test(t.nodeValue);})){out.push(e);return;}walk(e);});})(qi);return out;}
  function ser(e){var s="";[].forEach.call(e.childNodes,function(n){if(n.nodeType===3)s+=n.nodeValue;else if(n.nodeType===1){
      if(n.tagName==="BR")s+="\n";else if(n.matches(".chip"))s+=e.matches(".chip")?n.textContent:"[["+n.textContent+"]]";
      else if(n.matches(".blank")&&!n.querySelector(".chip"))s+="____";else s+=ser(n);}});return s;}
  function des(t,el,i,j){var ds=[].map.call(el.querySelectorAll(".chip[data-s]"),function(x){return x.getAttribute("data-s");});
    var od=origH[i]&&origH[i][j]!==undefined?document.createElement("div"):null;if(od){od.innerHTML=origH[i][j];ds=[].map.call(od.querySelectorAll(".chip[data-s]"),function(x){return x.getAttribute("data-s");});}
    var k=0;return emo(esc(t)).replace(/﴿([^﴾]+)﴾/g,'<span class="q">﴿$1﴾</span>').replace(/\[\[([\s\S]*?)\]\]/g,function(_,a){var d=ds[Math.min(k++,ds.length-1)];
      return '<span class="blank fill"><b class="chip'+(d?' st" data-s="'+d:'')+'">'+a+'</b></span>';}).replace(/_{3,}/g,'<span class="blank"></span>').replace(/\n/g,"<br>");}
  function collect(){cand=[];orig=[];origH=[];secs.forEach(function(s,i){var L=pick(s.querySelector(".qi"));cand.push(L);orig.push(L.map(ser));origH.push(L.map(function(e){return e.innerHTML;}));
      L.forEach(function(e,j){e.setAttribute("data-qe",i+":"+j);});});}
  function setEl(i,j,t){var e=cand[i]&&cand[i][j];if(!e)return;if(t==null||t===orig[i][j]){e.innerHTML=origH[i][j];}else e.innerHTML=e.matches(".chip")?esc(t):des(t,e,i,j);}
  function applyO(){Object.keys(ovr||{}).forEach(function(i){var o=ovr[i]||{};Object.keys(o).forEach(function(j){setEl(+i,+j,String(o[j]));});});paint();if(root.classList.contains("lp-full"))fitSoon();}
  /* ---- وضع التعديل ---- */
  function edit(on){editing=!!on;root.classList.toggle("qed",editing);bar.hidden=!editing;if(editing){p.hidden=true;idx=Math.min(idx,secs.length-1);step=maxs[idx];paint();}else{step=0;paint();}fitSoon();}
  function save(){if(!C()||!C().ok())return toast("سجّل الدخول بحساب المعلم أولًا.");var any=Object.keys(ovr).length;
    bar.querySelector(".sv").disabled=true;C().save("qd:"+curKey,any?ovr:null).then(function(){dirty=false;toast("✔ حُفظت التعديلات في حسابك");},function(e){toast("تعذّر الحفظ: "+e.message);}).then(function(){bar.querySelector(".sv").disabled=false;});}
  function done(){if(dirty&&confirm("حفظ التعديلات قبل الإنهاء؟"))save();edit(false);}
  bar.querySelector(".sv").onclick=save;bar.querySelector(".dn").onclick=done;
  p.querySelector(".ed").onclick=function(){edit(true);};
  p.querySelector(".rs").onclick=function(){if(!confirm("استعادة النص الأصلي لكل شرائح هذا العرض؟"))return;ovr={};secs.forEach(function(s,i){(cand[i]||[]).forEach(function(e,j){setEl(i,j,null);});});paint();fitSoon();
    if(C()&&C().ok())C().save("qd:"+curKey,null).then(function(){say("✔ عاد العرض إلى نصه الأصلي.");},function(e){say(e.message,1);});};
  function openDlg(e){var q=e.getAttribute("data-qe").split(":"),i=+q[0],j=+q[1];cur=[i,j,e];ta.value=ser(e);dlg.hidden=false;
    dlg.querySelector(".qed-tip").style.display=e.matches(".chip")?"none":"";setTimeout(function(){ta.focus();},30);}
  function closeDlg(){dlg.hidden=true;cur=null;}
  dlg.querySelector(".x").onclick=closeDlg;dlg.querySelector(".cn").onclick=closeDlg;
  dlg.querySelector(".og").onclick=function(){if(cur)ta.value=orig[cur[0]][cur[1]];};
  dlg.querySelector(".ok").onclick=function(){if(!cur)return;var i=cur[0],j=cur[1],t=ta.value.replace(/\r/g,"");
    if(t===orig[i][j]){if(ovr[i]){delete ovr[i][j];if(!Object.keys(ovr[i]).length)delete ovr[i];}}else{(ovr[i]=ovr[i]||{})[j]=t;}
    setEl(i,j,t);dirty=true;closeDlg();paint();fitSoon();};
  [p,dlg,bar].forEach(function(x){x.addEventListener("keydown",function(e){e.stopPropagation();if(e.key==="Escape"){if(x===dlg)closeDlg();else if(x===p)p.hidden=true;}});
    ["click","pointerdown","pointerup","mousedown","mouseup","touchstart","touchend"].forEach(function(t){x.addEventListener(t,function(e){e.stopPropagation();});});});
  /* أثناء التعديل: الضغط يفتح المحرّر بدل التقدّم، والأسهم تنتقل بين الشرائح */
  function jump(d){var n=idx+d;if(n<0||n>=secs.length)return;idx=n;step=maxs[idx];paint(d);}
  wrap.addEventListener("click",function(e){if(!editing)return;e.stopPropagation();e.preventDefault();var t=e.target.closest&&e.target.closest("[data-qe]");if(t)openDlg(t);},true);
  ["pointerdown","pointerup","touchstart","touchend"].forEach(function(t){wrap.addEventListener(t,function(e){if(editing)e.stopPropagation();},true);});
  wrap.addEventListener("keydown",function(e){if(!editing)return;e.stopPropagation();var k=e.key;if(k==="ArrowLeft"||k==="PageDown"){e.preventDefault();jump(1);}else if(k==="ArrowRight"||k==="PageUp"){e.preventDefault();jump(-1);}else if(k==="Escape")done();},true);
  c.addEventListener("click",function(e){if(!editing)return;var x=e.target.closest("[data-act]");if(!x)return;var a=x.getAttribute("data-act");
    if(a==="next"||a==="prev"){e.stopPropagation();jump(a==="next"?1:-1);}else if(a==="restart"){e.stopPropagation();idx=0;step=maxs[0];paint();}},true);
  root.addEventListener("click",function(e){if(!p.hidden&&!p.contains(e.target)&&!b.contains(e.target)){p.hidden=true;e.stopPropagation();e.preventDefault();}},true);
  b.onclick=function(e){e.stopPropagation();p.hidden=!p.hidden;say("");applyP();};
  root.appendChild(p);root.appendChild(bar);root.appendChild(dlg);c.appendChild(b);
  new MutationObserver(function(){if(!root.classList.contains("lp-full")&&editing){if(dirty&&confirm("لديك تعديلات غير محفوظة في العرض. حفظها الآن؟"))save();edit(false);p.hidden=true;}}).observe(root,{attributes:true,attributeFilter:["class"]});
  function load(key){curKey=key;ovr={};dirty=false;if(editing)edit(false);p.hidden=true;collect();var my=++seq;
    var ok=!!(C()&&C().ok());role(ok);if(!ok){prefs={q:1,c:1};try{var lv=JSON.parse(localStorage.getItem("qd:fs")||"null");if(lv&&typeof lv==="object")prefs={q:+lv.q||1,c:+lv.c||1};}catch(e){}applyP();if(root.classList.contains("lp-full"))fitSoon();
      if(window.STP&&STP.ready)STP.ready.then(function(){if(my===seq&&C()&&C().ok())load2(key,my);});return;}
    load2(key,my);}
  function role(st){b.hidden=false;p.querySelector(".qed-only").hidden=!st;p.querySelector(".h b").textContent=st?"✏️ أدوات المعلم":"🔠 حجم الخط";
    p.querySelector(".qed-note").textContent=st?"🔒 الإعدادات والتعديلات تُحفظ في حسابك أنت فقط، ولا تظهر لأي معلم آخر أو للطلاب.":"يُحفظ الحجم على هذا الجهاز.";
    b.innerHTML=st?'<span style="font-size:19px;line-height:1">✏️</span><small>المعلم</small>':'<span style="font-size:19px;line-height:1">🔠</span><small>الحجم</small>';
    b.title=st?"أدوات المعلم: حجم السؤال وتعديل نصوص العرض":"تكبير خط الأسئلة والخيارات";}
  function load2(key,my){role(true);
    C().get("qdprefs").then(function(v){if(my!==seq)return;prefs=v&&typeof v==="object"?{q:+v.q||1,c:+v.c||1}:{q:1,c:1};applyP();if(root.classList.contains("lp-full"))fitSoon();});
    C().get("qd:"+key).then(function(v){if(my!==seq||!v||typeof v!=="object")return;ovr=v;applyO();});}
  return {load:load};
})();
/* زر «الحصص» في أزرار العرض السفلية: يُظهر/يُخفي جدول توقيت الحصص */
(function(){var c=root.querySelector(".lp-ctrl");if(!c||c.querySelector("[data-clk]"))return;
  var b=document.createElement("button");b.type="button";b.className="lp-btn lp-afs";b.setAttribute("data-clk","");b.title="توقيت الحصص (إظهار/إخفاء)";b.setAttribute("aria-label","توقيت الحصص");
  b.innerHTML='<span style="font-size:19px;line-height:1">⏰</span><small>الحصص</small>';
  b.onclick=function(e){e.stopPropagation();sub();if(window.SCHOOLCLK)SCHOOLCLK.toggleTable();};
  var subd=false;function sub(){if(subd||!window.SCHOOLCLK)return;subd=true;SCHOOLCLK.onTable(function(on){b.classList.toggle("on",on);b.style.background=on?"#fde68a":"";});}
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",sub);else setTimeout(sub,0);window.addEventListener("load",sub);
  c.appendChild(b);})();
/* QED-JS-END */
/* DECK2-BEGIN */
/* DECK2: يبدأ العرض من أول سؤال فعلي، وأزرار: الأهداف، النص، المعجم، التشكيل */
var hid=[],SHOWI=false,TEXTSL=[],CURSL=[];
var INTRO_RE=/الأهداف|نواتج|التمهيد|التَّمْهيدُ|التمهيدُ|التهيئة|التَّهْيِئَةُ|^القراءة$|أقرأ النص|اقرأ النص في|أسلوب الأداء|مدخل إلى النص|أهم الأفكار|مهارات القراءة/;
var TEXT_RE=/^(النص|النصّ|النص القرآني|النص الشعري|النصّ الشعريّ|النصّ القرآنيّ)$/;
var QT={open:1,mcq:1,match:1,order:1,diagram:1,vocab:1,cols:1};
function calcHid(sl){CURSL=sl;hid=[];TEXTSL=[];SHOWI=false;var kid=root.classList.contains("kid"),fq=-1;
  sl.forEach(function(x,i){if(fq<0&&QT[x.t]&&!INTRO_RE.test(String(x.tag||"").trim()))fq=i;});
  sl.forEach(function(x,i){var h=0,tg=String(x.tag||"").trim();
    if(!kid&&fq>=0){if((x.t==="quran"||x.t==="abyat"||x.t==="text")&&TEXT_RE.test(tg)){h=2;TEXTSL.push(i);}
      else if(i<fq&&x.t!=="title"&&INTRO_RE.test(tg))h=1;}
    hid.push(h);});
  applyHid();}
function vis(i){return !hid[i]||(hid[i]===1&&SHOWI)||root.classList.contains("qed");}
function applyHid(){secs.forEach(function(s,i){s.classList.toggle("qd-hid",!vis(i));});}
function firstVis(){if(SHOWI||root.classList.contains("kid"))return 0;
  for(var i=0;i<secs.length;i++)if(vis(i)&&CURSL[i]&&CURSL[i].t!=="title")return i;return 0;}
function nv(i,d){for(var j=i+d;j>=0&&j<secs.length;j+=d)if(vis(j))return j;return -1;}
function visPos(){var n=0,p=0;for(var i=0;i<secs.length;i++)if(vis(i)){n++;if(i<=idx)p++;}return [Math.max(1,p),Math.max(1,n)];}
new MutationObserver(function(){applyHid();}).observe(root,{attributes:true,attributeFilter:["class"]});
function txtGroups(){var G=[];TEXTSL.forEach(function(i){var x=CURSL[i];
  if(x.t==="quran")G.push({title:x.h||x.tag||"النص القرآني",kind:"quran",items:(x.verses||[]).map(function(v){return {t:v[1],n:v[0]};})});
  else if(x.t==="abyat")G.push({title:x.h||x.tag||"النص الشعري",kind:"poem",items:(x.verses||[]).map(function(v){return {s:v};})});
  else G.push({title:x.h||x.tag||"النص",kind:"prose",items:(x.paras||[]).filter(function(p){return typeof p==="string";}).map(function(p){return {p:p};})});});
  return G.filter(function(g){return g.items.length;});}
var D2={},CTX={};
(function(){if(!ctrl||ctrl.querySelector("[data-d2]"))return;
  function mk(k,ic,lb,tt){var b=document.createElement("button");b.type="button";b.className="lp-btn lp-afs d2-b";b.setAttribute("data-d2",k);b.title=tt;b.setAttribute("aria-label",tt);
    b.innerHTML='<span style="font-size:20px;line-height:1">'+ic+'</span><small>'+lb+'</small>';ctrl.appendChild(b);D2[k]=b;return b;}
  mk("goals","🎯","الأهداف","إظهار الأهداف والتمهيد أو إخفاؤها").onclick=function(e){e.stopPropagation();SHOWI=!SHOWI;this.classList.toggle("on",SHOWI);applyHid();
    if(SHOWI){var f=-1;hid.forEach(function(h,i){if(f<0&&h===1)f=i;});if(f>=0){idx=f;step=0;}}else if(!vis(idx)){idx=firstVis();step=0;}
    paint(0);if(typeof fitSoon==="function")fitSoon();};
  mk("text","📜","النص","النص مع شرح كل آية أو بيت أو فقرة").onclick=function(e){e.stopPropagation();var c=CTX,P=c.P||{};
    if(!window.SHARH)return;if(P.sharh&&P.sharh.length)return SHARH.open(P.sharh,c.name||"");var g=txtGroups();if(g.length)SHARH.open(g,c.name||"");};
  var db=mk("dict","📖","المعجم","البحث عن معنى كلمة في المعجم الوسيط");
  var pop=document.createElement("form");pop.className="d2-dict";pop.hidden=true;
  pop.innerHTML='<b>📖 المعجم الوسيط</b><div class="d2-row"><input type="search" placeholder="اكتب الكلمة…" aria-label="الكلمة" dir="rtl" autocomplete="off"><button type="submit">ابحث</button></div><small>يفتح معنى الكلمة في «المعجم الوسيط» على موقع معجم المعاني.</small>';
  root.appendChild(pop);
  ["click","pointerdown","pointerup","keydown"].forEach(function(t){pop.addEventListener(t,function(e){e.stopPropagation();});});
  db.onclick=function(e){e.stopPropagation();pop.hidden=!pop.hidden;db.classList.toggle("on",!pop.hidden);if(!pop.hidden)setTimeout(function(){pop.querySelector("input").focus();},30);};
  pop.onsubmit=function(e){e.preventDefault();var w=pop.querySelector("input").value.trim().replace(/[ً-ْٰـ]/g,"");if(!w)return;
    window.open("https://www.almaany.com/ar/dict/ar-ar/"+encodeURIComponent(w)+"/?c="+encodeURIComponent("المعجم الوسيط"),"_blank","noopener");};
  mk("skills","🧩","المهارات","المهارات النحوية: أسماء الإشارة، الموصولة، الضمائر، النواسخ، حروف الجر والعطف، النداء، الاستفهام").onclick=function(e){e.stopPropagation();if(window.ARSK)ARSK.open(root);};
  mk("tsk","ـَـ","التشكيل","إظهار التشكيل أو إخفاؤه").onclick=function(e){e.stopPropagation();if(window.TSK){TSK.toggle();this.classList.toggle("on",TSK.off());}};
  document.addEventListener("click",function(e){if(!pop.hidden&&!pop.contains(e.target)&&e.target!==db&&!db.contains(e.target)){pop.hidden=true;db.classList.remove("on");}});
})();
function updBtns(){CTX=window.__QDP||{};window.__QDP=null;if(!D2.goals)return;var kid=root.classList.contains("kid"),P=CTX.P||{};
  D2.goals.hidden=!hid.some(function(h){return h===1;});D2.goals.classList.remove("on");
  D2.text.hidden=kid||!((P.sharh&&P.sharh.length)||TEXTSL.length);
  D2.dict.hidden=kid;
  D2.tsk.hidden=!/^#\/arabic(\/|$)/.test(location.hash);D2.skills.hidden=D2.tsk.hidden;var so=root.querySelector(".sk-ov");if(so)so.remove();if(window.TSK)D2.tsk.classList.toggle("on",TSK.off());
  var pp=root.querySelector(".d2-dict");if(pp){pp.hidden=true;D2.dict.classList.remove("on");}
}
/* DECK2-END */
window.QD={load:function(key){var d=(window.QD_DATA||{})[key];if(!d)return false;
  /* الإجابة الصحيحة لا تكون دائمًا الخيار الأول: نوزّع موضعها بشكل ثابت */
  if(!d.__mixed){d.__mixed=1;var SQ=[1,3,0,2,2,0,3,1,3,1,2,0,0,2,1,3],si=key.length;d.forEach(function(sl){if(sl.t!=="mcq"||sl.a!==0||!sl.choices||sl.choices.length<3||sl.big)return;
    var k=SQ[(si++)%SQ.length]%sl.choices.length;if(!k)return;
    var v=sl.choices.splice(0,1)[0];sl.choices.splice(k,0,v);sl.a=k;});}root.classList.toggle("kid",/^g[1-3]-/.test(key));build(d);QE.load(key);return true;}};
})();
