/* MAKER-BEGIN */
/* ===== صانع الألعاب التفاعلية: تسعة قوالب تُفتح بأسئلة الدرس الحالي ===== */
window.MAKER=(function(){
  function key(s){var h=0;s=String(s||"");for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return (h>>>0).toString(36);}
  function seed(pool,name){var out=[],seen={};(pool||[]).forEach(function(q){if(!q||!q.q||!q.c||q.c.length<2||seen[q.q])return;seen[q.q]=1;
    var c=q.c.slice(),a=+q.a||0;if(a>=4){var t=c[a];c.splice(a,1);c.splice(0,0,t);a=0;}c=c.slice(0,4);out.push({q:String(q.q),options:c.map(String),correct:a});});
    return {key:out.length?key(name):"",title:name||"",questions:out.slice(0,40)};}
  function open(pool,name){var old=document.getElementById("gmk");if(old)old.remove();window.__MAKER_SEED=seed(pool,name);
    var el=document.createElement("div");el.id="gmk";el.setAttribute("role","dialog");el.setAttribute("aria-label","صانع الألعاب التفاعلية");
    el.innerHTML='<div class="gmk-top"><button type="button" class="gmk-x" aria-label="إغلاق">×</button><b>🎮 صانع الألعاب التفاعلية</b><span></span></div><iframe src="games/maker/index.html" title="صانع الألعاب التفاعلية" allow="fullscreen; clipboard-write" allowfullscreen></iframe>';
    el.querySelector("span").textContent=name||"";document.body.appendChild(el);document.documentElement.classList.add("lp-lock");
    function close(){el.remove();document.removeEventListener("keydown",kd);if(!document.getElementById("gmh"))document.documentElement.classList.remove("lp-lock");}
    function kd(e){if(e.key==="Escape"&&!document.fullscreenElement)close();}
    el.querySelector(".gmk-x").onclick=close;document.addEventListener("keydown",kd);}
  return {open:open};})();
/* MAKER-END */