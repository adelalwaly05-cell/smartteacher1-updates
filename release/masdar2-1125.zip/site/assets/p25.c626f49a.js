
/* ===== زر الرجوع في المتصفح/الجوال: يغلق النافذة المفتوحة (عرض، لعبة، سبورة…) بدل مغادرة الصفحة ===== */
(function(){
if(/[?&]wbonly=1/.test(location.search))return;var SEL=".lp-full,#mlg,#tug,#mm,#cls,#sh,#wb,#gmh,.gx:not(#lvs),.el-lb,#crt,#ev,#flp,#atl",depth=0,ignore=0,busy=false;
function list(){return document.querySelectorAll(SEL);}
function sync(){if(busy)return;var n=list().length;
  if(n>depth){while(depth<n){depth++;try{history.pushState({ov:depth},"",location.href);}catch(e){}}}
  else if(n<depth){var k=depth-n;depth=n;if(history.state&&history.state.ov){ignore+=k;history.go(-k);}}}
var t=null;new MutationObserver(function(){clearTimeout(t);t=setTimeout(sync,30);}).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:["class"]});
window.addEventListener("popstate",function(){if(ignore>0){ignore--;return;}var L=list();if(!L.length||depth===0)return;
  depth--;busy=true;var top=L[L.length-1];
  if(top.classList.contains("el-lb"))top.remove();
  else{var b=top.querySelector(".lp-x,[data-a=\"x\"],.gh-x,[data-m=\"x\"],.cl-x");if(b)b.click();else top.remove();}
  setTimeout(function(){busy=false;depth=Math.min(depth,list().length);},60);});
})();
