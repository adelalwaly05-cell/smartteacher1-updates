/* UI3-BEGIN */
/* ===== إجابات الكتب العامة (يضيفها المسؤول من «عرض الكتاب» فتظهر لكل الزوار) ===== */
window.BOOKANS=(function(){var C={};
  function http(){return location.protocol.indexOf("http")===0;}
  function load(B){if(!B||!B.id||!B.pages||!http())return Promise.resolve(false);if(C[B.id])return C[B.id];
    C[B.id]=fetch("portal/api/index.php?a=bkans_get&b="+encodeURIComponent(B.id)+"&_="+Date.now(),{cache:"no-store",credentials:"same-origin"}).then(function(r){return r.json();}).then(function(j){
      var d=(j&&j.data)||{},ch=false;
      B.pages.forEach(function(p){var add=d[p.src];var base=(p.items||[]).filter(function(it){return !it.g;});
        if(add&&add.length){p.items=base.concat(add.map(function(it){it.g=1;return it;}));ch=true;}});return ch;}).catch(function(){return false;});
    return C[B.id];}
  function save(B){var d={};B.pages.forEach(function(p){var g=(p.items||[]).filter(function(it){return it.g;}).map(function(it){var o={};for(var k in it)if(k!=="g")o[k]=it[k];return o;});if(g.length)d[p.src]=g;});
    return STP.post("bkans_save",{b:B.id,data:JSON.stringify(d)});}
  function isAdmin(){return !!(window.STP&&STP.me&&STP.me.role==="admin");}
  return {load:load,save:save,isAdmin:isAdmin};})();

/* ===== الاختبار التفاعلي بملء الشاشة ===== */
window.QZFULL=(function(){var bar=null,cur=null;
  function off(panel){if(bar){bar.remove();bar=null;}var p=panel||cur;if(p){p.classList.remove("qz-full");}cur=null;
    if(!document.querySelector(".lp-full,#gmh,#cls,#sh,#wb,.gx,#mlg,#tug,#mm,#bk,#ev,#crt,#atl,#flp"))document.documentElement.classList.remove("lp-lock");
    document.removeEventListener("keydown",kd);if(window.LBAR&&LBAR.restore&&p)LBAR.restore();}
  function kd(e){if(e.key==="Escape"&&cur&&!document.querySelector(".gx,#mlg"))close();}
  function close(){var p=cur;off(p);if(p)p.innerHTML="";}
  function on(panel,name){cur=panel;panel.classList.add("qz-full");panel.scrollTop=0;document.documentElement.classList.add("lp-lock");if(window.LBAR)LBAR.hide();
    bar=document.createElement("div");bar.id="qzf-bar";bar.innerHTML='<button type="button" aria-label="إغلاق الاختبار">×</button><b>📝 اختبار تفاعلي</b><span></span>';
    bar.querySelector("span").textContent=name||"";bar.querySelector("button").onclick=close;document.body.appendChild(bar);document.addEventListener("keydown",kd);}
  window.addEventListener("hashchange",function(){if(cur)off(cur);});
  return {on:on,off:off,close:close};})();

/* ===== السبورة العائمة: أيقونة صغيرة في كل صفحات الموقع ===== */
(function(){
  function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v);}catch(e){}return null;}
  var WBO=/[?&]wbonly=1/.test(location.search),wbSeen=false;function init(){if(document.getElementById("wbfab"))return;
    var b=document.createElement("button");b.type="button";b.id="wbfab";b.title="السبورة (اضغط لفتحها، واسحب لتحريك الأيقونة)";b.setAttribute("aria-label","السبورة");
    b.innerHTML='<span>✏️</span><small>السبورة</small>';document.body.appendChild(b);
    var pos=null;try{pos=JSON.parse(ls("wbfab:pos")||"null");}catch(e){}
    function place(x,y){x=Math.max(4,Math.min(innerWidth-b.offsetWidth-4,x));y=Math.max(4,Math.min(innerHeight-b.offsetHeight-4,y));b.style.left=x+"px";b.style.top=y+"px";b.style.right="auto";b.style.bottom="auto";}
    if(pos)setTimeout(function(){place(pos.x,pos.y);},0);
    var sx,sy,ox,oy,mv=false,dn=false;
    b.addEventListener("pointerdown",function(e){dn=true;mv=false;var r=b.getBoundingClientRect();sx=e.clientX;sy=e.clientY;ox=r.left;oy=r.top;b.setPointerCapture(e.pointerId);});
    b.addEventListener("pointermove",function(e){if(!dn)return;if(!mv&&Math.hypot(e.clientX-sx,e.clientY-sy)<6)return;mv=true;place(ox+e.clientX-sx,oy+e.clientY-sy);});
    b.addEventListener("pointerup",function(){if(!dn)return;dn=false;if(mv){var r=b.getBoundingClientRect();ls("wbfab:pos",JSON.stringify({x:r.left,y:r.top}));return;}open();});
    function open(){if(!window.WB)return;var L=window.__lesson,key=L&&L.title?L.title:"السبورة العامة";WB.open(key,L&&L.title?L.title:"السبورة");
      var w=document.getElementById("wb");if(w)w.style.zIndex="2147483350";sync();}
    function sync(){var o=!!document.getElementById("wb");b.hidden=o;if(WBO){if(o)wbSeen=true;else if(wbSeen){wbSeen=false;try{parent.postMessage("wb-close","*");}catch(e){}}}}if(WBO){document.documentElement.classList.add("wbonly");var wst=document.createElement("style");wst.textContent="html.wbonly body>*:not(#wb){display:none!important}html.wbonly,html.wbonly body{background:#fff}";document.head.appendChild(wst);setTimeout(function(){open();try{parent.postMessage("wb-ready","*");}catch(e){}},60);}
    new MutationObserver(sync).observe(document.body,{childList:true});sync();
    window.addEventListener("resize",function(){var r=b.getBoundingClientRect();if(r.width&&b.style.left)place(r.left,r.top);});}
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();

/* ===== شريط إخباري ثابت أعلى «عرض الدرس»: عنوان الدرس والتاريخ يتحركان نحو اليمين ===== */
(function(){var tk=null,off=false,lastKey="";
  function deck(){return document.querySelector("#qd.lp-full,#lp-deck.lp-full,.lp-full");}
  function info(){var L=window.LBAR&&LBAR.info?LBAR.info():null,D=window.LBAR&&LBAR.dates?LBAR.dates():{};
    var t=(L&&L[0])||(window.__lesson&&__lesson.title)||"",s=(L&&L[1])||"";return [t,s,D.w||"",D.h?"🌙 "+D.h:"",D.g?"📅 "+D.g:""].filter(Boolean);}
  function esc2(x){return String(x).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
  function build(){var I=info();if(!I.length)return;tk=document.createElement("div");tk.id="ltk";tk.setAttribute("role","marquee");tk.setAttribute("aria-label",I.join(" – "));
    var one='<span class="ltk-run">'+I.map(function(x,i){return '<b class="'+(i===0?'t':i===1?'s':'d')+'">'+esc2(x)+'</b>';}).join('<i>✦</i>')+'<i>✦</i></span>';
    tk.innerHTML='<span class="ltk-lb">📘 الدرس</span><div class="ltk-vp"><div class="ltk-tr">'+one+one+'</div></div><button type="button" class="ltk-x" aria-label="إخفاء الشريط" title="إخفاء الشريط">×</button>';
    document.body.appendChild(tk);document.documentElement.classList.add("lp-tk");
    var tr=tk.querySelector(".ltk-tr"),run=tr.firstChild;
    function speed(){var w=run.getBoundingClientRect().width||800;tr.style.animationDuration=Math.max(14,w/70)+"s";
      /* نكرر النص حتى يغطي الشريط كله دائمًا */
      var vp=tk.querySelector(".ltk-vp").clientWidth;while(tr.children.length<12&&tr.scrollWidth<vp*2+w)tr.appendChild(run.cloneNode(true));
      if(tr.children.length%2)tr.appendChild(run.cloneNode(true));}
    requestAnimationFrame(speed);
    tk.querySelector(".ltk-x").onclick=function(){off=true;drop();};
    setTimeout(function(){window.dispatchEvent(new Event("resize"));},30);}
  function drop(){if(tk){tk.remove();tk=null;}document.documentElement.classList.remove("lp-tk");setTimeout(function(){window.dispatchEvent(new Event("resize"));},30);}
  setInterval(function(){var d=deck();if(d&&!tk&&!off)build();else if(!d){if(tk)drop();off=false;}
    else if(tk){var k=info().join("|");if(lastKey&&k!==lastKey){drop();build();}lastKey=k;}},600);
})();
/* UI3-END */