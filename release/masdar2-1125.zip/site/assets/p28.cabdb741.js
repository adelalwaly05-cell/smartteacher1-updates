/* EXAMS-BEGIN: «الاختبارات النهائية» – نماذج الاختبار النهائي التجريبي وفق دليل التقييم (عرض + طباعة) */
window.EXAMS=(function(){
  var GN=["","الأول","الثاني","الثالث","الرابع","الخامس","السادس","السابع","الثامن","التاسع","العاشر","الحادي عشر","الثاني عشر"];
  var AN="٠١٢٣٤٥٦٧٨٩",LT="أبتثجحخدذرزسشصضطظعغفقكلمنهوي";
  function an(n){return String(n).replace(/\d/g,function(d){return AN[d];});}
  function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
  var IDX=null,C={};
  function idx(){if(!IDX)IDX=fetch("exams/index.json",{cache:"no-cache"}).then(function(r){if(!r.ok)throw 0;return r.json();}).catch(function(){IDX=null;return {};});return IDX;}
  function load(g,m){var k=g+"-"+m;if(!C[k])C[k]=fetch("exams/g"+k+".json",{cache:"no-cache"}).then(function(r){if(!r.ok)throw 0;return r.json();}).catch(function(e){delete C[k];throw e;});return C[k];}
  function blank(t){return esc(t).replace(/_{2,}|ـ{3,}|\.{4,}|…{2,}/g,'<span class="xm-gap"></span>');}
  function mk(m){return '<span class="xm-m">('+an(String(m).replace(/^0?\.5$/,"½").replace(/^0?\.25$/,"¼"))+')</span>';}
  function lines(n){n=Math.max(1,Math.min(20,+n||1));return '<div class="xm-ln">'+Array(n+1).join('<i></i>')+'</div>';}
  function vs(V,cls){return V&&V.length?'<div class="xm-vs'+(cls?' '+cls:'')+'">'+V.map(function(v){return '<div><span>'+esc(v[0])+'</span><span>'+esc(v[1]||"")+'</span></div>';}).join("")+'</div>':'';}
  /* نص الإجابة: كل سطر في سطر، والسطر الذي يبدأ بـ§ عنوان داخلي */
  function atext(t){return String(t==null?"":t).split("\n").map(function(l){return l.charAt(0)==="§"?'<b class="xm-al">'+esc(l.slice(1))+'</b>':'<span>'+esc(l)+'</span>';}).join("");}
  function ansBody(it){return (it.a!=null&&typeof it.a!=="number"?atext(it.a):"")+vs(it.averses);}
  function nlines(it){if(it.lines)return it.lines;var t=String(typeof it.a==="string"?it.a:"").replace(/§[^\n]*/g,"");if(it.averses)return it.averses.length+1;return Math.max(1,Math.min(14,Math.ceil(t.length/75)));}
  /* منطقة الإجابة: I = تفاعلية على الشاشة (تظهر وتختفي بالضغط) */
  function rv(it,A,I,n){var b=ansBody(it);if(!b)return A?'':lines(n||nlines(it));
    if(I)return '<div class="xm-rv" role="button" tabindex="0" title="اضغط لإظهار الإجابة أو إخفائها">'+lines(n||nlines(it))+'<div class="xm-a">'+b+'</div><span class="xm-tip">👆 اضغط لإظهار الإجابة</span></div>';
    return A?'<div class="xm-a">'+b+'</div>':lines(n||nlines(it));}
  function choices(c,a,A,I){return '<div class="xm-ch'+(I?' xm-pick':'')+'">'+(c||[]).map(function(x,j){var ok=j===a;
      return '<span'+(ok?' data-ok="1"':'')+' class="'+(A&&!I&&ok?'ok':'')+'"'+(I?' role="button" tabindex="0"':'')+'><i></i><em>'+"أبجدهوزحطي".charAt(j)+'- </em>'+esc(x)+'</span>';}).join("")+'</div>';}
  function subs(S,A,I){return '<div class="xm-subs">'+S.map(function(s,j){var h='<div class="xm-sub"><div class="xm-q"><b>'+"أبجدهوزحطي".charAt(j)+'-</b> <span>'+blank(s.q||"")+'</span></div>';
      if(s.k==="tf")h+='<div class="xm-tf'+(I?' xm-pick':'')+'" data-a="'+esc(s.a||"")+'">'+['✓','✗'].map(function(m){var ok=m===s.a;return '<span'+(ok?' data-ok="1"':'')+' class="'+(A&&!I&&ok?'ok':'')+'"'+(I?' role="button" tabindex="0"':'')+'>( '+m+' )</span>';}).join("")+'</div>';
      else if(s.choices)h+=choices(s.choices,s.a,A,I);
      return h+'</div>';}).join("")+'</div>';}
  function item(it,i,A,I){var nb=it.nonum;var h='<div class="xm-it"><div class="xm-q">'+(nb?'':'<b>'+(it.n?an(it.n):(it.k==="topic"?an(i+1):LT[i%LT.length]))+'-</b> ')+'<span>'+blank(it.q||"")+'</span>'+(it.m?mk(it.m):'')+'</div>';
    if(it.passage)h+='<div class="xm-ps"><div class="xm-pr">'+it.passage.map(function(p){return '<p>'+esc(p)+'</p>';}).join("")+'</div></div>';
    if(it.x)h+='<div class="xm-x">'+atext(it.x)+'</div>';h+=vs(it.qverses);
    if(it.subs)return h+subs(it.subs,A,I)+'</div>';
    if(it.k==="mcq"){h+=choices(it.choices,it.a,A,I);}
    else if(it.k==="topics"){h+='<ol class="xm-tp">'+(it.topics||[]).map(function(t){return '<li>'+esc(t)+'</li>';}).join("")+'</ol>'+rv(it,A,I,it.lines||10);}
    else if(it.k==="topic"){if(A||I)h+=rv(it,A,I,3);}
    else{h+=rv(it,A,I);}
    return h+'</div>';}
  function passage(P){if(!P)return "";var h='<div class="xm-ps">'+(P.title?'<div class="xm-pt">'+esc(P.title)+'</div>':'');
    if(P.verses&&P.verses.length)h+=vs(P.verses);
    if(P.paras&&P.paras.length)h+=(P.kind==="quran"||/﴿/.test(P.paras.join(""))?'<div class="xm-qr">':'<div class="xm-pr">')+P.paras.map(function(x){return '<p>'+esc(x)+'</p>';}).join("")+'</div>';
    return h+(P.ref?'<div class="xm-ref">'+esc(P.ref)+'</div>':'')+'</div>';}
  function sh(S){var h=String(S.h||"");if(S.sk){var i=h.lastIndexOf(": "+S.sk);if(i>=0)h=h.slice(0,i)+":";}return h;}
  function ml(m){m=+m;return m===2?'درجتان':m===1?'درجة واحدة':(m>2&&m<11?an(m)+' درجات':an(String(m).replace(/^0?\.5$/,"½"))+' درجة');}
  function sec(S,A,I){var h='<section class="xm-sec'+(S.lvl===1?' xm-l1':'')+'"><div class="xm-sh"><b>'+esc(sh(S))+'</b>'+(S.marks?'<span>( '+ml(S.marks)+' )</span>':'')+'</div>';
    if(S.intro)h+='<div class="xm-in">'+atext(S.intro)+'</div>';h+=passage(S.passage);
    if(S.dictation){var D={a:'§'+(S.dlabel||'نص الإملاء (يُملى على الطالب):')+'\n'+S.dictation+(S.tnote&&!S.items.length?'':''),lines:Math.ceil(String(S.dictation).length/70)+1};
      h+='<div class="xm-it"><div class="xm-q"><span>اكتب ما يُملى عليك:</span></div>'+rv(D,A,I)+'</div>';}
    if(S.note)h+='<div class="xm-in">'+esc(S.note)+'</div>';
    h+=(S.items||[]).map(function(it,i){return item(it,i,A,I);}).join("");
    if(!A&&!I&&(S.items||[]).some(function(it){return it.k==="topic";}))h+=lines(wlines(S));
    if(S.tnote&&(A||I))h+=I?'<div class="xm-tn"><div class="xm-rv xm-rvn" role="button" tabindex="0"><span class="xm-tip">📋 '+esc(S.tlabel||"ملاحظات التصحيح")+' (للمعلم) – اضغط للعرض</span><div class="xm-a">'+atext(S.tnote)+'</div></div></div>':'<div class="xm-a xm-tnp">'+atext(S.tnote)+'</div>';
    return h+'</section>';}
  /* تقدير ارتفاع القسم بالأسطر لتوزيع الأقسام على صفحات A4 */
  function L(t,w){return Math.max(1,Math.ceil(String(t||"").length/(w||85)));}
  function estIt(it,A,I){var n=L(it.q,80)+(it.passage?it.passage.reduce(function(a,p){return a+L(p,90);},0)+1:0)+(it.x?String(it.x).split("\n").length:0)+(it.qverses?it.qverses.length:0);
    if(it.subs)it.subs.forEach(function(s){n+=L(s.q,80)+(s.choices?Math.ceil(s.choices.length/2):1);});
    else if(it.k==="mcq")n+=Math.ceil((it.choices||[]).length/2)+.3;
    else if(A&&!I){var b=String(typeof it.a==="string"?it.a:"");n+=b.split("\n").reduce(function(a,l){return a+L(l,85);},0)+(it.averses?it.averses.length:0);}
    else n+=it.k==="topic"?(I?3:0):nlines(it);
    return n+.4;}
  function estSec(S,A,I){var n=1.6+(S.intro?L(S.intro,85):0);var P=S.passage;if(P){n+=1+(P.verses?P.verses.length*1.1:0)+(P.paras?P.paras.reduce(function(a,p){return a+L(p,80)*1.15;},0):0);}
    if(S.dictation)n+=2+(A&&!I?L(S.dictation):Math.ceil(String(S.dictation).length/70)+1);
    (S.items||[]).forEach(function(it){n+=estIt(it,A,I);});if(!A&&!I&&(S.items||[]).some(function(it){return it.k==="topic";}))n+=wlines(S);return n;}
  function wlines(S){var t=String(S.intro||"").replace(/[٠-٩]/g,function(d){return "٠١٢٣٤٥٦٧٨٩".indexOf(d);}),m=t.match(/(\d+)\)?\s*(أسطر|سطر)/);if(m)return Math.min(20,+m[1]);var W={"خمسة":5,"ستة":6,"ثمانية":8,"عشرة":10,"اثني عشر":12,"ستة عشر":16,"ثمانية عشر":18,"عشرين":20};for(var k in W)if(t.indexOf(k+" سطر")>=0||t.indexOf(k+" أسطر")>=0)return W[k];return 12;}
  function bare(S){return S.lvl===1&&!(S.items&&S.items.length)&&!S.passage&&!S.dictation&&!S.intro;}
  function pages(E,A,I){var CAP=33,PG=[],cur=null,used=0,pend="";
    function np(){cur=[];PG.push(cur);used=0;}
    function put(h,n){cur.push(h);used+=n;}
    (E.papers||[]).forEach(function(P,pi){np();if(pi===0){put("@HEAD@",7);}
      put('<div class="xm-pp"><span>'+esc(P.name||"")+'</span>'+(P.marks?'<span>( '+an(P.marks)+' درجة )</span>':'')+'</div>',1.6);
      (P.sections||[]).forEach(function(S){var h=sec(S,A,I);
        if(bare(S)){pend+=h;return;}
        var n=estSec(S,A,I)+(pend?1.8:0),empty=cur.every(function(x){return x==="@HEAD@"||/^<div class="xm-pp"/.test(x);});
        var force=S.lvl===2&&!!S.passage&&!empty, small=n<=12&&used+n<=CAP;
        if(!empty&&(force||!small))np();
        put(pend+h,n);pend="";});});
    return PG;}
  function html(E,A,I){var g=+E.grade,hd='<header class="xm-hd"><div><b>دولة الكويت</b><br>وزارة التربية<br>الإدارة العامة لمنطقة ........ التعليمية<br>المدرسة: ....................</div>'+
      '<div class="c"><h1>'+esc(E.title||"نموذج الاختبار النهائي التجريبي")+'</h1><div>اللغة العربية – الصف '+(GN[g]||g)+'</div>'+(A?'<div class="xm-key">نموذج الإجابة</div>':'')+'</div>'+
      '<div>العام الدراسي ٢٠٢٦ / ٢٠٢٧م<br>'+esc(E.term?String(E.term).replace(/\s*\d{4}\/\d{4}.*/,""):"الفصل الدراسي الأول")+(E.time?'<br>الزمن: '+esc(E.time):'')+'<br>الدرجة الكلية: '+an(E.total||"")+'</div></header>'+
      '<div class="xm-st"><span>اسم الطالب: ......................................................</span><span>الصف: ..........</span><span>الدرجة: ( ........ / '+an(E.total||"")+' )</span></div>';
    var end='<div class="xm-end">انتهت الأسئلة – مع تمنياتنا لكم بالتوفيق والنجاح</div>';
    var nw=(E.papers||[]).some(function(P){return (P.sections||[]).some(function(S){return S.sk;});});
    if(!nw){var h='<div class="xm-doc">'+hd;(E.papers||[]).forEach(function(P){h+='<div class="xm-pp"><span>'+esc(P.name||"")+'</span>'+(P.marks?'<span>( '+an(P.marks)+' درجة )</span>':'')+'</div>'+(P.sections||[]).map(function(S){return sec(S,A,I);}).join("");});return h+end+'</div>';}
    var PG=pages(E,A,I);
    return '<div class="xm-doc xm-pgd">'+PG.map(function(p,i){return '<div class="xm-page">'+p.join("").replace("@HEAD@",hd)+(i===PG.length-1?end:'')+'<div class="xm-pn">صفحة '+an(i+1)+' من '+an(PG.length)+'</div></div>';}).join("")+'</div>';}
  /* التفاعل: الضغط على الإجابة يظهرها ويخفيها، والاختيار من متعدد يُلوَّن بالأخضر ✓ أو الأحمر ✗ */
  function interact(w){if(w.__xi)return;w.__xi=1;
    function act(t){var r=t.closest(".xm-rv");if(r){r.classList.toggle("on");return true;}
      var o=t.closest(".xm-pick>span");if(o){var box=o.parentNode,was=o.classList.contains("ok")||o.classList.contains("bad");
        [].forEach.call(box.children,function(x){x.classList.remove("ok","bad");});
        if(!was)o.classList.add(o.hasAttribute("data-ok")?"ok":"bad");return true;}return false;}
    w.addEventListener("click",function(e){act(e.target);});
    w.addEventListener("keydown",function(e){if((e.key==="Enter"||e.key===" ")&&act(e.target))e.preventDefault();});}
  var CSS='.xm-doc{direction:rtl;font-family:Tajawal,Arial,sans-serif;color:#111;line-height:1.85;font-size:16px}'+
   '.xm-hd{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;border:2px solid #1f5f7a;border-radius:10px;padding:8px 12px;font-size:13.5px;font-weight:700}.xm-hd .c{text-align:center;flex:1}.xm-hd h1{margin:0;font-size:19px;color:#14465c}'+
   '.xm-key{display:inline-block;margin-top:2px;background:#1d4ed8;color:#fff;border-radius:8px;padding:0 12px}'+
   '.xm-st{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;margin:8px 0;font-weight:700;font-size:14px}'+
   '.xm-pp{display:flex;justify-content:space-between;background:#14465c;color:#fff;border-radius:8px;padding:4px 12px;margin:12px 0 6px;font-weight:800}'+
   '.xm-sec{margin:8px 0 10px;break-inside:auto}.xm-sh{display:flex;justify-content:space-between;gap:10px;border-bottom:2px solid #1f5f7a;padding-bottom:2px;margin-bottom:4px;color:#14465c}.xm-sh span{white-space:nowrap;font-weight:700}'+
   '.xm-in{font-weight:700;margin:3px 0}.xm-ps{border:1.4px solid #888;border-radius:8px;padding:6px 12px;margin:6px 0;break-inside:avoid}.xm-pt{text-align:center;font-weight:800;margin-bottom:2px}'+
   '.xm-pr p{margin:2px 0;text-align:justify}.xm-qr,.xm-vs{font-family:Amiri,"Traditional Arabic",serif;font-size:18px}.xm-qr p{text-align:justify;margin:2px 0}.xm-vs div{display:grid;grid-template-columns:1fr 1fr;gap:30px;text-align:center}.xm-ref{text-align:left;font-size:13px;color:#444}'+
   '.xm-it{margin:6px 0 4px;break-inside:avoid}.xm-q{display:flex;gap:6px;align-items:baseline}.xm-q>span:not(.xm-m){flex:1 1 auto;min-width:0}.xm-q>.xm-m{flex:none}.xm-m{white-space:nowrap;font-weight:700;color:#14465c;margin-right:auto;padding-right:8px}'+
   '.xm-ch{display:grid;grid-template-columns:1fr 1fr;gap:2px 24px;padding-right:22px}.xm-ch span i{display:inline-block;width:13px;height:13px;border:1.6px solid #333;border-radius:50%;margin-left:6px;vertical-align:-2px}.xm-ch span.ok{color:#1d4ed8;font-weight:800}.xm-ch span.ok i{background:#1d4ed8;border-color:#1d4ed8}'+
   '.xm-ln{padding-right:22px}.xm-ln i{display:block;border-bottom:1.4px dotted #555;height:28px}.xm-gap{display:inline-block;min-width:110px;border-bottom:1.4px dotted #555}'+
'.xm-l1>.xm-sh{background:#e8f1f7;border-radius:8px;padding:3px 10px;border-bottom:0;margin-top:10px;font-size:17px}.xm-x{padding-right:22px;font-weight:600}.xm-x span,.xm-a span{display:block}.xm-al{display:block;color:#14465c;margin-top:2px}.xm-ch em{font-style:normal;font-weight:700}'+'.xm-subs{padding-right:14px}.xm-sub{margin:3px 0}.xm-tf{display:flex;gap:14px;padding-right:22px}.xm-tf span{border:1.5px solid #cbd5e1;border-radius:10px;padding:0 12px}.xm-tf span.ok{color:#1d4ed8;border-color:#1d4ed8;font-weight:800}.xm-tnp{border:1px dashed #1d4ed8;border-radius:8px;padding:4px 10px;margin-top:4px}.xm-vs span{display:block}'+
   '.xm-a{color:#1d4ed8;font-weight:700;padding-right:22px;white-space:normal}.xm-pn{position:absolute;bottom:8px;left:0;right:0;text-align:center;font-size:12px;color:#64748b}.xm-page>.xm-sec:first-child,.xm-page>.xm-pp:first-child{margin-top:0}'+
   '@media print{.xm-page{break-after:page;page-break-after:always;position:relative;min-height:265mm}.xm-page:last-child{break-after:auto;page-break-after:auto}.xm-pn{display:none}}'+
   '.xm-tp{margin:2px 0;padding-right:40px}.xm-end{text-align:center;font-weight:800;margin-top:14px;border-top:1.5px solid #999;padding-top:6px}';
  function printIt(E,A){var doc='<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>'+esc((E.title||"")+" – الصف "+(GN[E.grade]||""))+'</title>'+
      '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal:wght@500;700;800&family=Amiri:wght@400;700&display=swap"><style>@page{size:A4;margin:12mm}body{margin:0}'+CSS+'.pb{position:fixed;top:10px;left:10px;padding:8px 18px;font:800 15px Tajawal,sans-serif;border:0;border-radius:10px;background:#14465c;color:#fff;cursor:pointer}@media print{.pb{display:none}}</style></head><body><button class="pb">🖨 طباعة</button>'+html(E,A)+'</body></html>';
    var w=null;try{w=window.open("","_blank");}catch(e){}
    if(w&&w.document){w.document.open();w.document.write(doc);w.document.close();try{w.document.querySelector(".pb").onclick=function(){w.print();};}catch(e){}
      var go=function(){try{w.focus();w.print();}catch(e){}};if(w.document.fonts&&w.document.fonts.ready)w.document.fonts.ready.then(function(){setTimeout(go,300);});else setTimeout(go,800);return;}
    var f=document.createElement("iframe");f.style.cssText="position:fixed;width:0;height:0;border:0;left:-9999px";document.body.appendChild(f);var d=f.contentWindow.document;d.open();d.write(doc);d.close();
    setTimeout(function(){try{f.contentWindow.focus();f.contentWindow.print();}catch(e){}setTimeout(function(){f.remove();},60000);},900);}
  function css(){if(document.getElementById("xm-css"))return;var s=document.createElement("style");s.id="xm-css";s.textContent=CSS+
    '.xm-bar{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 12px}.xm-bar button{border:2px solid #14465c;background:#fff;color:#14465c;border-radius:12px;padding:8px 14px;font:800 15px Tajawal,sans-serif;cursor:pointer}.xm-bar button.on{background:#14465c;color:#fff}'+
    '.xm-wrap{background:#fff;border-radius:14px;box-shadow:0 4px 18px rgba(0,0,0,.08);padding:16px;max-width:900px;margin:0 auto;overflow:hidden}.xm-wrap .xm-a{display:none}.xm-wrap.ans .xm-a{display:block}.xm-wrap:not(.ans) .xm-ch span.ok{color:inherit;font-weight:inherit}.xm-wrap:not(.ans) .xm-ch span.ok i{background:none;border-color:#333}'+
'.xm-rv{position:relative;cursor:pointer;border-radius:10px;padding:2px 0;transition:background .15s}.xm-rv:hover{background:#f0f9ff}.xm-wrap .xm-rv.on .xm-a{display:block}.xm-wrap .xm-rv.on .xm-ln,.xm-wrap.ans .xm-rv .xm-ln{display:none}.xm-rv.on{background:#eff6ff}'+'.xm-tip{position:absolute;left:6px;top:4px;font-size:12px;font-weight:700;color:#0e7490;background:#ecfeff;border:1px solid #a5f3fc;border-radius:8px;padding:0 6px;opacity:0;transition:opacity .2s;pointer-events:none}.xm-rv:hover .xm-tip{opacity:1}.xm-rv.on .xm-tip,.xm-wrap.ans .xm-tip{display:none}'+'.xm-rvn{padding:4px 8px;border:1.4px dashed #94a3b8}.xm-rvn .xm-tip{position:static;opacity:1;display:inline-block;pointer-events:auto}.xm-wrap.ans .xm-rvn .xm-tip,.xm-rvn.on .xm-tip{display:inline-block}'+'.xm-pick>span{cursor:pointer;border-radius:10px;padding:2px 8px;border:1.6px solid transparent;transition:background .15s,border-color .15s}.xm-pick>span:hover{background:#f1f5f9}'+'.xm-wrap .xm-pick>span.ok{background:#dcfce7!important;border-color:#16a34a!important;color:#166534!important;font-weight:800!important}.xm-wrap .xm-pick>span.ok i{background:#16a34a!important;border-color:#16a34a!important}.xm-pick>span.ok:after{content:" ✓";color:#16a34a;font-weight:900;font-size:18px}'+'.xm-wrap .xm-pick>span.bad{background:#fee2e2!important;border-color:#dc2626!important;color:#991b1b!important}.xm-wrap .xm-pick>span.bad i{background:#dc2626!important;border-color:#dc2626!important}.xm-pick>span.bad:after{content:" ✗";color:#dc2626;font-weight:900;font-size:18px}'+'.xm-wrap.ans .xm-pick>span[data-ok]{color:#1d4ed8;font-weight:800;border-color:#93c5fd}.xm-wrap.ans .xm-pick>span[data-ok] i{background:#1d4ed8;border-color:#1d4ed8}'+'.xm-hint{max-width:900px;margin:0 auto 10px;background:#ecfeff;border:1px solid #a5f3fc;border-radius:12px;padding:6px 12px;font-weight:700;color:#155e75;font-size:14px}'+
    '.xm-tk .xm-opts{display:grid;grid-template-columns:1fr 1fr;gap:6px;padding-right:22px}.xm-op{display:flex;gap:8px;align-items:center;border:1.6px solid #dbe3ee;border-radius:10px;padding:6px 10px;cursor:pointer;background:#fff}.xm-op:has(input:checked){border-color:#14465c;background:#eef6fb}.xm-op.ok{border-color:#16a34a;background:#ecfdf3}.xm-op.bad{border-color:#dc2626;background:#fef2f2}'+
    '.xm-ta{display:block;width:calc(100% - 22px);margin-right:22px;box-sizing:border-box;border:1.6px solid #dbe3ee;border-radius:10px;padding:8px 10px;font:16px/1.8 Tajawal,Arial,sans-serif;resize:vertical;background:#fbfdff}.xm-ta:focus{outline:none;border-color:#14465c}'+
    '.xm-off{background:#fff7ed;border:1.4px dashed #f59e0b;border-radius:10px;padding:6px 12px;font-weight:700;color:#92400e}.xm-mk{padding-right:22px;font-weight:800;color:#14465c;margin-top:2px}.xm-cnt{align-self:center;font-weight:800;color:#14465c}'+
    '.xm-send{text-align:center;margin-top:14px}.xm-send button{border:0;background:#16a34a;color:#fff;border-radius:14px;padding:12px 28px;font:800 18px Tajawal,sans-serif;cursor:pointer}.xm-send button:disabled{opacity:.6}.xm-err{color:#dc2626;font-weight:700}'+
    '.xm-res{max-width:900px;margin:0 auto 12px;background:linear-gradient(135deg,#14465c,#0e7490);color:#fff;border-radius:16px;padding:16px;text-align:center;font-weight:700}.xm-big{font-size:44px;font-weight:900}.xm-big small{font-size:20px}'+
    '.xm-lnk{display:inline-flex;align-items:center;border:2px solid #14465c;background:#fff;color:#14465c;border-radius:12px;padding:8px 14px;font:800 15px Tajawal,sans-serif;text-decoration:none}'+
    '.xm-wrap .xm-page{border:1px solid #dbe3ee;border-radius:12px;padding:18px 20px 34px;margin:0 0 20px;box-shadow:0 2px 10px rgba(20,70,92,.06);position:relative;background:#fff}.xm-wrap:has(.xm-pgd){background:#f1f5f9;box-shadow:none;padding:12px}'+
    '.xm-wrap.ans .xm-ln{display:none}.xm-note{max-width:900px;margin:0 auto 10px;font-size:14px;color:#555}@media(max-width:600px){.xm-hd{flex-direction:column;align-items:stretch}.xm-ch,.xm-tk .xm-opts{grid-template-columns:1fr}}';document.head.appendChild(s);}
  /* ===== الحل الإلكتروني للطالب ===== */
  function skill(h){h=String(h||"");var p=h.indexOf(":");if(p>=0)h=h.slice(p+1);var a=h.trim().split(/\s+[–-]\s+/);h=a[a.length-1].trim().replace(/^\([^)]*\)\s*/,"").trim();return h||"أخرى";}
  function offline(S){var k=skill(S.h);return !!S.dictation||k==="الإملاء"||k==="الخط"||k==="الرسم الهجائي";}
  function takeHtml(E,dr,res){var n=0;var h='<div class="xm-doc xm-tk"><header class="xm-hd"><div class="c"><h1>'+esc(E.title||"")+'</h1><div>اللغة العربية – الصف '+(GN[E.grade]||"")+(res?' – مراجعة إجاباتك':' – الحل الإلكتروني')+'</div></div></header>';
    (E.papers||[]).forEach(function(P,pi){h+='<div class="xm-pp"><span>'+esc(P.name||"")+'</span></div>';(P.sections||[]).forEach(function(S,si){
      h+='<section class="xm-sec'+(S.lvl===1?' xm-l1':'')+'"><div class="xm-sh"><b>'+esc(sh(S))+'</b>'+(S.marks?'<span>( '+an(S.marks)+' )</span>':'')+'</div>';
      if(offline(S)){h+='<div class="xm-off">📝 يُؤدّى هذا السؤال ورقيًا مع المعلم.</div></section>';return;}
      if(S.intro)h+='<div class="xm-in">'+atext(S.intro)+'</div>';h+=passage(S.passage);if(S.note)h+='<div class="xm-in">'+esc(S.note)+'</div>';
      (S.items||[]).forEach(function(it,ii){var k=pi+"."+si+"."+ii,v=dr[k],mk=res&&res.marks?res.marks[k]:undefined;n++;
        h+='<div class="xm-it" data-k="'+k+'"><div class="xm-q"><b>'+LT[ii%LT.length]+'-</b> <span>'+blank(it.q||"")+'</span>'+(it.m?'<span class="xm-m">('+an(it.m)+')</span>':'')+'</div>';
        if(it.k==="topics")h+='<ol class="xm-tp">'+(it.topics||[]).map(function(t){return '<li>'+esc(t)+'</li>';}).join("")+'</ol>';
        if(it.passage)h+='<div class="xm-ps"><div class="xm-pr">'+it.passage.map(function(p){return '<p>'+esc(p)+'</p>';}).join("")+'</div></div>';if(it.x)h+='<div class="xm-x">'+atext(it.x)+'</div>';h+=vs(it.qverses);if(it.subs)h+=subs(it.subs,false,false);
        if(it.k==="mcq"){h+='<div class="xm-opts">'+(it.choices||[]).map(function(c,j){var cls=res?(j===it.a?' ok':(+v===j&&v!==null&&v!==undefined?' bad':'')):'';
            return '<label class="xm-op'+cls+'"><input type="radio" name="q'+k.replace(/\./g,"_")+'" value="'+j+'"'+(v!==null&&v!==undefined&&+v===j?' checked':'')+(res?' disabled':'')+'> <span>'+esc(c)+'</span></label>';}).join("")+'</div>';}
        else{h+='<textarea class="xm-ta" rows="'+(it.k==="topics"||it.k==="topic"?12:Math.max(2,Math.min(8,+it.lines||3)))+'"'+(res?' readonly':'')+' placeholder="اكتب إجابتك هنا…">'+esc(v||"")+'</textarea>';
          if(res)h+='<div class="xm-a" style="display:block"><b>نموذج الإجابة:</b> '+ansBody(it)+'</div>';}
        if(res)h+='<div class="xm-mk">'+(mk===undefined?'⏳ بانتظار تصحيح المعلم':(it.k==="mcq"?(mk>0?'✅ إجابة صحيحة':'❌ إجابة غير صحيحة'):'الدرجة: <b>'+an(mk)+'</b> من '+an(it.m)))+'</div>';
        h+='</div>';});h+='</section>';});});
    return h+'</div>';}
  function collect(root){var A={};root.querySelectorAll(".xm-it[data-k]").forEach(function(d){var k=d.getAttribute("data-k"),r=d.querySelector("input[type=radio]:checked"),t=d.querySelector("textarea");
      if(d.querySelector("input[type=radio]"))A[k]=r?+r.value:null;else if(t)A[k]=t.value;});return A;}
  function take(E,g,m,view,bind){var key="xm:draft:"+g+"-"+m,dr={};try{dr=JSON.parse(localStorage.getItem(key)||"{}")||{};}catch(e){}
    view.innerHTML='<div class="xm-bar"><button type="button" data-x="back">→ عرض الاختبار</button><span class="xm-cnt"></span></div><div class="xm-note">الإملاء والخط يُؤدَّيان ورقيًا مع المعلم. إجاباتك تُحفظ تلقائيًا على هذا الجهاز حتى ترسلها.</div><div class="xm-wrap">'+takeHtml(E,dr,null)+
      '<div class="xm-send"><p class="xm-err"></p><button type="button" data-x="send">📤 إرسال الإجابات</button></div></div>';
    var w=view.querySelector(".xm-wrap"),cnt=view.querySelector(".xm-cnt"),tm=null;
    function stat(){var A=collect(w),ks=Object.keys(A),d=ks.filter(function(k){return A[k]!==null&&String(A[k]).trim()!=="";}).length;cnt.textContent="أجبت عن "+an(d)+" من "+an(ks.length);return [d,ks.length,A];}
    function save(){clearTimeout(tm);tm=setTimeout(function(){try{localStorage.setItem(key,JSON.stringify(collect(w)));}catch(e){}},400);stat();}
    w.addEventListener("input",save);w.addEventListener("change",save);stat();
    view.querySelector('[data-x="back"]').onclick=function(){route([XP0,"exams",String(g),String(m)],tS0,SH0,view,bind,CARD0);};
    w.querySelector('[data-x="send"]').onclick=function(){var b=this,s=stat(),er=w.querySelector(".xm-err");
      if(s[0]<s[1]&&!confirm("لم تُجب عن "+an(s[1]-s[0])+" سؤالًا. هل تريد الإرسال الآن؟"))return;
      b.disabled=true;b.textContent="⏳ جارٍ الإرسال…";er.textContent="";
      STP.post("exam_submit",{exam:g+"-"+m,answers:s[2]}).then(function(r){try{localStorage.removeItem(key);}catch(e){}
        view.innerHTML='<div class="xm-res"><div class="xm-big">'+an(r.score)+' <small>من '+an(r.total)+'</small></div><div>'+(r.pending?'⏳ '+an(r.pending)+' سؤالًا مقاليًا بانتظار تصحيح معلمك، وستتغيّر درجتك بعد التصحيح.':'✅ صُحّحت إجاباتك كلها.')+'</div>'+
          '<div class="xm-bar" style="justify-content:center;margin-top:10px"><a class="xm-lnk" href="'+(window.PORTAL_URL?PORTAL_URL():"portal/")+'">👤 صفحتي ومهاراتي</a></div></div><div class="xm-wrap">'+takeHtml(E,s[2],r)+'</div>';
        window.scrollTo(0,0);}).catch(function(e){b.disabled=false;b.textContent="📤 إرسال الإجابات";er.textContent=e.message;});};
    bind();}
  /* ===== توليد نموذج جديد: كل سؤال يُختار عشوائيًا من أحد النماذج بنفس موقعه (البنية واحدة وفق دليل التقييم) ===== */
  function genModel(g,L,view,bind){view.innerHTML='<p class="el-load">⏳ جارٍ توليد النموذج…</p>';
    Promise.all(L.map(function(x){return load(g,x.m);})).then(function(M){var E=JSON.parse(JSON.stringify(M[0]));E.title="نموذج اختبار مُولَّد من بنك الأسئلة";
      E.papers.forEach(function(P,pi){P.sections=P.sections.map(function(S,si){var c=M.filter(function(X){return X.papers[pi]&&X.papers[pi].sections[si];});var X=c[Math.floor(Math.random()*c.length)];return JSON.parse(JSON.stringify(X.papers[pi].sections[si]));});});
      view.innerHTML='<div class="xm-bar"><button type="button" data-x="re">🎲 توليد نموذج آخر</button><button type="button" data-x="ans">👁 إظهار الإجابات</button><button type="button" data-x="p0">🖨 طباعة الاختبار</button><button type="button" data-x="p1">🖨 طباعة نموذج الإجابة</button></div>'+
        '<div class="xm-note">كل سؤال اختير عشوائيًا من أحد نماذج الصف في الموقع نفسه، فيبقى النموذج مطابقًا لدليل التقييم.</div><div class="xm-wrap">'+html(E,true,true)+'</div>';
      var w=view.querySelector(".xm-wrap");interact(w);w=view.querySelector(".xm-wrap"),k=w.querySelector(".xm-key");if(k)k.style.display="none";
      view.querySelector(".xm-bar").onclick=function(e){var b=e.target.closest("[data-x]");if(!b)return;var x=b.getAttribute("data-x");
        if(x==="re")genModel(g,L,view,bind);else if(x==="ans"){var on=w.classList.toggle("ans");b.classList.toggle("on",on);b.textContent=on?"🙈 إخفاء الإجابات":"👁 إظهار الإجابات";if(k)k.style.display=on?"":"none";}else printIt(E,x==="p1");};bind();
    },function(){view.innerHTML='<div class="el-empty">تعذّر تحميل النماذج، حاول مجددًا.</div>';});}
  var tS0=null,SH0=null,CARD0=null,XP0="arabic";
  /* المسارات: arabic/exams ، arabic/exams/<g> ، arabic/exams/<g>/<m> */
  function route(p,tS,setHead,view,bind,card){css();tS0=tS;SH0=setHead;CARD0=card;XP0=p[0]||"arabic";var g=p[2]?+p[2]:null,m=p[3]?+p[3]:null,base=XP0+"/exams",SJ=XP0==="smart"?window.__SM_SUBJ:XP0==="courses"?window.__CRS_SUBJ:null,t0=tS.concat([["الاختبارات النهائية",base]]);
    var COL=[["#0ea5e9","#0369a1"],["#14b8a6","#0f766e"],["#8b5cf6","#6d28d9"]];
    if(!g){setHead("الاختبارات النهائية",t0,XP0);view.innerHTML='<p class="el-load">⏳ جارٍ التحميل…</p>';
      idx().then(function(I){view.innerHTML='<p class="el-gs-hint">نماذج الاختبار النهائي التجريبي – الفصل الدراسي الأول – وفق دليل التقييم. اختر الصف</p><div class="el-grid">'+
        [4,5,6,7,8,9,10,11,12].filter(function(k){return XP0==="arabic"||!SJ||SJ.grades.indexOf(k)>=0;}).map(function(k){var n=(I[k]||[]).length;return card('data-go="'+base+'/'+k+'"',COL[k%3],'<b>'+k+'</b>',"الصف "+GN[k],n===1?"نموذج واحد":n===2?"نموذجان":n?an(n)+" نماذج":"قريبًا");}).join("")+'</div>';bind();});return;}
    var tg=t0.concat([["الصف "+GN[g],base+"/"+g]]);
    if(!m){setHead("الاختبارات النهائية – الصف "+GN[g],tg,base);idx().then(function(I){var L=I[g]||[];
      var gen=window.STP&&STP.isStaff&&STP.isStaff()&&L.length>1;
      view.innerHTML=(gen?'<div class="xm-bar"><button type="button" data-x="gen">🎲 توليد نموذج جديد من بنك الأسئلة</button></div>':'')+(L.length?'<div class="el-list">'+L.map(function(x,i){return '<button type="button" class="el-row" data-go="'+base+'/'+g+'/'+x.m+'"><span class="el-ic"><b>'+an(x.m)+'</b></span><span class="el-t">'+esc(x.t||("نموذج الاختبار النهائي التجريبي ("+an(x.m)+")"))+'</span><span class="el-n">'+an(x.total||"")+' درجة</span></button>';}).join("")+'</div>':'<div class="el-empty">نماذج هذا الصف قريبًا بإذن الله.</div>');
      var gb=view.querySelector('[data-x="gen"]');if(gb)gb.onclick=function(){genModel(g,L,view,bind);};bind();});return;}
    setHead("نموذج الاختبار النهائي التجريبي ("+an(m)+")",tg.concat([["النموذج "+an(m),""]]),base+"/"+g);view.innerHTML='<p class="el-load">⏳ جارٍ تحميل النموذج…</p>';
    Promise.all([load(g,m),window.STP&&STP.ready?STP.ready.catch(function(){return null;}):Promise.resolve(null)]).then(function(R){var E=R[0],me=R[1],role=me&&me.role,staff=role==="teacher"||role==="admin";
      if(role==="student"){view.innerHTML='<div class="xm-bar"><button type="button" class="on" data-x="take">✍️ حلّ الاختبار إلكترونيًا</button><button type="button" data-x="p0">🖨 طباعة الاختبار</button></div>'+
          '<div class="xm-note">تُصحَّح أسئلة الاختيار من متعدد فور الإرسال، ويصحّح معلمك الأسئلة المقالية، وتظهر النتيجة في صفحتك ولوليّ أمرك.</div><div class="xm-wrap">'+html(E,false)+'</div>';
        view.querySelector(".xm-bar").onclick=function(e){var b=e.target.closest("[data-x]");if(!b)return;if(b.getAttribute("data-x")==="take")take(E,g,m,view,bind);else printIt(E,false);};bind();return;}
      view.innerHTML='<div class="xm-bar"><button type="button" data-x="ans">👁 إظهار الإجابات</button><button type="button" data-x="p0">🖨 طباعة الاختبار</button><button type="button" data-x="p1">🖨 طباعة نموذج الإجابة</button>'+
        (staff?'<button type="button" data-x="asg">📌 إسناد لفصل (حلّ إلكتروني)</button>':'')+(!me?'<a class="xm-lnk" href="'+(window.PORTAL_URL?PORTAL_URL():"portal/")+'">🔐 ادخل بحساب الطالب لحلّه إلكترونيًا</a>':'')+'</div><div class="xm-hint">👆 اضغط مكان الإجابة لتظهر، واضغط مرة أخرى لتختفي. وفي الاختيار من متعدد اضغط اختيارك: الأخضر ✓ صحيح، والأحمر ✗ خطأ.</div><div class="xm-wrap">'+html(E,true,true)+'</div>';
      var w=view.querySelector(".xm-wrap");interact(w);
      view.querySelector(".xm-bar").onclick=function(e){var b=e.target.closest("[data-x]");if(!b)return;var x=b.getAttribute("data-x");
        if(x==="ans"){var on=w.classList.toggle("ans");b.classList.toggle("on",on);b.textContent=on?"🙈 إخفاء الإجابات":"👁 إظهار الإجابات";w.querySelector(".xm-key")&&(w.querySelector(".xm-key").style.display=on?"":"none");}
        else if(x==="asg"){if(window.ASSIGN)ASSIGN("arabic/exams/"+g+"/"+m,(E.title||"نموذج الاختبار النهائي")+" – الصف "+GN[g]);}
        else printIt(E,x==="p1");};
      var k=w.querySelector(".xm-key");if(k)k.style.display="none";bind();
    },function(){view.innerHTML='<div class="el-empty">تعذّر تحميل النموذج، تحقّق من الاتصال ثم أعد المحاولة.</div>';});}
  return {route:route,html:html,print:printIt};})();
/* تُرسم صفحة المكتبة أحيانًا قبل تحميل هذا الملف؛ فنعيد رسمها ليظهر قسم الاختبارات للزائر أيضًا */
(function(){var h=location.hash;if(/^#\/arabic(\/|$)/.test(h)&&(/exams/.test(h)||!/^#\/arabic\/[a-z]+\/\d+\/\d/.test(h))){try{window.dispatchEvent(new HashChangeEvent("hashchange"));}catch(e){}}})();
/* EXAMS-END */
