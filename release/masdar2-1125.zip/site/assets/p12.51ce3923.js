/* CUST-BEGIN */
/* تخصيصات المعلم المحفوظة في حسابه على الخادم (لا تظهر لغيره) */
window.CUST=(function(){var cache={};
  function ok(){return !!(window.STP&&STP.isStaff&&STP.isStaff()&&location.protocol.indexOf("http")===0);}
  function key(k){return String(k).replace(/[^a-zA-Z0-9:_\-.]/g,"").slice(0,110);}
  function cl(v){return v==null?null:JSON.parse(JSON.stringify(v));}
  function get(k){k=key(k);if(!ok())return Promise.resolve(null);if(Object.prototype.hasOwnProperty.call(cache,k))return Promise.resolve(cl(cache[k]));
    return STP.post("custom_get",{keys:[k]}).then(function(j){var v=j.data&&j.data[k];try{v=v?JSON.parse(v):null;}catch(e){v=null;}cache[k]=v;return cl(v);}).catch(function(){return null;});}
  function save(k,v){k=key(k);if(!ok())return Promise.reject(new Error("سجّل الدخول بحساب المعلم أولًا."));
    return STP.post("custom_save",{k:k,data:v==null?"":JSON.stringify(v)}).then(function(j){cache[k]=cl(v);return j;});}
  return {ok:ok,get:get,save:save};})();
/* ===== ساعة عائمة + توقيت الحصص (الدوام المدرسي) ===== */
window.SCHOOLCLK=(function(){
  /* توقيت الدوام المدرسي (بنظام 24 ساعة) */
  var P=[["طابور الصباح","07:45","07:55",1],["الحصة الأولى","07:55","08:40"],["الحصة الثانية","08:45","09:30"],["الحصة الثالثة","09:35","10:20"],
    ["الفرصة الأولى","10:20","10:35",1],["الحصة الرابعة","10:35","11:20"],["الحصة الخامسة","11:25","12:10"],["الفرصة الثانية","12:10","12:25",1],
    ["الحصة السادسة","12:25","13:10"],["الحصة السابعة","13:10","13:55"]];
  var AR="٠١٢٣٤٥٦٧٨٩",DAYS=["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
  function an(n){return String(n).replace(/\d/g,function(d){return AR[d];});}
  function mins(t){var a=t.split(":");return +a[0]*60+ +a[1];}
  function h12(t){var a=t.split(":"),h=+a[0]%12||12;return h+":"+a[1];}
  function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v);}catch(e){}return null;}
  function now(){return new Date();}
  /* الحالة الحالية: الحصة الجارية والمتبقي */
  function status(d){d=d||now();var wd=d.getDay(),m=d.getHours()*60+d.getMinutes()+d.getSeconds()/60;
    if(wd===5||wd===6)return {i:-1,t:"عطلة نهاية الأسبوع – لا دوام اليوم"};
    var s=mins(P[0][1]),e=mins(P[P.length-1][2]);
    if(m<s)return {i:-1,t:"يبدأ الدوام بعد "+dur(s-m)};
    if(m>=e)return {i:-1,t:"انتهى الدوام المدرسي لليوم"};
    for(var i=0;i<P.length;i++){var a=mins(P[i][1]),b=mins(P[i][2]);
      if(m>=a&&m<b)return {i:i,t:P[i][0]+" • باقٍ "+dur(b-m),left:b-m,len:b-a};
      if(i<P.length-1&&m>=b&&m<mins(P[i+1][1]))return {i:-1,nx:i+1,t:"استراحة قصيرة • "+P[i+1][0]+" بعد "+dur(mins(P[i+1][1])-m)};}
    return {i:-1,t:""};}
  function dur(x){var t=Math.ceil(x);if(t>=60){var h=Math.floor(t/60),r=t%60;return an(h)+" س"+(r?" و"+an(r)+" د":"");}return an(t)+" د";}
  var HF=null,HK="",HV="";function hijri(d){var k=d.toDateString();if(k===HK)return HV;HK=k;try{HF=HF||new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura",{day:"numeric",month:"long",year:"numeric"});HV=HF.format(d);}catch(e){HV="";}return HV;}
  function greg(d){return an(d.getDate())+" / "+an(d.getMonth()+1)+" / "+an(d.getFullYear());}
  /* ---------- الساعة العائمة ---------- */
  var el=null,fab=null,tm=null;
  function st(v){if(v===undefined)return ls("clk:st")||(innerWidth<600?"min":"open");ls("clk:st",v);}
  function build(){if(el)return;
    if(!document.getElementById('ck-font')){var lk=document.createElement('link');lk.id='ck-font';lk.rel='stylesheet';lk.href='https://fonts.googleapis.com/css2?family=Orbitron:wght@700;800&display=swap';document.head.appendChild(lk);}
    el=document.createElement("div");el.id="stclk";el.setAttribute("role","timer");el.setAttribute("aria-label","الساعة");
    el.innerHTML='<div class="ck-bar"><span class="ck-grip" title="اسحب لتحريك الساعة">⠿</span><button type="button" data-ck="tbl" title="توقيت الحصص">📋</button><button type="button" data-ck="min" title="تصغير">–</button><button type="button" data-ck="x" title="إغلاق">×</button></div>'+
      '<div class="ck-face"><div class="ck-main"><span class="ck-t">12:00</span><span class="ck-side"><b class="ck-ap">ص</b><span class="ck-s">00</span></span></div>'+
      '<div class="ck-row"><span class="ck-day"></span><span class="ck-g"></span></div><div class="ck-h"></div><button type="button" class="ck-p" data-ck="tbl"></button></div>';
    fab=document.createElement("button");fab.type="button";fab.id="stclk-fab";fab.title="إظهار الساعة";fab.setAttribute("aria-label","إظهار الساعة");fab.innerHTML="🕐";
    document.body.appendChild(el);document.body.appendChild(fab);
    el.addEventListener("click",function(e){var b=e.target.closest("[data-ck]");if(!b)return;var a=b.getAttribute("data-ck");
      if(a==="x"){st("closed");apply();}else if(a==="min"){st(st()==="min"?"open":"min");apply();}else if(a==="tbl")toggleTable();});
    fab.onclick=function(){st("open");apply();};
    drag();var pos=null;try{pos=JSON.parse(ls("clk:pos")||"null");}catch(e){}if(pos)place(pos.x,pos.y);
    apply();tick();tm=setInterval(tick,1000);
    window.addEventListener("resize",function(){var r=el.getBoundingClientRect();if(r.width)place(r.left,r.top);});}
  function apply(){var s=st();el.classList.toggle("min",s==="min");el.hidden=s==="closed";fab.hidden=s!=="closed";if(!el.hidden)tick();}
  function place(x,y){var w=el.offsetWidth||220,h=el.offsetHeight||120;x=Math.max(4,Math.min(innerWidth-w-4,x));y=Math.max(4,Math.min(innerHeight-h-4,y));
    el.style.left=x+"px";el.style.top=y+"px";el.style.right="auto";el.style.bottom="auto";}
  function drag(){var g=el.querySelector(".ck-bar"),sx,sy,ox,oy,on=false;
    g.addEventListener("pointerdown",function(e){if(e.target.closest("button"))return;on=true;var r=el.getBoundingClientRect();sx=e.clientX;sy=e.clientY;ox=r.left;oy=r.top;g.setPointerCapture(e.pointerId);el.classList.add("drag");});
    g.addEventListener("pointermove",function(e){if(on)place(ox+e.clientX-sx,oy+e.clientY-sy);});
    function up(){if(!on)return;on=false;el.classList.remove("drag");var r=el.getBoundingClientRect();ls("clk:pos",JSON.stringify({x:r.left,y:r.top}));}
    g.addEventListener("pointerup",up);g.addEventListener("pointercancel",up);}
  var CKN={};function ckset(c,v){var n=CKN[c]||(CKN[c]=el.querySelector(c));if(n&&n.textContent!==v)n.textContent=v;}
  if(!window.__ckvis){window.__ckvis=1;document.addEventListener("visibilitychange",function(){if(!document.hidden&&el)tick();});}
  function tick(){if(document.hidden||!el||el.hidden)return;var d=now(),h=d.getHours(),m=d.getMinutes(),s=d.getSeconds();
    ckset(".ck-t",(h%12||12)+":"+(m<10?"0":"")+m);ckset(".ck-s",(s<10?"0":"")+s);
    ckset(".ck-ap",h<12?"ص":"م");ckset(".ck-day",DAYS[d.getDay()]);
    ckset(".ck-g",greg(d)+" م");ckset(".ck-h",hijri(d));
    var S=status(d),pb=el.querySelector(".ck-p");ckset(".ck-p",(S.i>=0?(P[S.i][3]?"☕ ":"📚 "):"⏰ ")+S.t);var on=S.i>=0,wn=S.i>=0&&S.left<=5;if(pb.classList.contains("on")!==on)pb.classList.toggle("on",on);if(pb.classList.contains("warn")!==wn)pb.classList.toggle("warn",wn);
    if(tbl&&!tbl.hidden)paintTable(S);}
  /* ---------- جدول توقيت الحصص ---------- */
  var tbl=null;
  function buildTable(){if(tbl)return;tbl=document.createElement("div");tbl.id="stclk-tbl";tbl.hidden=true;tbl.setAttribute("role","dialog");tbl.setAttribute("aria-label","توقيت الدوام المدرسي");
    tbl.innerHTML='<div class="ct-h"><b>🕐 توقيت الدوام المدرسي</b><button type="button" class="ct-x" aria-label="إغلاق">×</button></div><div class="ct-now"></div>'+
      '<table><thead><tr><th>الحصص والتوقيت</th><th>من الساعة</th><th>إلى الساعة</th><th>المدة</th></tr></thead><tbody>'+
      P.map(function(r,i){return '<tr data-i="'+i+'"'+(r[3]?' class="brk"':'')+'><th>'+r[0]+'</th><td>'+an(h12(r[1]))+'</td><td>'+an(h12(r[2]))+'</td><td>'+an(mins(r[2])-mins(r[1]))+' دقيقة</td></tr>';}).join("")+'</tbody></table>';
    document.body.appendChild(tbl);tbl.querySelector(".ct-x").onclick=function(){tbl.hidden=true;sync();};
    ["click","pointerdown","pointerup","mousedown","mouseup","touchstart","touchend","keydown"].forEach(function(t){tbl.addEventListener(t,function(e){e.stopPropagation();if(t==="keydown"&&e.key==="Escape"){tbl.hidden=true;sync();}});});}
  function paintTable(S){S=S||status();tbl.querySelector(".ct-now").textContent=S.t||"";
    tbl.querySelectorAll("tr[data-i]").forEach(function(r){var i=+r.getAttribute("data-i");r.classList.toggle("cur",i===S.i);r.classList.toggle("nx",S.nx===i);});}
  var subs=[];function sync(){var on=!!(tbl&&!tbl.hidden);subs.forEach(function(f){try{f(on);}catch(e){}});}
  function toggleTable(force){buildTable();tbl.hidden=force===undefined?!tbl.hidden:!force;if(!tbl.hidden)paintTable();sync();}
  function init(){build();buildTable();}
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
  return {toggleTable:toggleTable,onTable:function(f){subs.push(f);},status:status,show:function(){st("open");apply();}};
})();
/* CUST-END */