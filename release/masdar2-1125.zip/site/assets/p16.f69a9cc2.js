/* SM-BEGIN */
/* ===== أيقونات معبّرة تُسحب وتُحرَّك فوق عرض الدرس ===== */
window.STICK=(function(){
var CATS=[
 ["⭐ تحفيز",["⭐","🌟","👏","🏆","🥇","🎉","💯","👍","💪","🎖️","🔥","❤️","😍","🤩","😊","🙌"]],
 ["✔️ تصحيح",["✅","✔️","❌","✖️","❓","❗","⭕","🔴","🟢","🟡","🔵","⚠️","💡","📌","🎯","🔍"]],
 ["➡️ أسهم",["➡️","⬅️","⬆️","⬇️","↗️","↘️","↙️","↖️","🔄","↩️","👉","👈","👆","👇","☝️","✋"]],
 ["📚 تعليم",["📖","📚","✏️","📝","🖊️","📒","🧠","🎓","🏫","👨‍🏫","👩‍🏫","🧑‍🎓","👦","👧","🧕","🗣️"]],
 ["🌿 طبيعة",["☀️","🌙","⭐","☁️","🌧️","🌈","🌳","🌴","🌸","🌹","🍃","🌊","💧","⛰️","🏜️","🌍"]],
 ["🐾 حيوانات",["🐑","🐫","🐎","🦅","🐦","🐍","🐝","🦋","🐟","🐬","🐪","🦁","🐘","🐱","🐶","🐓"]],
 ["🕌 قيم",["🕌","🤲","📿","🕋","🤝","💎","⚖️","🛡️","🕊️","🌙","✨","🙏","🫶","💖","🏅","🇰🇼"]]];
var KW=[[/آيات|سورة|القرآن|قرآن/,["📖","🕌","🤲","✨","🌙","🕋"]],[/القصص|موسى|مدين/,["🐑","💧","🌴","🏜️","👧","🤲"]],[/الأنبياء|إبراهيم/,["🔥","🗿","🪓","🕊️","🌙","⭐"]],
 [/الفرقان/,["🌙","🌍","🌧️","🌊","🤲","✨"]],[/آل عمران/,["🤲","📖","🕌","💪","🤝","✨"]],[/الحية|النسر/,["🦅","🐍","⛰️","☀️","🪶","🌳"]],
 [/شباب الإسلام|مدح الرسول/,["🕌","⚔️","🏇","🌟","📜","🛡️"]],[/مصعب|أسامة|نسيبة/,["🛡️","⚔️","🏇","🕌","🌟","📜"]],[/الحديث|حديث|وصايا/,["🤝","💬","📿","❤️","⚖️","🕊️"]],
 [/الأوطان|الكويت|وطني|درة/,["🇰🇼","🏙️","⛵","🌊","❤️","🏝️"]],[/السعادة|السرور/,["😊","😄","🌈","🎉","☀️","💖"]],[/العصفور|التينة/,["🐦","🌳","🍂","🪺","☀️","🌿"]],
 [/الماء/,["💧","🌊","🚰","⛵","🐫","☀️"]],[/صنع الخالق|بديع/,["🌍","🌺","🐝","🦋","🌈","🌙"]],[/عام جديد/,["📅","🎆","⏳","🌅","✨","📝"]],
 [/دفقة|شعوري|سلوا قلبي|شاعر|الشعر|فضائل|أخلاق/,["🪶","🎼","💖","🌹","📜","💎"]],[/الإملاء|الهمزة|التاء|التنوين|تنوين|الألف/,["✍️","🔤","📝","✏️","🧐","✅"]],
 [/السلامة اللغوية|الإعراب|المبتدأ|الخبر|الفاعل|المفعول|الحال|النعت|العطف|المعرب|المبني|جمع|المثنى|الفعل|الحرف/,["🧩","🔤","🧠","📐","✅","❓"]],
 [/التعبير|فقرة|القصة القصيرة/,["📝","💡","✍️","📄","🗂️","🌟"]],[/التذوق|التشبيه|الطباق|المقابلة|الكناية|الاستعارة|الجمال/,["🎨","🌸","💫","🖼️","🌷","✨"]],
 [/الاستماع/,["🎧","👂","🔊","🗣️","📻","💬"]],[/التدريب|التطبيق/,["🏋️","✅","🎯","📝","🏆","💪"]]];
function suggest(txt){var out=[];KW.forEach(function(k){if(k[0].test(txt))k[1].forEach(function(e){if(out.indexOf(e)<0)out.push(e);});});
  ["⭐","👏","✅","❌","💡","🎯","❓","➡️"].forEach(function(e){if(out.length<14&&out.indexOf(e)<0)out.push(e);});return out.slice(0,16);}
var ANIM=["","bob","wig","pulse","spin"],ANN={"":"بدون حركة",bob:"قفز",wig:"اهتزاز",pulse:"نبض",spin:"دوران"};
function ls(k,v){try{if(v===undefined)return JSON.parse(localStorage.getItem(k)||"null");localStorage.setItem(k,JSON.stringify(v));}catch(e){return null;}}
function attach(host,o){o=o||{};if(!host||host.querySelector(":scope > .stk-layer"))return;
  var layer=document.createElement("div");layer.className="stk-layer";host.appendChild(layer);
  var tray=document.createElement("div");tray.className="stk-tray";tray.hidden=true;host.appendChild(tray);
  var mine=suggest(o.text||"");var cats=[["✨ أيقونات الدرس",mine]].concat(CATS),cur=0,K=o.key?"stk:"+o.key:null,list=(K&&ls(K))||[],sel=null;
  function drawTray(){tray.innerHTML='<div class="stk-th"><b>🎨 أيقونات معبّرة</b><span>اضغط الأيقونة لإضافتها، ثم اسحبها لأي مكان</span><button type="button" data-x aria-label="إغلاق">✕</button></div>'+
    '<div class="stk-tabs">'+cats.map(function(c,i){return '<button type="button" data-c="'+i+'"'+(i===cur?' class="on"':'')+'>'+c[0]+'</button>';}).join("")+'</div>'+
    '<div class="stk-grid">'+cats[cur][1].map(function(e){return '<button type="button" data-e="'+e+'">'+e+'</button>';}).join("")+'</div>'+
    '<div class="stk-tf"><button type="button" data-clear>🗑️ مسح كل الأيقونات</button></div>';}
  drawTray();
  ["pointerdown","pointerup","click","dblclick","wheel","touchstart","touchend","keydown"].forEach(function(t){tray.addEventListener(t,function(e){e.stopPropagation();},{passive:t!=="wheel"&&t!=="click"});layer.addEventListener(t,function(e){if(e.target!==layer)e.stopPropagation();},{passive:t!=="wheel"&&t!=="click"});});
  tray.addEventListener("click",function(e){var b=e.target.closest("button");if(!b)return;
    if(b.hasAttribute("data-x")){tray.hidden=true;if(btn)btn.classList.remove("on");return;}
    if(b.hasAttribute("data-c")){cur=+b.getAttribute("data-c");drawTray();return;}
    if(b.hasAttribute("data-clear")){list=[];save();paint();return;}
    var em=b.getAttribute("data-e");if(em){var n=list.length;list.push({e:em,x:44+(n%5)*3,y:38+(n%4)*4,s:9,r:0,a:"bob"});save();paint();select(list.length-1);}});
  function save(){if(K)ls(K,list);}
  function paint(){layer.innerHTML="";list.forEach(function(it,i){var d=document.createElement("div");d.className="stk"+(it.a?" a-"+it.a:"")+(sel===i?" sel":"");d.setAttribute("data-i",i);
      d.style.left=it.x+"%";d.style.top=it.y+"%";d.style.fontSize="calc("+it.s+" * min(1vw,1.6vh))";d.style.setProperty("--r",(it.r||0)+"deg");
      d.innerHTML='<span class="stk-e">'+it.e+'</span>'+(sel===i?'<span class="stk-tools"><button type="button" data-t="big" title="تكبير">＋</button><button type="button" data-t="small" title="تصغير">－</button><button type="button" data-t="rot" title="تدوير">⟳</button><button type="button" data-t="anim" title="الحركة: '+ANN[it.a||""]+'">✨</button><button type="button" data-t="del" title="حذف">🗑</button></span>':'');
      layer.appendChild(d);});}
  function select(i){sel=i;paint();}
  var drag=null;
  layer.addEventListener("pointerdown",function(e){var t=e.target.closest("[data-t]");var d=e.target.closest(".stk");if(!d)return;e.preventDefault();var i=+d.getAttribute("data-i");
    if(t){var it=list[i],a=t.getAttribute("data-t");
      if(a==="big")it.s=Math.min(40,it.s*1.2);if(a==="small")it.s=Math.max(3,it.s/1.2);if(a==="rot")it.r=((it.r||0)+15)%360;
      if(a==="anim"){it.a=ANIM[(ANIM.indexOf(it.a||"")+1)%ANIM.length];}
      if(a==="del"){list.splice(i,1);sel=null;}save();paint();return;}
    if(sel!==i)select(i);var R=layer.getBoundingClientRect();drag={i:i,x:e.clientX,y:e.clientY,ox:list[i].x,oy:list[i].y,W:R.width,H:R.height,id:e.pointerId};
    try{layer.setPointerCapture(e.pointerId);}catch(_){}
    var el=layer.querySelector('.stk[data-i="'+i+'"]');if(el)el.classList.add("drag");});
  layer.addEventListener("pointermove",function(e){if(!drag)return;var it=list[drag.i];it.x=Math.max(-2,Math.min(98,drag.ox+(e.clientX-drag.x)/drag.W*100));it.y=Math.max(-2,Math.min(96,drag.oy+(e.clientY-drag.y)/drag.H*100));
    var el=layer.querySelector('.stk[data-i="'+drag.i+'"]');if(el){el.style.left=it.x+"%";el.style.top=it.y+"%";}});
  function end(){if(!drag)return;drag=null;save();var el=layer.querySelector(".stk.drag");if(el)el.classList.remove("drag");}
  layer.addEventListener("pointerup",end);layer.addEventListener("pointercancel",end);
  layer.addEventListener("wheel",function(e){var d=e.target.closest(".stk");if(!d)return;e.preventDefault();var it=list[+d.getAttribute("data-i")];it.s=Math.max(3,Math.min(40,it.s*(e.deltaY<0?1.1:0.9)));save();paint();},{passive:false});
  layer.addEventListener("dblclick",function(e){var d=e.target.closest(".stk");if(!d)return;list.splice(+d.getAttribute("data-i"),1);sel=null;save();paint();});
  host.addEventListener("pointerdown",function(e){if(sel!==null&&!e.target.closest(".stk")&&!e.target.closest(".stk-tray")){sel=null;paint();}},true);
  var btn=null;if(o.btnHost){btn=document.createElement("button");btn.type="button";btn.className=o.btnClass||"stk-btn";btn.title="أيقونات معبّرة عن الدرس تُسحب وتُحرّك";btn.setAttribute("aria-label","أيقونات معبّرة");
    btn.innerHTML=o.btnHTML||'🎨<small>أيقونات</small>';btn.onclick=function(e){e.stopPropagation();tray.hidden=!tray.hidden;btn.classList.toggle("on",!tray.hidden);};
    if(o.btnFirst)o.btnHost.insertBefore(btn,o.btnHost.firstChild);else o.btnHost.appendChild(btn);}
  paint();
  return {reset:function(key,text){K=key?"stk:"+key:null;list=(K&&ls(K))||[];mine=suggest(text||"");cats[0][1]=mine;sel=null;cur=0;drawTray();paint();tray.hidden=true;if(btn)btn.classList.remove("on");}};}
return {attach:attach,suggest:suggest};})();
/* SM-END */