
/* نمط الرموز التعبيرية: يعمل على المتصفحات الحديثة والقديمة معًا */
window.__EMO=function(){try{return new RegExp("(\\p{Extended_Pictographic}(?:\\uFE0F|\\u200D\\p{Extended_Pictographic}|[\\u{1F3FB}-\\u{1F3FF}])*)","gu");}
  catch(e){return /((?:[\u2600-\u27BF]|[\uD83C-\uD83E][\uDC00-\uDFFF])(?:\uFE0F|\u200D(?:[\u2600-\u27BF]|[\uD83C-\uD83E][\uDC00-\uDFFF])|\uD83C[\uDFFB-\uDFFF])*)/g;}};
