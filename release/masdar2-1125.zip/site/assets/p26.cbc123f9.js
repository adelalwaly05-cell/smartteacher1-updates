
/* ===== مدخل الموقع: معلم / معلمة — تتغيّر صيغ المخاطبة في الموقع كله ===== */
(function(){
var GKEY="edu:gender",NKEY="edu:name",VKEY="edu:vid";
function NM(){try{return localStorage.getItem(NKEY)||"";}catch(e){return "";}}
window.EDU_NAME=NM;
function G(){if(window.EDU_G_TMP)return window.EDU_G_TMP;try{return localStorage.getItem(GKEY)||"";}catch(e){return "";}}
window.EDU_G=G;
/* صيغة المذكر ← صيغة المؤنث (للأوامر والمخاطبة فقط، لا يمسّ نصوص القرآن والقصص والإجابات) */
var F=[["يجيب الطالب وحده على جهازه ويحصل على درجته فورًا","تجيب الطالبة وحدها على جهازها وتحصل على درجتها فورًا"],
 ["يمسح الطلاب الباركود بجوالاتهم، ويكتبون أسماءهم، ثم يجيبون معًا في الوقت نفسه","تمسح الطالبات الباركود بجوالاتهن، ويكتبن أسماءهن، ثم يُجبن معًا في الوقت نفسه"],
 ["ويدخل الطلاب بأسمائهم ويجيبون معًا","وتدخل الطالبات بأسمائهن ويُجبن معًا"],["طالب انضمّ","طالبة انضمّت"],
 ["حتى يبدأ المعلم","حتى تبدأ المعلمة"],["حتى يكشف المعلم","حتى تكشف المعلمة"],["لتصل","لتصلي"],["وابدأ","وابدئي"],["واضغط","واضغطي"],["ربحته","ربحتِه"],
 ["مستفيدًا","مستفيدةً"],["معبّرًا","معبّرةً"],["موضحًا","موضحةً"],["مراعيًا","مراعيةً"],["مدلّلًا","مدلّلةً"],
 ["اضغط","اضغطي"],["حاول","حاولي"],["استفد","استفيدي"],["وحدّد","وحدّدي"],["وحدد","وحددي"],["وبيّن","وبيّني"],["ووضّح","ووضّحي"],["واكتب","واكتبي"],["اسحب","اسحبي"],["اقرأ","اقرئي"],["اكتب","اكتبي"],["أكمل","أكملي"],["استنتج","استنتجي"],["استخلص","استخلصي"],["استخرج","استخرجي"],
 ["رتّب","رتّبي"],["رتب","رتبي"],["ضع","ضعي"],["حدّد","حدّدي"],["حدد","حددي"],["علّل","علّلي"],["علل","عللي"],["دلّل","دلّلي"],["دلل","دللي"],["اختر","اختاري"],
 ["صِل","صِلي"],["وظّف","وظّفي"],["وظف","وظفي"],["وضّح","وضّحي"],["بيّن","بيّني"],["كوّن","كوّني"],["ارجع","ارجعي"],["صُغ","صوغي"],["غيّر","غيّري"],
 ["أعِد","أعيدي"],["أعد","أعيدي"],["اتلُ","اتلي"],["أجب","أجيبي"],["ابدأ","ابدئي"],["العب","العبي"],["انتظر","انتظري"],["افتح","افتحي"],["افقع","افقعي"],
 ["قرّر","قرّري"],["أدِر","أديري"],["أدر","أديري"],["ناقش","ناقشي"],["ادرس","ادرسي"],["افهم","افهمي"],["تأكد","تأكدي"],["جرّب","جرّبي"],["فكّر","فكّري"],
 ["أضف","أضيفي"],["أدخل","أدخلي"],["ادخل","ادخلي"],["استخدم","استخدمي"],["راجع","راجعي"],["تابع","تابعي"],["صدّر","صدّري"],["اجمع","اجمعي"],["اعرف","اعرفي"],
 ["صف هذا","صفي هذا"],["أنت","أنتِ"],["معك","معكِ"],["لديك","لديكِ"],["أحسنت","أحسنتِ"],["ربحت","ربحتِ"],["انسحبت","انسحبتِ"],["احتفظت","احتفظتِ"],["أجبت","أجبتِ"],
 ["وصلت","وصلتِ"],["لم تُجب","لم تُجيبي"],["تستطيع","تستطيعين"],["تريد","تريدين"],["زملائك","زميلاتك"],["لمشاركتك","لمشاركتكِ"],
 ["المعلم/ة","المعلمة"],["طالب/ة","طالبة"],["الطالب/ة","الطالبة"],["الطلاب","الطالبات"],["للطلاب","للطالبات"],["طلابًا","طالباتٍ"],["طلاب","طالبات"],["الطالب","الطالبة"],
 ["طالبًا","طالبةً"],["طالب","طالبة"],["المعلم","المعلمة"],["معلم","معلمة"],["فريقك","فريقكِ"]];
var M=[["المعلم/ة","المعلم"],["طالب/ة","طالب"],["الطالب/ة","الطالب"]];
var AL="\\u0621-\\u064A\\u066E-\\u06D3",DI="\\u064B-\\u0652\\u0670";
function rx(w){return new RegExp("(^|[^"+AL+DI+"])("+w.replace(/[\/]/g,"\\/")+")(?!["+AL+DI+"])","g");}
var RF=F.map(function(p){return [rx(p[0]),p[1]];}),RM=M.map(function(p){return [rx(p[0]),p[1]];});
function conv(t){var g=G(),R=g==="f"?RF:RM;if(!g||!/[\u0621-\u064A]/.test(t))return t;R.forEach(function(r){t=t.replace(r[0],function(_,a){return a+r[1];});});return t;}
window.EDU_GTXT=conv;
/* محتوى لا يُغيَّر: الآيات، القصص، الإجابات، الخيارات، أسماء الطلاب، الخرائط والبطاقات */
var SKIP=".sh-txt,.sh-bayt,.sh-exp,.sh-w,.ayah,.para,.q,.qr,.poem,.ra,.ch,.oi span,.mi span,.ml span,.vc,.fc-face,.mm-n,.mg-a,.tg-a,.wh-a,.qz-b,.lv-btn,.lv-o,.tf-a,.bl-in,.cl-card b,.cl-nm,.cl-rank span,.cl-pick h3,.cl-prof h2,.lv-chip,.lv-row span,.lv-p b,.gx-names,.cl-log span,.cl-sel,.el-crumbs,.cb div,.dlg,[data-nog],textarea,input,script,style,svg";
function walk(root){if(!G()||!root)return;if(root.nodeType===3){fix(root);return;}if(root.nodeType!==1||root.closest&&root.closest(SKIP))return;
  var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null),n,list=[];while(n=w.nextNode())list.push(n);list.forEach(fix);}
function fix(n){var p=n.parentElement;if(!p||p.closest(SKIP))return;var v=n.nodeValue,c=conv(v);if(c!==v)n.nodeValue=c;}
window.eduGApply=function(root){walk(root||document.body);};
var mo=new MutationObserver(function(ms){if(!G())return;ms.forEach(function(m){if(m.type==="characterData")fix(m.target);else m.addedNodes.forEach(walk);});});
mo.observe(document.body,{childList:true,subtree:true,characterData:true});
/* شاشة الدخول */
function beep(f){try{var a=window._gctx=window._gctx||new (window.AudioContext||window.webkitAudioContext)(),t=a.currentTime;[f,f*1.25,f*1.5].forEach(function(x,i){var o=a.createOscillator(),g=a.createGain();o.frequency.value=x;
  g.gain.setValueAtTime(.0001,t+i*.09);g.gain.exponentialRampToValueAtTime(.16,t+i*.09+.02);g.gain.exponentialRampToValueAtTime(.0001,t+i*.09+.3);o.connect(g);g.connect(a.destination);o.start(t+i*.09);o.stop(t+i*.09+.35);});}catch(e){}}
function gate(start){var old=document.getElementById("edu-gate");if(old)old.remove();var d=document.createElement("div");d.id="edu-gate";d.setAttribute("role","dialog");d.setAttribute("aria-label","الدخول إلى الموقع");
  var PU=window.PORTAL_URL?PORTAL_URL():"portal/",TG="https://t.me/+DPUPpvokREQwYjVk";
  if(!document.getElementById("gt2-css")){var st=document.createElement("style");st.id="gt2-css";st.textContent=
   '#edu-gate .gt2-logo{width:132px;height:132px;border-radius:50%;display:block;margin:0 auto 6px;box-shadow:0 10px 28px rgba(14,94,128,.35);border:4px solid #fff;animation:gxBob 3s ease-in-out infinite}'+
   '#edu-gate .gt2-h{margin:6px 0 4px;font-size:clamp(24px,5vw,32px);font-weight:900;color:#0f3f57}'+
   '#edu-gate .gt2-sub{margin:0 0 16px;color:#475569;font-size:15px}'+
   '#edu-gate .gt2-col{display:flex;flex-direction:column;gap:12px;max-width:440px;margin:0 auto}'+
   '#edu-gate .gt2-b{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:60px;padding:10px 16px;border:2px solid #0b3a52;border-radius:16px;background:linear-gradient(180deg,#1a6a8f,#155e80);color:#fff;font:800 clamp(17px,4vw,21px) Tajawal,sans-serif;cursor:pointer;text-decoration:none;box-shadow:0 6px 16px rgba(21,94,128,.3);transition:transform .15s,box-shadow .2s}'+
   '#edu-gate .gt2-b:hover{transform:translateY(-2px);box-shadow:0 10px 22px rgba(21,94,128,.4)}'+
   '#edu-gate .gt2-b small{display:block;font-size:12px;font-weight:600;opacity:.9}'+
   '#edu-gate .gt2-b .ic{font-size:24px}'+
   '#edu-gate .gt2-sep{display:flex;align-items:center;gap:10px;color:#94a3b8;font-size:13px;margin:16px auto 10px;max-width:440px}#edu-gate .gt2-sep:before,#edu-gate .gt2-sep:after{content:"";flex:1;height:1px;background:#cbd5e1}'+
   '#edu-gate .gt2-tg{background:linear-gradient(180deg,#2aa3e0,#1d8cc9);border-color:#1679ad;min-height:52px;font-size:17px}'+
   '#edu-gate .gt2-web{background:#fff;color:#155e80;border-color:#155e80;min-height:46px;font-size:15px;box-shadow:none}'+
   '#edu-gate .gt2-back{position:absolute;top:14px;right:14px;border:2px solid #cbd5e1;background:#fff;color:#0f3f57;border-radius:12px;padding:6px 12px;font:800 15px Tajawal,sans-serif;cursor:pointer}'+
   '#edu-gate .gt2-back:hover{border-color:#155e80}'+
   '#edu-gate .gt2-acc{display:inline-block;margin-top:12px;color:#155e80;font-size:14px;font-weight:700}';
   document.head.appendChild(st);}
  var GNs=["الأول","الثاني","الثالث","الرابع","الخامس","السادس","السابع","الثامن","التاسع","العاشر","الحادي عشر","الثاني عشر"];
  var HOME='<img class="gt2-logo" src="assets/mg-logo.webp" alt="المجموعة التعليمية التفاعلية"><h1 class="gt2-h">أهلًا بكم في المدرسة التفاعلية</h1><p class="gt2-sub">اختر طريقة الدخول المناسبة لك</p>'+
    '<div class="gt2-col"><a class="gt2-b" data-v="email" href="'+PU+'?m=email"><span class="ic">✉️</span><span>التسجيل في الموقع من خلال الإيميل</span></a>'+
    '<a class="gt2-b" data-v="tg" href="'+PU+'?m=tg"><span class="ic">📲</span><span>التسجيل في الموقع من خلال التليجرام</span></a>'+
    '<button type="button" class="gt2-b" data-v="guest"><span class="ic">🚪</span><span>دخول زائر<small>بدون تسجيل</small></span></button></div>'+
    '<a class="gt2-acc" href="'+PU+'">🔐 لديك حساب بالفعل؟ تسجيل الدخول</a>'+
    '<div class="gt2-sep">تواصل معنا</div><div class="gt2-col"><a class="gt2-b gt2-tg" href="'+TG+'" target="_blank" rel="noopener"><span class="ic">💬</span><span>راسلني عبر قناتي على تليجرام</span></a></div>';
  var GUEST='<button type="button" class="gt2-back" data-back>→ رجوع</button><img class="gt2-logo" style="width:92px;height:92px" src="assets/mg-logo.webp" alt=""><h1 class="gt2-h">دخول زائر</h1><p class="gt2-sub">اختر الصف وصيغة المخاطبة ثم ادخل مباشرة — الاسم اختياري</p>'+
    '<label class="gt-name"><span>✍️ اسمك (اختياري)</span><input data-nm maxlength="40" autocomplete="name" placeholder="مثال: أ. محمد"></label>'+
    '<label class="gt-name"><span>🏫 الصف</span><select data-gr><option value="">كل الصفوف</option>'+GNs.map(function(g,i){return '<option value="'+(i+1)+'">الصف '+g+'</option>';}).join("")+'</select></label>'+
    '<div class="gt-opts"><button data-g="m"><span class="gt-em">👨‍🏫</span><b>معلم</b><small>صيغة المذكّر للطلاب</small></button><button data-g="f"><span class="gt-em">👩‍🏫</span><b>معلمة</b><small>صيغة المؤنّث للطالبات</small></button></div>'+
    '<p class="gt-note">يمكنك تغيير الاسم والصف لاحقًا من الشارة أسفل الصفحة</p>';
  d.innerHTML='<div class="gt-bg"><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="gt-box" style="position:relative"></div>';
  var box=d.querySelector(".gt-box");document.body.appendChild(d);document.documentElement.classList.add("lp-lock");
  function close(){d.classList.add("out");setTimeout(function(){d.remove();document.documentElement.classList.remove("lp-lock");location.reload();},600);}
  function home(){box.innerHTML=HOME;box.style.animation="none";void box.offsetWidth;box.style.animation="";
    box.querySelector('[data-v="guest"]').onclick=guest;}
  function guest(){box.innerHTML=GUEST;box.querySelector("[data-back]").onclick=home;
    var nmI=box.querySelector("[data-nm]"),grI=box.querySelector("[data-gr]");var n0=NM();nmI.value=n0==="زائر"?"":n0;try{var g0=localStorage.getItem("edu:grade")||"";grI.value=g0==="all"?"":g0;}catch(e){}
    box.querySelectorAll("[data-g]").forEach(function(b){b.onclick=function(){var g=b.getAttribute("data-g"),nm=nmI.value.replace(/\s+/g," ").trim()||"زائر";
      try{localStorage.setItem(GKEY,g);localStorage.setItem(NKEY,nm.slice(0,40));localStorage.setItem("edu:grade",grI.value||"all");}catch(e){}
      if(location.hash.indexOf("#/")===0)location.hash="";if(/[?&]gate=1/.test(location.search))history.replaceState(null,"",location.pathname);beep(g==="f"?660:523);b.classList.add("pick");close();};});}
  if(start==="guest")guest();else home();}
window.EDU_GATE=gate;
/* شارة اسم الزائر: تظهر طوال التصفح، والضغط عليها يغيّر الاسم */
function meChip(){var n=NM();var c=document.getElementById("edu-me");if(!n){if(c)c.remove();return;}
  if(!c){c=document.createElement("button");c.type="button";c.id="edu-me";c.title="تغيير الاسم";c.onclick=function(){gate("guest");};document.body.appendChild(c);}
  var gr="";try{gr=localStorage.getItem("edu:grade")||"";}catch(e){}var GNs=["","الأول","الثاني","الثالث","الرابع","الخامس","السادس","السابع","الثامن","التاسع","العاشر","الحادي عشر","الثاني عشر"];
  var _r=window.STP&&STP.me&&STP.me.role;c.textContent=(_r==="parent"?"👨‍👩‍👧 ":_r==="student"?"🎓 ":_r==="member"?"🙋 ":G()==="f"?"👩‍🏫 ":"👨‍🏫 ")+n+(gr&&GNs[+gr]&&!(window.STP&&STP.me)?" • الصف "+GNs[+gr]:"");}
window.EDU_ME=meChip;window.addEventListener("load",function(){if(window.STP&&STP.ready)STP.ready.then(function(){if(NM())meChip();});});
/* تسجيل الزيارة في البوابة (عدد الزوار وتنبيه المسؤول بالزائر الجديد) */
function vid(){var v="";try{v=localStorage.getItem(VKEY)||"";}catch(e){}if(!/^[a-z0-9]{16,40}$/.test(v)){var a=new Uint8Array(12);(window.crypto||{getRandomValues:function(x){for(var i=0;i<x.length;i++)x[i]=Math.random()*256|0;return x;}}).getRandomValues(a);
  v=Array.prototype.map.call(a,function(b){return ("0"+b.toString(16)).slice(-2);}).join("");try{localStorage.setItem(VKEY,v);}catch(e){}}return v;}
function ping(hb){if(location.protocol.indexOf("http")!==0||!NM()||!window.STP||!STP.ready)return;
  STP.ready.then(function(){var ns=false;try{ns=!sessionStorage.getItem("edu:sess");sessionStorage.setItem("edu:sess","1");}catch(e){}
    return STP.post("visit",{vid:vid(),name:NM(),gender:G()||"m",new_session:ns&&!hb,hb:!!hb});}).catch(function(){});}
window.EDU_PING=ping;
function startVisit(){meChip();ping(false);setInterval(function(){if(!document.hidden)ping(true);},120000);}
var NEEDG=function(){var g="";try{g=localStorage.getItem("edu:grade")||"";}catch(e){}return !g;};
if((!G()||!NM()||NEEDG()||/[?&]gate=1/.test(location.search))&&!/^#live=/.test(location.hash)){gate();
  /* المعلم المسجّل في البوابة: يُؤخذ اسمه وصيغته من حسابه مباشرة دون نافذة الاختيار */
  if(window.STP&&STP.ready)STP.ready.then(function(me){if(!me||!me.name||(G()&&NM()))return;try{localStorage.setItem(GKEY,me.gender==="f"?"f":"m");localStorage.setItem(NKEY,me.name);}catch(e){}
    var d=document.getElementById("edu-gate");if(d){d.remove();document.documentElement.classList.remove("lp-lock");}walk(document.body);startVisit();});
  /* أي حساب مسجّل (معلم، طالب، مشرف، مسؤول) لا يحتاج نافذة الزائر */
  if(window.STP&&STP.ready)STP.ready.then(function(me){if(!me)return;var d=document.getElementById("edu-gate");if(d){d.remove();document.documentElement.classList.remove("lp-lock");}});}
else{walk(document.body);if(!/^#live=/.test(location.hash))startVisit();}
})();
