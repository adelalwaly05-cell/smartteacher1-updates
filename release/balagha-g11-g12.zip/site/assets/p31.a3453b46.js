/* BLG-BEGIN: الشرح البلاغي للأبيات — اضغط على أي بيت في المرحلة الثانوية ليظهر شرحه البلاغي ومصدره */
(function(){
var FILES=["assets/blg.1a527fd2.json"],DB=null,KEYS=[],P=null;
function norm(s){return String(s||"").replace(/[ً-ْٰـ«»\s.،,:؛!؟?()"\-–…]/g,"").replace(/[أإآ]/g,"ا").replace(/ى/g,"ا").replace(/ة/g,"ه");}
function load(){if(P)return P;P=Promise.all(FILES.map(function(f){return fetch(f).then(function(r){return r.json();}).catch(function(){return {};});})).then(function(L){DB={};L.forEach(function(o){for(var k in o)DB[k]=o[k];});KEYS=Object.keys(DB).filter(function(k){return k.length>=10;}).sort(function(a,b){return b.length-a.length;});return DB;});return P;}
function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
var css=".blg-hint{cursor:help}.blg-on{outline:2px dashed #b45309;outline-offset:2px;border-radius:6px}"+
"#blg{position:fixed;z-index:2147483100;left:16px;top:84px;width:min(440px,calc(100vw - 32px));max-height:min(70vh,620px);display:flex;flex-direction:column;background:#fffdf7;color:#1f2937;border:1px solid #e7d9b8;border-radius:16px;box-shadow:0 18px 48px rgba(31,41,55,.28);font:500 15px/1.75 Tajawal,'Noto Naskh Arabic',sans-serif;direction:rtl}"+
"#blg .bh{display:flex;align-items:center;gap:8px;padding:10px 14px;background:linear-gradient(135deg,#7c2d12,#b45309);color:#fff;border-radius:16px 16px 0 0;cursor:move;user-select:none;touch-action:none}"+
"#blg .bh b{flex:1;font-size:15px}#blg .bh button{background:rgba(255,255,255,.18);border:0;color:#fff;width:30px;height:30px;border-radius:9px;font-size:17px;cursor:pointer}"+
"#blg .bb{overflow:auto;padding:12px 16px 14px}#blg .bv{display:grid;gap:2px;text-align:center;font:700 17px/1.8 'Amiri','Noto Naskh Arabic',serif;color:#7c2d12;background:#fbf3e2;border-radius:12px;padding:8px 10px;margin-bottom:8px}"+
"#blg .bp{font-size:12.5px;color:#6b7280;margin-bottom:6px}#blg ol{margin:0;padding:0 22px 0 0;list-style:arabic-indic}#blg li{margin:0 0 6px}"+
"#blg .bs{margin-top:10px;padding-top:8px;border-top:1px dashed #e7d9b8;font-size:12.5px;color:#92400e}#blg .bs b{color:#7c2d12}"+
"@media (prefers-color-scheme:dark){#blg{background:#1f1a14;color:#f3e9d7;border-color:#4a3b26}#blg .bv{background:#2b2218;color:#f5c27a}#blg .bp{color:#c9b99b}#blg .bs{color:#f0b46a;border-color:#4a3b26}#blg .bs b{color:#f5c27a}}"+
"@media print{#blg{display:none!important}}";
var st=document.createElement("style");st.textContent=css;document.head.appendChild(st);
/* الأبيات: عرض الدرس (.hk-vr)، الشرح (.sh-bayt)، الاختبارات (.xm-vs > div) */
var SEL=".hk-vr,.sh-bayt,.xm-vs > div";
function firstHalf(el){if(el.classList.contains("hk-vr")){var s=el.querySelector(".s");return s?(s.getAttribute("data-t")||s.textContent):"";}var sp=el.querySelector("span");return sp?sp.textContent:el.textContent;}
function close(){var d=document.getElementById("blg");if(d)d.remove();document.querySelectorAll(".blg-on").forEach(function(x){x.classList.remove("blg-on");});}
function show(o,el){close();el.classList.add("blg-on");
  var d=document.createElement("div");d.id="blg";d.setAttribute("role","dialog");
  d.innerHTML='<div class="bh"><b>🎨 الشرح البلاغي</b><button type="button" data-x title="إغلاق">×</button></div><div class="bb">'+
    '<div class="bv"><span>'+esc(o.v[0])+'</span><span>'+esc(o.v[1])+'</span></div>'+(o.p?'<div class="bp">📖 '+esc(o.p)+'</div>':'')+
    '<ol>'+o.b.map(function(x){return '<li>'+esc(x)+'</li>';}).join("")+'</ol>'+
    '<div class="bs"><b>📚 المصدر:</b> '+esc(o.s)+'</div></div>';
  document.body.appendChild(d);
  try{var p=JSON.parse(localStorage.getItem("blg:pos")||"null");if(p){d.style.left=Math.max(0,Math.min(innerWidth-80,p.x))+"px";d.style.top=Math.max(0,Math.min(innerHeight-60,p.y))+"px";}}catch(e){}
  d.querySelector("[data-x]").onclick=close;
  var h=d.querySelector(".bh"),dr=null;
  h.addEventListener("pointerdown",function(e){if(e.target.closest("button"))return;var r=d.getBoundingClientRect();dr={x:e.clientX,y:e.clientY,l:r.left,t:r.top};h.setPointerCapture(e.pointerId);});
  h.addEventListener("pointermove",function(e){if(!dr)return;d.style.left=(dr.l+e.clientX-dr.x)+"px";d.style.top=(dr.t+e.clientY-dr.y)+"px";});
  h.addEventListener("pointerup",function(){if(!dr)return;dr=null;var r=d.getBoundingClientRect();try{localStorage.setItem("blg:pos",JSON.stringify({x:r.left,y:r.top}));}catch(e){}});}
document.addEventListener("click",function(e){var el=e.target.closest&&e.target.closest(SEL);if(!el)return;
  if(document.querySelector("#wb.wb-on:not(.wb-win)"))return;
  var k=norm(firstHalf(el));if(!k)return;
  load().then(function(db){var o=db[k];if(!o)return;if(el.classList.contains("blg-on")&&document.getElementById("blg")){close();return;}show(o,el);});},true);
/* بيت مذكور داخل نص (أمثلة، تدريبات، أسئلة) في عرض الدرس أو الشرح أو الاختبار */
document.addEventListener("click",function(e){var t=e.target;if(!t.closest||t.closest(SEL)||t.closest("#blg,button,a,input,textarea,select,[data-r],[contenteditable]"))return;
  if(!t.closest("#hdk,#sh,.sh-box,.xm-wrap,.xm-doc"))return;
  var el=t.closest("li,p,td,.hk-li > div,.hk-txt,div");if(!el)return;var tx=el.textContent||"";if(tx.length>700)return;
  load().then(function(){var n=norm(tx),k=null;for(var i=0;i<KEYS.length;i++)if(n.indexOf(KEYS[i])>-1){k=KEYS[i];break;}if(!k)return;
    if(el.classList.contains("blg-on")&&document.getElementById("blg")){close();return;}show(DB[k],el);});},true);
document.addEventListener("keydown",function(e){if(e.key==="Escape")close();});
/* تلميح: إظهار مؤشر المساعدة على الأبيات التي لها شرح */
function mark(){if(!DB)return;document.querySelectorAll(SEL).forEach(function(el){if(el.__blg)return;el.__blg=1;if(DB[norm(firstHalf(el))]){el.classList.add("blg-hint");el.title="اضغط لعرض الشرح البلاغي";}});}
load().then(function(){mark();new MutationObserver(function(){clearTimeout(mark.t);mark.t=setTimeout(mark,250);}).observe(document.body,{childList:true,subtree:true});});
window.BLG={load:load,norm:norm};
})();
/* BLG-END */
