/* SXP-BEGIN: الشرح التفصيلي المبسّط لدرسي «أغراض التشبيه» و«بلاغة التشبيه» (مرثية أبي ذؤيب – الصف العاشر) */
(function(){
var D=[
{g:"قبل أن نبدأ",c:"#0f766e",items:[
{t:"ما التشبيه؟ وما أركانه؟",i:"🧩",
 s:["التشبيه: أن نعقد مقارنة بين شيئين يشتركان في صفة، فنُلحق الأول بالثاني لأنّ الصفة فيه أوضح وأقوى.","أركانه أربعة: المشبّه (الشيء الذي نصفه) – المشبّه به (الشيء الأقوى في الصفة) – أداة التشبيه (الكاف، كأنّ، مثل…) – وجه الشبه (الصفة المشتركة)."],
 ex:{q:"العلمُ كالنورِ في الهداية.",a:["المشبّه: العلم","الأداة: الكاف","المشبّه به: النور","وجه الشبه: الهداية"]},
 tip:"اسأل نفسك: مَن الذي نصفه؟ وبِمَ شبّهناه؟ وما الصفة المشتركة؟",
 qz:{q:"في «الجنديُّ كالأسدِ في الشجاعة»، المشبّه به هو:",o:["الجندي","الأسد","الشجاعة"],a:1}}]},
{g:"أغراض التشبيه",c:"#4f46e5",items:[
{t:"بيان حال المشبّه",i:"🔍",
 s:["نستخدمه حين يكون المشبّه مجهولًا لا نعرف صفته، فيأتي التشبيه ليصفه لنا ويقرّبه إلى أذهاننا.","تذكّر: المشبّه «مجهول الصفة» ← التشبيه «يعرّفنا» به."],
 ex:{q:"﴿يَوْمَ يَكُونُ النَّاسُ كَالْفَرَاشِ الْمَبْثُوثِ (٤) وَتَكُونُ الْجِبَالُ كَالْعِهْنِ الْمَنفُوشِ﴾",a:["حال الناس والجبال يوم القيامة لم نرها، فهي مجهولة لنا.","فشبّه الناس بالفراش المنتشر المضطرب، والجبال بالصوف المنفوش.","فعرفنا حالهما ← الغرض: بيان حال المشبّه."]},
 tip:"إذا كان المشبّه شيئًا لم نره أو لا نعرف صفته ← بيان حال.",
 qz:{q:"«إنّما الناسُ كالإبلِ المائةِ لا تكادُ تجدُ فيها راحلةً»، الغرض:",o:["بيان حال المشبّه","تقبيح المشبّه","بيان إمكان المشبّه"],a:0}},
{t:"تقرير حال المشبّه",i:"📌",
 s:["نستخدمه حين نعرف المعنى، لكنّه معنى عقلي (معنوي) نريد أن نثبّته في النفس ونقنع السامع به، فنضرب له مثالًا محسوسًا.","تذكّر: «معنى معنوي» + «مثال محسوس» ← تقرير وتثبيت."],
 ex:{q:"«مثَلُ المؤمنِ للمؤمنِ كاليدينِ تغسلُ إحداهما الأخرى»",a:["تعاون المؤمنين وتناصحهم معنى عقلي.","شبّهه بصورة نراها: يدان تغسل كل منهما الأخرى.","فثبت المعنى في النفس ← الغرض: تقرير حال المشبّه."]},
 tip:"المشبّه أمر معنوي (الصدق، العلم، النفس، الأخوّة…) والمشبّه به شيء محسوس ← تقرير.",
 qz:{q:"«والنفسُ كالطفلِ إن تُهمِلْه شبَّ على حبّ الرضاع…»، الغرض:",o:["بيان مقدار الحال","تقرير حال المشبّه","تزيين المشبّه"],a:1}},
{t:"بيان إمكان المشبّه",i:"🤔",
 s:["نستخدمه حين نقول عن المشبّه شيئًا غريبًا قد لا يصدّقه السامع، فنأتي بشبيه له يثبت أنّ هذا الأمر ممكن الحدوث.","يكثر في التشبيه الضمني (الذي لا يُصرَّح فيه بالتشبيه، بل يُفهم من المعنى)."],
 ex:{q:"قد يَشيبُ الفتى وليس عجيبًا ... أن يُرى النَّوْرُ في القضيبِ الرطيبِ",a:["شيب الشاب الصغير أمر غريب.","فأثبت إمكانه بالغصن الطريّ الذي يظهر فيه الزهر الأبيض.","إذن الأمر ممكن ← الغرض: بيان إمكان المشبّه."]},
 tip:"ابحث عن «أمر غريب» يحتاج إلى دليل ← بيان إمكان.",
 qz:{q:"يكثر غرض «بيان إمكان المشبّه» في التشبيه:",o:["البليغ","الضمني","التامّ"],a:1}},
{t:"بيان مقدار حال المشبّه",i:"📏",
 s:["نستخدمه حين نعرف صفة المشبّه بشكل عام، لكنّنا نريد أن نبيّن درجتها: هل هي قويّة أم ضعيفة؟ كبيرة أم صغيرة؟"],
 ex:{q:"تناول المريضُ دواءً مُرًّا كأنّه العلقمُ.",a:["نعرف أنّ الدواء مُرّ (صفة معروفة).","لكن «كأنّه العلقم» بيّنت مقدار المرارة: شديدة جدًّا.","الغرض: بيان مقدار حال المشبّه."]},
 tip:"الصفة مذكورة أو معروفة، والتشبيه يقيس «كم» هي ← مقدار.",
 qz:{q:"﴿وَمَا أَمْرُ السَّاعَةِ إِلَّا كَلَمْحِ الْبَصَرِ﴾، الغرض:",o:["بيان مقدار حال المشبّه","تقرير حال المشبّه","تزيين المشبّه"],a:0}},
{t:"تزيين المشبّه",i:"🌸",
 s:["نستخدمه لنُظهر المشبّه في صورة جميلة محبّبة، فنشبّهه بشيء جميل.","يكثر في: المدح، والرثاء، والفخر، ووصف ما تحبّه النفس."],
 ex:{q:"ما هو عبدٌ لكنّه ولدٌ ... فهو يدي والذراعُ والعضدُ",a:["الشاعر يمدح خادمه.","شبّهه بالولد في المحبة، وباليد والذراع في النفع والمعاونة.","الغرض: تزيين المشبّه."]},
 tip:"مدح أو رثاء أو فخر ومشبّه به جميل ← تزيين.",
 qz:{q:"«فإنّك شمسٌ والملوكُ كواكبٌ» قيلت في المدح، والغرض الأقرب للتزيين أم التقبيح؟",o:["التزيين","التقبيح"],a:0}},
{t:"تقبيح المشبّه",i:"🚫",
 s:["عكس التزيين: نُظهر المشبّه في صورة قبيحة منفّرة، فنشبّهه بشيء مكروه.","يكثر في: الهجاء، ووصف ما تنفر منه النفس."],
 ex:{q:"وإذا أشارَ محدِّثًا فكأنّه ... قِردٌ يُقهقِهُ أو عجوزٌ تلطِمُ",a:["المتنبي يهجو شخصًا.","شبّهه حين يتكلّم ويشير بقرد يضحك أو عجوز تلطم وجهها.","الغرض: تقبيح المشبّه."]},
 tip:"هجاء ومشبّه به مكروه ← تقبيح.",
 qz:{q:"«وتفتحُ – لا كانت – فمًا لو رأيتَه ... توهّمتَه بابًا من النار يُفتحُ»، الغرض:",o:["تزيين المشبّه","تقبيح المشبّه","بيان الحال"],a:1}},
{t:"جدول سريع للتمييز",i:"🗂️",table:[["الغرض","متى؟","كلمة مفتاحية"],["بيان الحال","المشبّه مجهول الصفة","يعرّفنا"],["تقرير الحال","معنى معنوي يحتاج مثالًا","يثبّت"],["بيان الإمكان","أمر غريب","يُثبت أنه ممكن"],["بيان المقدار","صفة معروفة إجمالًا","يقيس الدرجة"],["التزيين","مدح – رثاء – فخر","يجمّل"],["التقبيح","هجاء – ذمّ","ينفّر"]]}]},
{g:"بلاغة التشبيه",c:"#be185d",items:[
{t:"البيان والإيضاح",i:"💡",
 s:["التشبيه يجعل المعنى أوضح من الكلام العادي، ويضيف صفات أخرى لم تُذكر، ويدعونا إلى التفكير في العلاقة بين الطرفين فنستمتع."],
 ex:{q:"﴿وَلَهُ الْجَوَارِ الْمُنشَآتُ فِي الْبَحْرِ كَالْأَعْلَامِ﴾",a:["الجواري: السفن، والأعلام: الجبال.","التشبيه أوضح ضخامة السفن أكثر من قولنا: «السفن كبيرة».","وأضاف صفة الثبات والثقل ← البيان والإيضاح."]},
 tip:"قارن التشبيه بالكلام العادي: أيّهما أوضح؟",
 qz:{q:"بلاغة التشبيه في الآية السابقة تتمثّل في:",o:["البيان والإيضاح","الإيجاز فقط","التقبيح"],a:0}},
{t:"المبالغة في المدح أو الذمّ",i:"📈",
 s:["عندما نشبّه شخصًا بشيء أقوى منه في الصفة، نرفع درجة الصفة عنده، فنبالغ في مدحه أو ذمّه."],
 ex:{q:"«زيدٌ شجاع» ← «زيدٌ كالأسد»",a:["الجملة الأولى وصف عادي.","في الثانية شبّهنا زيدًا بالأسد وهو أشجع منه، فصارت شجاعته أعظم.","وأضفنا معنى الهيبة والقوّة ← المبالغة في المدح."]},
 tip:"المشبّه به أقوى في الصفة ← مبالغة.",
 qz:{q:"أيّهما أبلغ في المدح؟",o:["زيدٌ كريم","زيدٌ كالبحر"],a:1}},
{t:"الإيجاز",i:"✂️",
 s:["كلّما حذفنا أداة التشبيه أصبح التعبير أقصر وأقوى؛ لأنّنا كأنّنا نقول: المشبّه هو المشبّه به نفسه."],
 ex:{q:"«زيدٌ كالأسد» ← «زيدٌ أسدٌ»",a:["حذفنا الكاف فصار الكلام أوجز.","وادّعينا أنّ زيدًا هو الأسد نفسه.","لذلك «زيدٌ أسدٌ» أبلغ من «زيدٌ كالأسد»."]},
 tip:"حذف الأداة = إيجاز + قوّة.",
 qz:{q:"«زيدٌ أسدٌ» أبلغ من «زيدٌ كالأسد» لأنّ:",o:["فيه أداة تشبيه","جعل المشبّه عين المشبّه به وأوجز","فيه وجه شبه"],a:1}},
{t:"الطرافة وبُعد الخيال",i:"🎨",
 s:["أجمل التشبيهات ما ينقلك إلى صورة غريبة بعيدة لا تخطر على البال، وفيها خيال واسع.","أمّا التشبيه الواضح القريب جدًّا (مثل: الأرض تشبه الكرة) فلا يُعدّ بليغًا."],
 ex:{q:"كأنّه عاشقٌ قد مدَّ صفحتَه ... يومَ الوداعِ إلى توديعِ مُرتحِلِ",a:["الأُخيطل يصف رجلًا مصلوبًا قد بسط ذراعيه.","شبّهه بعاشق يمدّ عنقه ليودّع حبيبه المسافر.","صورة طريفة بعيدة مليئة بالخيال ← الطرافة وبُعد المرمى."]},
 tip:"كلّما كانت الصورة أبعد وأغرب وأجمل ← أبلغ.",
 qz:{q:"«الأرض تشبه الكرة في الشكل» ليس فيه أثر بلاغي لأنّ:",o:["الشبه ظاهر قريب","فيه خيال واسع","حُذفت أداته"],a:0}},
{t:"مراتب التشبيه (سلّم البلاغة)",i:"🪜",
 steps:[["١","العلمُ نورٌ","البليغ (المؤكّد المجمل): بلا أداة ولا وجه شبه – الأقوى"],["٢","العلمُ نورٌ في الهداية","المؤكّد المفصّل: بلا أداة مع وجه الشبه"],["٣","العلمُ كالنور","المرسل المجمل: بأداة بلا وجه شبه"],["٤","العلمُ كالنورِ في الهداية","المرسل المفصّل (التامّ): كل الأركان – الأضعف"]],
 s:["قاعدة ذهبية: كلّما حذفنا ركنًا (الأداة أو وجه الشبه) ارتفعت درجة التشبيه في البلاغة."],
 tip:"التشبيه البليغ أبلغ الأنواع، والتشبيه التامّ أقلّها.",
 qz:{q:"أبلغ أنواع التشبيه:",o:["التامّ","المرسل المجمل","البليغ"],a:2}}]}];
var css="#sxb{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;margin:0 0 14px;padding:14px 18px;border:0;border-radius:18px;background:linear-gradient(135deg,#4f46e5,#be185d);color:#fff;font:800 clamp(16px,2.2vw,21px) Tajawal,sans-serif;cursor:pointer;box-shadow:0 10px 26px rgba(79,70,229,.3)}#sxb:hover{filter:brightness(1.07)}"+
"#sxw{position:fixed;z-index:2147483200;left:calc(97vw - min(760px,94vw));top:15vh;width:min(760px,94vw);height:min(80vh,820px);display:flex;flex-direction:column;background:#fffdf8;border-radius:20px;box-shadow:0 24px 70px rgba(30,27,75,.35);border:1px solid #e0dcf5;direction:rtl;font-family:Tajawal,'Noto Naskh Arabic',sans-serif;color:#1f2937;resize:both;overflow:hidden;min-width:300px;min-height:300px}"+
"#sxw.max{left:0!important;top:0!important;width:100vw!important;height:100vh!important;border-radius:0}"+
"#sxw .h{display:flex;align-items:center;gap:8px;padding:10px 14px;background:linear-gradient(135deg,#312e81,#6d28d9);color:#fff;cursor:move;user-select:none;touch-action:none}#sxw .h b{flex:1;font-size:18px}"+
"#sxw .h button{border:0;background:rgba(255,255,255,.18);color:#fff;min-width:38px;height:36px;border-radius:10px;font-size:16px;font-weight:800;cursor:pointer;padding:0 8px}"+
"#sxw .bd{flex:1;overflow:auto;padding:16px 18px 26px;font-size:calc(18px * var(--z,1));line-height:1.9;container-type:inline-size}"+
"#sxw .gp{margin:0 0 16px}#sxw .gp h3{margin:0 0 8px;font-size:1.15em;color:var(--c);display:flex;align-items:center;gap:8px}#sxw .gp h3:before{content:'';width:6px;height:1.1em;border-radius:3px;background:var(--c)}"+
"#sxw .ls{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}"+
"#sxw .it{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:14px;border:2px solid color-mix(in srgb,var(--c) 30%,#fff);background:#fff;font:700 1em Tajawal,sans-serif;color:#1f2937;cursor:pointer;text-align:right}#sxw .it:hover{background:color-mix(in srgb,var(--c) 10%,#fff)}#sxw .it i{font-style:normal;font-size:1.3em}"+
"#sxw .bk{border:0;background:#ede9fe;color:#4c1d95;border-radius:10px;padding:6px 14px;font:800 .85em Tajawal,sans-serif;cursor:pointer;margin-bottom:10px}"+
"#sxw h2{margin:0 0 10px;font-size:1.45em;color:var(--c)}#sxw .tg{display:inline-block;font-size:.75em;font-weight:800;color:#fff;background:var(--c);border-radius:20px;padding:1px 12px;margin-bottom:6px}"+
"#sxw .sp{background:#fff;border-radius:14px;border-right:5px solid var(--c);padding:10px 14px;margin:0 0 12px;box-shadow:0 2px 10px rgba(0,0,0,.04)}#sxw .sp p{margin:0 0 6px}"+
"#sxw .ex{background:#fff7ed;border:1px dashed #fdba74;border-radius:14px;padding:12px 14px;margin:0 0 12px}#sxw .ex .q{font-family:Amiri,serif;font-weight:700;font-size:1.25em;color:#7c2d12;text-align:center;margin-bottom:8px;line-height:1.8}#sxw .ex ol{margin:0;padding-right:22px}"+
"#sxw .tp{background:#ecfdf5;border-radius:12px;padding:8px 12px;margin:0 0 12px;color:#065f46;font-weight:700}"+
"#sxw .qz{background:#eef2ff;border-radius:14px;padding:12px 14px}#sxw .qz .o{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}#sxw .qz button{border:2px solid #c7d2fe;background:#fff;border-radius:12px;padding:6px 14px;font:700 .95em Tajawal,sans-serif;cursor:pointer}#sxw .qz button.ok{background:#dcfce7;border-color:#16a34a}#sxw .qz button.no{background:#fee2e2;border-color:#dc2626}"+
"#sxw table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden}#sxw th{background:#4f46e5;color:#fff;padding:8px}#sxw td{border-bottom:1px solid #e5e7eb;padding:8px;text-align:center}"+
"#sxw .st{display:grid;gap:8px;margin-bottom:12px}#sxw .st div{display:grid;grid-template-columns:2.2em 1fr;gap:8px;align-items:center;background:#fff;border-radius:12px;padding:8px 10px;border:1px solid #fbcfe8}#sxw .st b{display:grid;place-items:center;width:2em;height:2em;border-radius:50%;background:#be185d;color:#fff}#sxw .st em{font-style:normal;font-family:Amiri,serif;font-weight:700;color:#7c2d12;font-size:1.15em}#sxw .st small{display:block;color:#4b5563;font-size:.85em}"+
"#sxw .nv{display:flex;justify-content:space-between;gap:8px;margin-top:14px}#sxw .nv button{border:0;background:#4f46e5;color:#fff;border-radius:12px;padding:8px 14px;font:800 .9em Tajawal,sans-serif;cursor:pointer}"+
"@media print{#sxw,#sxb{display:none!important}}";
var st=document.createElement("style");st.textContent=css;document.head.appendChild(st);
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
var FLAT=[];D.forEach(function(g,gi){g.items.forEach(function(it,ii){FLAT.push([gi,ii]);});});
var W=null,Z=1;try{Z=+localStorage.getItem("sx:z")||1;}catch(e){}
function home(focus){var h="";D.forEach(function(g,gi){if(focus&&g.g!=="قبل أن نبدأ"&&g.g!==focus)return;h+='<div class="gp" style="--c:'+g.c+'"><h3>'+esc(g.g)+'</h3><div class="ls">'+g.items.map(function(it,ii){return '<button class="it" data-o="'+gi+'-'+ii+'"><i>'+it.i+'</i>'+esc(it.t)+'</button>';}).join("")+'</div></div>';});
 if(focus)h+='<button class="bk" data-all>عرض كل العناصر (الدرسين معًا)</button>';body(h);}
function show(gi,ii){var g=D[gi],it=g.items[ii],h='<button class="bk" data-home>→ القائمة</button><div style="--c:'+g.c+'"><span class="tg">'+esc(g.g)+'</span><h2>'+it.i+' '+esc(it.t)+'</h2>';
 if(it.steps)h+='<div class="st">'+it.steps.map(function(s){return '<div><b>'+s[0]+'</b><span><em>'+esc(s[1])+'</em><small>'+esc(s[2])+'</small></span></div>';}).join("")+'</div>';
 if(it.s)h+='<div class="sp">'+it.s.map(function(p){return '<p>'+esc(p)+'</p>';}).join("")+'</div>';
 if(it.table)h+='<table><tr>'+it.table[0].map(function(x){return '<th>'+esc(x)+'</th>';}).join("")+'</tr>'+it.table.slice(1).map(function(r){return '<tr>'+r.map(function(x,i){return '<td'+(i?'':' style="font-weight:800;color:#4f46e5"')+'>'+esc(x)+'</td>';}).join("")+'</tr>';}).join("")+'</table>';
 if(it.ex)h+='<div class="ex"><div style="font-weight:800;color:#c2410c;margin-bottom:4px">✍️ مثال وتحليله</div><div class="q">'+esc(it.ex.q)+'</div><ol>'+it.ex.a.map(function(x){return '<li>'+esc(x)+'</li>';}).join("")+'</ol></div>';
 if(it.tip)h+='<div class="tp">💡 كيف أعرفه في الاختبار؟ '+esc(it.tip)+'</div>';
 if(it.qz)h+='<div class="qz"><b>🎯 اختبر نفسك:</b> '+esc(it.qz.q)+'<div class="o">'+it.qz.o.map(function(o,k){return '<button data-q="'+k+'" data-a="'+it.qz.a+'">'+esc(o)+'</button>';}).join("")+'</div><div class="fb" style="margin-top:6px;font-weight:800"></div></div>';
 var k=-1;FLAT.forEach(function(f,j){if(f[0]===gi&&f[1]===ii)k=j;});
 h+='<div class="nv">'+(k<FLAT.length-1?'<button data-go="'+FLAT[k+1].join("-")+'">التالي ←</button>':'<span></span>')+(k>0?'<button data-go="'+FLAT[k-1].join("-")+'">→ السابق</button>':'<span></span>')+'</div></div>';body(h);}
function body(h){var b=W.querySelector(".bd");b.innerHTML=h;b.scrollTop=0;}
function open(focus){if(W){W.remove();}W=document.createElement("div");W.id="sxw";W.style.setProperty("--z",Z);
 W.innerHTML='<div class="h"><b>📘 الشرح التفصيلي المبسّط</b><button data-zm="-">أ−</button><button data-zm="+">أ+</button><button data-mx title="تكبير">⛶</button><button data-x title="إغلاق">✕</button></div><div class="bd"></div>';
 document.body.appendChild(W);home(focus);
 try{var p=JSON.parse(localStorage.getItem("sx:pos")||"null");if(p){W.style.left=Math.max(0,Math.min(innerWidth-120,p.x))+"px";W.style.top=Math.max(0,Math.min(innerHeight-80,p.y))+"px";}}catch(e){}
 W.addEventListener("click",function(e){var t=e.target.closest("button");if(!t)return;
  if(t.hasAttribute("data-x")){W.remove();W=null;return;}
  if(t.hasAttribute("data-mx")){W.classList.toggle("max");return;}
  if(t.dataset.zm){Z=Math.max(.7,Math.min(2.2,Z+(t.dataset.zm==="+"?.1:-.1)));W.style.setProperty("--z",Z);try{localStorage.setItem("sx:z",Z);}catch(e){}return;}
  if(t.hasAttribute("data-home")){home(focus);return;}if(t.hasAttribute("data-all")){home(null);return;}
  if(t.dataset.o||t.dataset.go){var v=(t.dataset.o||t.dataset.go).split("-");show(+v[0],+v[1]);return;}
  if(t.dataset.q!==undefined){var ok=t.dataset.q===t.dataset.a,box=t.closest(".qz");box.querySelectorAll("button").forEach(function(x){x.classList.remove("ok","no");if(x.dataset.q===x.dataset.a&&ok)x.classList.add("ok");});t.classList.add(ok?"ok":"no");box.querySelector(".fb").textContent=ok?"✅ أحسنت! إجابة صحيحة.":"❌ حاول مرة أخرى.";}});
 var hd=W.querySelector(".h"),dr=null;
 hd.addEventListener("pointerdown",function(e){if(e.target.closest("button")||W.classList.contains("max"))return;var r=W.getBoundingClientRect();dr={x:e.clientX,y:e.clientY,l:r.left,t:r.top};hd.setPointerCapture(e.pointerId);});
 hd.addEventListener("pointermove",function(e){if(!dr)return;W.style.left=(dr.l+e.clientX-dr.x)+"px";W.style.top=(dr.t+e.clientY-dr.y)+"px";});
 hd.addEventListener("pointerup",function(){if(!dr)return;dr=null;var r=W.getBoundingClientRect();try{localStorage.setItem("sx:pos",JSON.stringify({x:r.left,y:r.top}));}catch(e){}});}
document.addEventListener("keydown",function(e){if(e.key==="Escape"&&W){W.remove();W=null;}});
/* زر في صفحة الدرسين فقط */
function which(){var h=decodeURIComponent(location.hash||"");if(h.indexOf("#/arabic/sec/10/")!==0)return null;var t=(document.getElementById("el-title")||{}).textContent||"",c=(document.getElementById("el-crumbs")||{}).textContent||"";
 if(c.indexOf("مرثية")<0&&t.indexOf("مرثية")<0)return null;if(t.indexOf("أغراض التشبيه")>-1)return "أغراض التشبيه";if(t.indexOf("بلاغة التشبيه")>-1)return "بلاغة التشبيه";return null;}
function place(){var v=document.getElementById("el-view"),w=which(),b=document.getElementById("sxb");
 if(!v||!w){if(b)b.remove();return;}if(b&&b.parentNode===v&&b.dataset.w===w)return;if(b)b.remove();
 b=document.createElement("button");b.id="sxb";b.type="button";b.dataset.w=w;b.innerHTML="📘 الشرح التفصيلي المبسّط: "+w+" <span style='font-size:.8em;opacity:.9'>(اضغط لفتح القائمة)</span>";
 b.onclick=function(){open(w);};v.insertBefore(b,v.firstChild);}
var tm;new MutationObserver(function(){clearTimeout(tm);tm=setTimeout(place,120);}).observe(document.body,{childList:true,subtree:true});
addEventListener("hashchange",function(){setTimeout(place,300);});setTimeout(place,600);
window.SXP={open:open};
})();
/* SXP-END */
