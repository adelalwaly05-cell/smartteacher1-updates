
(function(){
var AN="٠١٢٣٤٥٦٧٨٩";function an(n){return String(n).replace(/\d/g,function(d){return AN[d];});}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
function qreq(h){h=String(h);var i=h.indexOf("⁣");if(i<0)return h;var r=h.slice(0,i).replace(/\s*[–-]\s*$/,"").trim(),t=h.slice(i+1).trim();if(!r)return t;return '<span class="q-req"><b>المطلوب:</b> '+r+'</span><span class="q-item">'+t+'</span>';}
function qtx(s){return qreq(esc(s)).replace(/﴿([^﴾]+)﴾/g,'<span class="q">﴿$1﴾</span>').replace(window.__EMO(),'<span class="gemo">$1</span>');}
function shuffle(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),t=a[i];a[i]=a[j];a[j]=t;}return a;}
function lock(on){document.documentElement.classList.toggle("lp-lock",on);}
var IC={x:'<path d="M6 6l12 12M18 6 6 18"/>',snd:'<path d="M4 9v6h4l5 4V5L8 9Z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
 mute:'<path d="M4 9v6h4l5 4V5L8 9Z"/><path d="m17 9 5 6M22 9l-5 6"/>',lad:'<path d="M7 3v18M17 3v18M7 7h10M7 12h10M7 17h10"/>',
 aud:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',ph:'<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>'};
function ico(n){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+IC[n]+'</svg>';}

/* ================= من سيربح المليون ================= */
var LADDER=[100,200,300,500,1000,2000,4000,8000,16000,32000,64000,125000,250000,500000,1000000];
/* سلّم جوائز بطول عدد أسئلة الدرس كلها (ينتهي دائمًا بالمليون) */
function ladderFor(n){if(n<=15)return LADDER.slice(15-n);var out=[];for(var i=0;i<n;i++){var v=100*Math.pow(10000,i/(n-1)),m=Math.pow(10,Math.floor(Math.log10(v))-1);out.push(Math.round(v/m)*m);}out[n-1]=1000000;return out;}
function money(n){return an(n.toLocaleString("en-US")).replace(/,/g,"٬");}
var actx=null,muted=false,gxKill=0;
/* عند إغلاق أي لعبة (بزر الإغلاق أو بزر الرجوع): إيقاف كل الأصوات المجدولة فورًا ومنع أي صوت متأخر منها */
var GXSEL="#mlg,#tug,.gx";
function gxOpen(){return !!document.querySelector(GXSEL);}
function gxSilence(){gxKill=Date.now()+5000;try{if(actx){actx.close();actx=null;}}catch(e){actx=null;}try{window.speechSynthesis&&speechSynthesis.cancel();}catch(e){}
  document.querySelectorAll("audio,video").forEach(function(m){try{if(!m.closest("#wb,#qd"))m.pause();}catch(e){}});}
(function(){var was=false;new MutationObserver(function(){var now=gxOpen();if(was&&!now)gxSilence();if(now&&!was)gxKill=0;was=now;}).observe(document.body,{childList:true});})();
function gxMute(){return !gxOpen()&&Date.now()<gxKill;}
function tone(seq){if(muted||gxMute())return;try{actx=actx||new (window.AudioContext||window.webkitAudioContext)();var t=actx.currentTime;
  seq.forEach(function(s){var o=actx.createOscillator(),g=actx.createGain();o.type=s[3]||"sine";o.frequency.value=s[0];g.gain.setValueAtTime(.0001,t+s[1]);
    g.gain.exponentialRampToValueAtTime(.18,t+s[1]+.02);g.gain.exponentialRampToValueAtTime(.0001,t+s[1]+s[2]);o.connect(g);g.connect(actx.destination);o.start(t+s[1]);o.stop(t+s[1]+s[2]+.05);});}catch(e){}}
var SND={ok:[[523,0,.15],[659,.12,.15],[784,.24,.15],[1047,.36,.35]],no:[[200,0,.5,"sawtooth"],[150,.25,.6,"sawtooth"]],sel:[[440,0,.25,"triangle"],[440,.35,.25,"triangle"]],
 tick:[[880,0,.05,"square"]],win:[[523,0,.2],[659,.15,.2],[784,.3,.2],[1047,.45,.2],[784,.65,.15],[1047,.8,.6]],life:[[700,0,.12],[900,.1,.15]]};

function openMLG(pool,title){
  if(!pool||pool.length<3)return alert("لا توجد أسئلة كافية لهذه اللعبة بعد.");
  var el=document.createElement("div");el.id="mlg";el.setAttribute("role","dialog");el.setAttribute("aria-label","من سيربح المليون");
  el.innerHTML='<div class="mg-top"><button class="mg-ib" data-a="x" aria-label="إغلاق">'+ico("x")+'</button><button class="mg-ib" data-a="snd" aria-label="الصوت">'+ico("snd")+'</button>'+
    '<div class="mg-title">من سيربح المليون؟</div><span class="mg-cur"></span><button class="mg-ib mg-lt" data-a="lad" aria-label="سلّم الجوائز">'+ico("lad")+'</button></div>'+
    '<div class="mg-main"><div class="mg-stage"></div><aside class="mg-ladder"></aside></div>';
  document.body.appendChild(el);lock(true);
  var stage=el.querySelector(".mg-stage"),ladEl=el.querySelector(".mg-ladder"),cur=el.querySelector(".mg-cur");
  var qs,prizes,safe,lvl,life,timer=null,tleft,busy,removed,paused=false,tsec=30;
  try{var _t=localStorage.getItem("mlg:ts");if(_t!==null&&!isNaN(+_t))tsec=+_t;}catch(e){}
  function close(){clearInterval(timer);el.remove();lock(!!document.getElementById("gmh"));document.removeEventListener("keydown",key);}
  function key(e){if(e.key==="Escape")close();}
  document.addEventListener("keydown",key);
  el.querySelector(".mg-top").onclick=function(e){var b=e.target.closest("[data-a]");if(!b)return;var a=b.getAttribute("data-a");
    if(a==="x")close();else if(a==="snd"){muted=!muted;b.innerHTML=ico(muted?"mute":"snd");}else if(a==="lad")el.classList.toggle("show-ladder");};
  ladEl.onclick=function(){el.classList.remove("show-ladder");};
  function drawLadder(){ladEl.innerHTML=prizes.map(function(p,i){return '<div class="mg-step'+(safe.indexOf(i)>-1?' safe':'')+(i<lvl?' done':'')+(i===lvl?' now':'')+'"><i>'+an(i+1)+'</i><span>'+money(p)+'</span></div>';}).join("");
    cur.textContent=lvl<prizes.length?"السؤال "+an(lvl+1)+" • "+money(prizes[lvl]):"";}
  function guaranteed(){var g=0;safe.forEach(function(i){if(i<lvl)g=prizes[i];});return g;}
  function intro(){
    stage.innerHTML='<div class="mg-card" style="align-self:center"><h3>من سيربح المليون؟</h3><p>'+esc(title||"")+'</p>'+
      '<p>أجب عن '+an((pool.lesson||pool).length)+' سؤالًا متتاليًا بترتيب الكتاب لتصل إلى <b style="color:#ffd76a">المليون</b>.</p><p>معك ثلاث وسائل مساعدة: حذف إجابتين، سؤال الجمهور، الاتصال بصديق. المستويات البيضاء في السلّم مبالغ مضمونة.</p>'+
      '<p style="margin-top:12px"><b>وقت كل سؤال</b></p><div class="mg-opts">'+[[15,"١٥ ث"],[30,"٣٠ ث"],[45,"٤٥ ث"],[60,"٦٠ ث"],[90,"٩٠ ث"],[0,"بلا وقت"]].map(function(o){
        return '<button data-ts="'+o[0]+'" class="'+(o[0]===tsec?'on':'')+'">'+o[1]+'</button>';}).join("")+'</div>'+
      '<p class="mg-hint">أثناء اللعب: اضغط على العدّاد لإيقافه مؤقتًا أو تشغيله، وزر (+١٠) يضيف ١٠ ثوانٍ.</p>'+
      '<button class="mg-go" data-go>ابدأ اللعب</button></div>';
    stage.querySelectorAll("[data-ts]").forEach(function(b){b.onclick=function(){tsec=+b.getAttribute("data-ts");try{localStorage.setItem("mlg:ts",tsec);}catch(e){}
      stage.querySelectorAll("[data-ts]").forEach(function(x){x.classList.toggle("on",x===b);});};});
    stage.querySelector("[data-go]").onclick=start;
  }
  function start(){
    qs=(pool.lesson||pool).map(function(q){var o=q.c.map(function(t,k){return {t:t,ok:k===q.a};});return {q:q.q,qa:q.qa,o:o};});
    prizes=ladderFor(qs.length);var n=qs.length;safe=n>=6?[Math.round(n/3)-1,Math.round(2*n/3)-1]:[Math.floor(n/2)-1];
    lvl=0;life={half:true,aud:true,ph:true};ask();
  }
  function ask(){
    busy=false;removed=[];drawLadder();var Q=qs[lvl],L="أبجد";
    stage.innerHTML='<div class="mg-life"><button class="mg-lf" data-l="half"'+(life.half?'':' disabled')+'>٥٠:٥٠</button>'+
      '<button class="mg-lf" data-l="aud"'+(life.aud?'':' disabled')+' aria-label="سؤال الجمهور">'+ico("aud")+'الجمهور</button>'+
      '<button class="mg-lf" data-l="ph"'+(life.ph?'':' disabled')+' aria-label="اتصال بصديق">'+ico("ph")+'صديق</button>'+
      '<button class="mg-lf walk" data-l="walk">انسحاب</button></div>'+
      '<div class="mg-tw">'+(tsec?'<button class="mg-timer" data-tm aria-label="إيقاف أو تشغيل العداد"><span>'+an(tsec)+'</span></button><button class="mg-plus" data-plus aria-label="أضف ١٠ ثوانٍ">+١٠</button>':'<div class="mg-timer off"><span>∞</span></div>')+'</div><div class="mg-q">'+qtx(Q.q)+'</div><div class="mg-ans">'+
      Q.o.map(function(o,k){return '<button class="mg-a'+(Q.qa?' qa':'')+'" data-k="'+k+'"><span><b>'+L[k]+':</b><span>'+(Q.qa?'﴿ '+esc(o.t)+' ﴾':qtx(o.t))+'</span></span></button>';}).join("")+
      '</div><div class="mg-msg"></div>';
    stage.querySelectorAll(".mg-a").forEach(function(b){b.onclick=function(){if(!busy)answer(+b.getAttribute("data-k"));};});
    stage.querySelectorAll(".mg-lf").forEach(function(b){b.onclick=function(){if(!busy&&!b.disabled)lifeline(b.getAttribute("data-l"),b);};});
    clearInterval(timer);paused=false;if(!tsec)return;
    tleft=tsec;var tmax=tsec,tm=stage.querySelector(".mg-timer");
    function show(){tm.style.setProperty("--p",(tleft/tmax*100)+"%");tm.querySelector("span").textContent=paused?"⏸":an(Math.max(tleft,0));tm.classList.toggle("low",tleft<=10&&!paused);tm.classList.toggle("paused",paused);}
    tm.onclick=function(){if(busy)return;paused=!paused;tone(SND.tick);show();};
    stage.querySelector("[data-plus]").onclick=function(){if(busy)return;tleft+=10;tmax=Math.max(tmax,tleft);tone(SND.life);show();};
    show();
    timer=setInterval(function(){if(paused||document.querySelector("#mlg .mg-pop"))return;tleft--;show();
      if(tleft<=10&&tleft>0)tone(SND.tick);if(tleft<=0){clearInterval(timer);timeUp();}},1000);
  }
  function msg(t){stage.querySelector(".mg-msg").textContent=t;}
  function answer(k){busy=true;clearInterval(timer);var Q=qs[lvl],bs=stage.querySelectorAll(".mg-a"),ok=Q.o[k].ok,ci=0;
    Q.o.forEach(function(o,j){if(o.ok)ci=j;});bs[k].classList.add("sel");msg("إجابة نهائية؟");tone(SND.sel);
    setTimeout(function(){bs[ci].classList.remove("sel");bs[ci].classList.add("ok","blink");
      if(ok){tone(SND.ok);msg("إجابة صحيحة! ربحت "+money(prizes[lvl]));setTimeout(function(){lvl++;if(lvl>=qs.length)win();else ask();},1900);}
      else{bs[k].classList.remove("sel");bs[k].classList.add("no");tone(SND.no);msg("إجابة خاطئة");setTimeout(function(){over("no");},2000);}},1500);}
  function timeUp(){busy=true;var Q=qs[lvl],bs=stage.querySelectorAll(".mg-a");Q.o.forEach(function(o,j){if(o.ok)bs[j].classList.add("ok");});tone(SND.no);msg("انتهى الوقت!");setTimeout(function(){over("time");},2000);}
  function lifeline(t,b){
    if(t==="walk"){busy=true;clearInterval(timer);return over("walk");}
    life[t]=false;b.disabled=true;tone(SND.life);var Q=qs[lvl],bs=stage.querySelectorAll(".mg-a"),ci=0,L="أبجد";Q.o.forEach(function(o,j){if(o.ok)ci=j;});
    var live=[0,1,2,3].slice(0,Q.o.length).filter(function(j){return removed.indexOf(j)<0;});
    if(t==="half"){var wrong=shuffle(live.filter(function(j){return j!==ci;})).slice(0,Math.max(0,live.length-2));removed=removed.concat(wrong);wrong.forEach(function(j){bs[j].classList.add("hide");});return;}
    var pop=document.createElement("div");pop.className="mg-pop";
    if(t==="aud"){var left=100,pc={},rest=live.filter(function(j){return j!==ci;});pc[ci]=40+Math.floor(Math.random()*35);left-=pc[ci];
      rest.forEach(function(j,i){var v=i===rest.length-1?left:Math.floor(Math.random()*left);pc[j]=v;left-=v;});
      pop.innerHTML='<div class="mg-card"><h3>رأي الجمهور</h3><div class="mg-bars">'+Q.o.map(function(o,j){return '<div class="mg-bar"><span>'+an(pc[j]||0)+'٪</span><div data-h="'+(pc[j]||0)+'"></div><span>'+L[j]+'</span></div>';}).join("")+
        '</div><button class="mg-go" data-c>متابعة</button></div>';
      setTimeout(function(){pop.querySelectorAll("[data-h]").forEach(function(d){d.style.height=d.getAttribute("data-h")+"%";});},60);}
    else{var right=Math.random()<.8,pick=right?ci:shuffle(live.filter(function(j){return j!==ci;}))[0];if(pick===undefined)pick=ci;var conf=right?70+Math.floor(Math.random()*25):40+Math.floor(Math.random()*20);
      pop.innerHTML='<div class="mg-card"><h3>اتصال بصديق</h3><p>«أهلًا! فكّرت جيدًا… أظن أن الإجابة هي <b style="color:#ffd76a">('+L[pick]+')</b>، وأنا متأكد بنسبة '+an(conf)+'٪.»</p><button class="mg-go" data-c>متابعة</button></div>';}
    el.appendChild(pop);pop.querySelector("[data-c]").onclick=function(){pop.remove();};}
  function confetti(){var c=document.createElement("div");c.className="mg-conf";var C=["#ffd76a","#ff6b8a","#6be4ff","#8dff8a","#c38bff"];
    for(var i=0;i<90;i++){var p=document.createElement("i");p.style.left=Math.random()*100+"%";p.style.background=C[i%5];p.style.animationDuration=(2+Math.random()*2.5)+"s";p.style.animationDelay=Math.random()*1.2+"s";c.appendChild(p);}
    el.appendChild(c);setTimeout(function(){c.remove();},6000);}
  function endCard(h,big,txt){drawLadder();stage.innerHTML='<div class="mg-card" style="align-self:center"><h3>'+h+'</h3><p class="mg-big">'+big+'</p><p>'+txt+'</p>'+
      '<button class="mg-go" data-r>العب مرة أخرى</button><button class="mg-go alt" data-x>إغلاق</button></div>';
    stage.querySelector("[data-r]").onclick=start;stage.querySelector("[data-x]").onclick=close;}
  function win(){tone(SND.win);confetti();endCard("مبروك! ربحت المليون",money(prizes[prizes.length-1]),"أجبت عن جميع الأسئلة إجابة صحيحة. أداء رائع!");}
  function over(why){var g=why==="walk"?(lvl>0?prizes[lvl-1]:0):guaranteed();var Q=qs[lvl],c="";Q.o.forEach(function(o){if(o.ok)c=o.t;});
    endCard(why==="walk"?"انسحبت من اللعبة":why==="time"?"انتهى الوقت":"انتهت اللعبة",money(g),
      (why==="walk"?"احتفظت بما ربحته حتى الآن.":"رصيدك المضمون هو ما تراه أعلاه.")+'<br>الإجابة الصحيحة: '+(Q.qa?'<span class="q">﴿ '+esc(c)+' ﴾</span>':qtx(c)));}
  intro();
}
window.MLG={open:openMLG};
/* ================= لعبة «شدّ الحبل» (فريقان) ================= */
var nbuf=null;
function noise(dur,f0,f1,vol,t0){if(muted||gxMute())return;try{actx=actx||new (window.AudioContext||window.webkitAudioContext)();var t=actx.currentTime+(t0||0);
  if(!nbuf){nbuf=actx.createBuffer(1,actx.sampleRate,actx.sampleRate);var d=nbuf.getChannelData(0);for(var i=0;i<d.length;i++)d[i]=Math.random()*2-1;}
  var s=actx.createBufferSource(),f=actx.createBiquadFilter(),g=actx.createGain();s.buffer=nbuf;s.loop=true;f.type="bandpass";f.Q.value=1.2;
  f.frequency.setValueAtTime(f0,t);f.frequency.exponentialRampToValueAtTime(f1,t+dur);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol||.25,t+.05);
  g.gain.exponentialRampToValueAtTime(.0001,t+dur);s.connect(f);f.connect(g);g.connect(actx.destination);s.start(t);s.stop(t+dur+.05);}catch(e){}}
var TS={ok:function(){tone([[523,0,.12],[659,.1,.12],[784,.2,.12],[1047,.3,.3]]);noise(.9,900,2500,.18,.15);},
  no:function(){tone([[220,0,.25,"sawtooth"],[165,.2,.45,"sawtooth"]]);},
  pull:function(){noise(.5,300,1400,.3);tone([[110,0,.25,"triangle"]]);},
  turn:function(){tone([[660,0,.08,"square"],[880,.09,.1,"square"]]);},
  tick:function(){tone([[1000,0,.04,"square"]]);},
  win:function(){tone([[392,0,.18],[523,.16,.18],[659,.32,.18],[784,.48,.3],[659,.8,.15],[784,.95,.6]]);noise(2.2,700,3000,.22,.2);}};
function fig(x,c,dir){var lean=dir*14;return '<g class="tg-f" style="transform-origin:'+x+'px 228px"><circle cx="'+(x+lean)+'" cy="104" r="15" fill="'+c+'"/>'+
  '<path d="M'+(x+lean*.8)+' 120 L'+x+' 180 M'+x+' 180 L'+(x-dir*16)+' 228 M'+x+' 180 L'+(x+dir*12)+' 228 M'+(x+lean*.6)+' 136 L'+(x-dir*26)+' 150 M'+(x+lean*.6)+' 140 L'+(x-dir*8)+' 150" stroke="'+c+'" stroke-width="9" stroke-linecap="round" fill="none"/></g>';}
function openTUG(pool,title){
  if(!pool||pool.length<3)return alert("لا توجد أسئلة كافية لهذه اللعبة بعد.");
  var el=document.createElement("div");el.id="tug";el.setAttribute("role","dialog");el.setAttribute("aria-label","شدّ الحبل");
  el.innerHTML='<div class="tg-top"><button class="tg-ib" data-a="x" aria-label="رجوع">'+ico("x")+'</button><button class="tg-ib" data-a="snd" aria-label="الصوت">'+ico(muted?"mute":"snd")+'</button>'+
    '<div class="tg-title">شدّ الحبل</div></div><div class="tg-body"></div>';
  document.body.appendChild(el);lock(true);
  var body=el.querySelector(".tg-body"),names=["الفريق الأزرق","الفريق الأحمر"],win=4,pos,turn,sc,qs,qi,timer=null,tl,busy;
  function close(){clearInterval(timer);el.remove();lock(!!document.getElementById("gmh"));document.removeEventListener("keydown",kd);}
  function kd(e){if(e.key==="Escape")close();}document.addEventListener("keydown",kd);
  el.querySelector(".tg-top").onclick=function(e){var b=e.target.closest("[data-a]");if(!b)return;if(b.getAttribute("data-a")==="x")close();else{muted=!muted;b.innerHTML=ico(muted?"mute":"snd");}};
  function setup(){
    body.innerHTML='<div class="tg-card"><h3>شدّ الحبل</h3><p>'+esc(title||"")+'</p><p>فريقان يتناوبان على الإجابة. كل إجابة صحيحة تشدّ الحبل نحو الفريق، ومن يوصل العُقدة إلى خطّه أولًا يفوز!</p>'+
      '<div class="tg-names"><label>الفريق الأول<input type="text" maxlength="18" value="'+esc(names[0])+'" data-n="0"></label><label>الفريق الثاني<input type="text" maxlength="18" value="'+esc(names[1])+'" data-n="1"></label></div>'+
      '<p class="tg-lbl">طول الجولة</p><div class="tg-len">'+[[3,"قصيرة"],[4,"متوسطة"],[5,"طويلة"]].map(function(x){return '<button data-w="'+x[0]+'" class="'+(x[0]===win?'on':'')+'">'+x[1]+'</button>';}).join("")+'</div>'+
      '<button class="tg-go" data-go>ابدأ التحدّي</button></div>';
    body.querySelectorAll("[data-w]").forEach(function(b){b.onclick=function(){win=+b.getAttribute("data-w");body.querySelectorAll("[data-w]").forEach(function(x){x.classList.toggle("on",x===b);});};});
    body.querySelector("[data-go]").onclick=function(){body.querySelectorAll("[data-n]").forEach(function(i){var v=i.value.trim();if(v)names[+i.getAttribute("data-n")]=v;});start();};
  }
  function start(){pos=0;turn=0;sc=[0,0];qs=[];qi=0;
    body.innerHTML='<div class="tg-score"><div class="tg-team t0"><b></b><span></span></div><div class="tg-vs">ضد</div><div class="tg-team t1"><b></b><span></span></div></div>'+
      '<div class="tg-arena"><svg viewBox="140 30 720 220" preserveAspectRatio="xMidYMid meet" aria-hidden="true">'+
      '<rect x="0" y="228" width="1000" height="22" fill="#7cc46b"/><rect x="0" y="236" width="1000" height="14" fill="#5fa84f"/>'+
      '<line x1="500" y1="40" x2="500" y2="240" stroke="#fff" stroke-width="4" stroke-dasharray="10 8"/>'+
      '<g class="tg-mk"><line x1="800" y1="60" x2="800" y2="240" stroke="#3b6cff" stroke-width="6"/><path d="M800 60h40l-12 12 12 12h-40Z" fill="#3b6cff"/>'+
      '<line x1="200" y1="60" x2="200" y2="240" stroke="#ff4d5e" stroke-width="6"/><path d="M200 60h-40l12 12-12 12h40Z" fill="#ff4d5e"/></g>'+
      '<g class="tg-rope"><path d="M-200 150 Q500 162 1200 150" stroke="#b07a3a" stroke-width="10" fill="none" stroke-linecap="round"/>'+
      '<path d="M-200 150 Q500 162 1200 150" stroke="#d9a35c" stroke-width="4" stroke-dasharray="14 10" fill="none"/>'+
      '<g transform="translate(500 156)"><path d="M0 0l-14 34h28Z" fill="#e2203a"/><circle r="11" fill="#ff3b55" stroke="#fff" stroke-width="3"/></g>'+
      '<g class="tg-side s0">'+fig(660,"#3b6cff",1)+fig(740,"#3b6cff",1)+fig(820,"#3b6cff",1)+'</g>'+
      '<g class="tg-side s1">'+fig(340,"#ff4d5e",-1)+fig(260,"#ff4d5e",-1)+fig(180,"#ff4d5e",-1)+'</g></g></svg></div>'+
      '<div class="tg-play"></div>';
    body.querySelector(".tg-team.t0 b").textContent=names[0];body.querySelector(".tg-team.t1 b").textContent=names[1];
    rope();ask();}
  function rope(){var r=body.querySelector(".tg-rope");r.style.transform="translateX("+(pos*300/win)+"px)";
    body.querySelector(".tg-team.t0 span").textContent=an(sc[0]);body.querySelector(".tg-team.t1 span").textContent=an(sc[1]);
    body.querySelector(".tg-team.t0").classList.toggle("now",turn===0);body.querySelector(".tg-team.t1").classList.toggle("now",turn===1);}
  function next(){if(qi>=qs.length){qs=qs.concat(shuffle(pool));}var q=qs[qi++],o=q.c.map(function(t,k){return {t:t,ok:k===q.a};});return {q:q.q,qa:q.qa,o:shuffle(o)};}
  function ask(){busy=false;var Q=next(),L="أبجد",play=body.querySelector(".tg-play");rope();TS.turn();
    play.innerHTML='<div class="tg-turn t'+turn+'">دور: '+esc(names[turn])+' <span class="tg-t">٢٠</span></div><div class="tg-q">'+qtx(Q.q)+'</div><div class="tg-ans">'+
      Q.o.map(function(o,k){return '<button class="tg-a'+(Q.qa?' qa':'')+'" data-k="'+k+'"><b>'+L[k]+'</b><span>'+(Q.qa?'﴿ '+esc(o.t)+' ﴾':qtx(o.t))+'</span></button>';}).join("")+'</div><div class="tg-msg"></div>';
    play.querySelectorAll(".tg-a").forEach(function(b){b.onclick=function(){if(!busy)answer(Q,+b.getAttribute("data-k"),b);};});
    tl=20;var tt=play.querySelector(".tg-t");clearInterval(timer);
    timer=setInterval(function(){tl--;tt.textContent=an(Math.max(tl,0));tt.classList.toggle("low",tl<=5);if(tl<=5&&tl>0)TS.tick();if(tl<=0){clearInterval(timer);answer(Q,-1,null);}},1000);}
  function answer(Q,k,b){busy=true;clearInterval(timer);var play=body.querySelector(".tg-play"),bs=play.querySelectorAll(".tg-a"),ok=k>-1&&Q.o[k].ok,msg=play.querySelector(".tg-msg");
    Q.o.forEach(function(o,j){if(o.ok)bs[j].classList.add("ok");});if(b&&!ok)b.classList.add("no");
    if(ok){sc[turn]++;pos+=turn===0?1:-1;TS.ok();setTimeout(TS.pull,350);msg.textContent="أحسنت! "+names[turn]+" يشدّ الحبل 💪";
      var side=body.querySelector(".tg-side.s"+turn);side.classList.remove("pull");void side.offsetWidth;side.classList.add("pull");}
    else{TS.no();msg.textContent=k<0?"انتهى الوقت! ينتقل الدور.":"إجابة خاطئة! ينتقل الدور.";}
    rope();
    setTimeout(function(){if(Math.abs(pos)>=win)return end(pos>0?0:1);turn=1-turn;ask();},2100);}
  function end(w){TS.win();var c=document.createElement("div");c.className="mg-conf";var C=w===0?["#3b6cff","#8fb0ff","#ffd76a","#fff"]:["#ff4d5e","#ffa3ad","#ffd76a","#fff"];
    for(var i=0;i<90;i++){var p=document.createElement("i");p.style.left=Math.random()*100+"%";p.style.background=C[i%4];p.style.animationDuration=(2+Math.random()*2.5)+"s";p.style.animationDelay=Math.random()*1.2+"s";c.appendChild(p);}
    el.appendChild(c);setTimeout(function(){c.remove();},6000);
    body.querySelector(".tg-play").innerHTML='<div class="tg-card tg-win t'+w+'"><h3>🏆 فاز '+esc(names[w])+'!</h3><p>النتيجة: '+esc(names[0])+' '+an(sc[0])+' — '+an(sc[1])+' '+esc(names[1])+'</p>'+
      '<button class="tg-go" data-r>جولة جديدة</button><button class="tg-go alt" data-s>تغيير الفريقين</button></div>';
    body.querySelector("[data-r]").onclick=start;body.querySelector("[data-s]").onclick=setup;}
  setup();
}
window.TUG={open:openTUG};
/* ================= أدوات مشتركة للألعاب الجديدة ================= */
function gxShell(id,title,cls){
  var el=document.createElement("div");el.id=id;el.className="gx "+(cls||"");el.setAttribute("role","dialog");el.setAttribute("aria-label",title);
  el.innerHTML='<div class="gx-top"><button class="gx-ib" data-a="x" aria-label="رجوع">'+ico("x")+'</button><button class="gx-ib" data-a="snd" aria-label="الصوت">'+ico(muted?"mute":"snd")+'</button>'+
    '<div class="gx-title">'+esc(title)+'</div><div class="gx-stat"></div></div><div class="gx-body"></div>';
  document.body.appendChild(el);lock(true);
  var api={el:el,body:el.querySelector(".gx-body"),stat:el.querySelector(".gx-stat"),onclose:null};
  function kd(e){if(e.key==="Escape")api.close();}
  api.close=function(){if(api.onclose)api.onclose();el.remove();lock(!!document.getElementById("gmh"));document.removeEventListener("keydown",kd);};
  document.addEventListener("keydown",kd);
  el.querySelector(".gx-top").onclick=function(e){var b=e.target.closest("[data-a]");if(!b)return;if(b.getAttribute("data-a")==="x")api.close();else{muted=!muted;b.innerHTML=ico(muted?"mute":"snd");}};
  return api;
}
function gxConfetti(el,C){var c=document.createElement("div");c.className="mg-conf";C=C||["#ffd76a","#ff6b8a","#6be4ff","#8dff8a","#c38bff"];
  for(var i=0;i<90;i++){var p=document.createElement("i");p.style.left=Math.random()*100+"%";p.style.background=C[i%C.length];p.style.animationDuration=(2+Math.random()*2.5)+"s";p.style.animationDelay=Math.random()*1.2+"s";c.appendChild(p);}
  el.appendChild(c);setTimeout(function(){c.remove();},6000);}
function gxMk(q){var o=q.c.map(function(t,k){return {t:t,ok:k===q.a};});return {q:q.q,qa:q.qa,o:shuffle(o)};}
function gxTxt(o,qa){return qa?'﴿ '+esc(o.t)+' ﴾':qtx(o.t);}
function gxBest(k,v){var b=0;try{b=+localStorage.getItem(k)||0;if(v>b){localStorage.setItem(k,v);return {best:v,rec:true};}}catch(e){}return {best:Math.max(b,v),rec:false};}
var GS={pop:function(){noise(.18,2500,600,.45);tone([[880,0,.08,"triangle"],[1320,.05,.12,"triangle"]]);},
  ding:function(n){var f=660*Math.pow(1.06,Math.min(n||0,12));tone([[f,0,.1],[f*1.5,.08,.18]]);},
  buzz:function(){tone([[180,0,.3,"sawtooth"]]);},
  whoosh:function(){noise(.4,400,2000,.2);},
  click:function(){tone([[1500,0,.02,"square"]]);},
  lose:function(){tone([[392,0,.2,"triangle"],[330,.2,.2,"triangle"],[262,.4,.45,"triangle"]]);},
  win:function(){tone([[523,0,.15],[659,.13,.15],[784,.26,.15],[1047,.4,.4]]);noise(1.6,800,3000,.18,.2);}};

/* ================= ١) فرقعة البالونات ================= */
function openBLN(pool,title){
  if(!pool||pool.length<3)return alert("لا توجد أسئلة كافية لهذه اللعبة بعد.");
  var short=pool.filter(function(q){return Math.max.apply(null,q.c.map(function(t){return t.length;}))<=70;});if(short.length>=3)pool=short;
  var G=gxShell("bln","فرقعة البالونات","gx-sky"),body=G.body,score,lives,round,streak,qs,qi,live=[],tmo=[];
  function clear(){tmo.forEach(clearTimeout);tmo=[];live.forEach(function(b){b.remove();});live=[];}
  G.onclose=clear;
  function stat(){G.stat.innerHTML='<span>⭐ '+an(score)+'</span><span class="gx-hearts">'+"❤️".repeat(Math.max(lives,0))+'<i>'+"🤍".repeat(Math.max(3-lives,0))+'</i></span>';}
  function intro(){G.stat.innerHTML="";body.innerHTML='<div class="gx-card"><div class="gx-emoji">🎈</div><h3>فرقعة البالونات</h3><p>'+esc(title||"")+'</p>'+
    '<p>اقرأ السؤال، ثم افقع البالون الذي يحمل الإجابة الصحيحة قبل أن يطير بعيدًا! معك ثلاث محاولات، والبالونات تُسرع كلما تقدّمت.</p><button class="gx-go" data-go>ابدأ</button></div>';
    body.querySelector("[data-go]").onclick=start;}
  function start(){score=0;lives=3;round=0;streak=0;qs=shuffle(pool);qi=0;stat();
    body.innerHTML='<div class="bl-q"></div><div class="bl-sky"><div class="bl-cloud c1"></div><div class="bl-cloud c2"></div><div class="bl-msg"></div></div>';next();}
  function next(){clear();if(lives<=0)return over();if(qi>=qs.length){qs=shuffle(pool);qi=0;}var Q=gxMk(qs[qi++]);round++;
    body.querySelector(".bl-q").innerHTML='<span class="bl-r">السؤال '+an(round)+'</span>'+qtx(Q.q);body.querySelector(".bl-msg").textContent="";
    var sky=body.querySelector(".bl-sky"),W=sky.clientWidth,H=sky.clientHeight,n=Q.o.length,lane=W/n,dur=Math.max(5.5,11-round*.45),done=false,C=["#ff5d7a","#3fa9ff","#ffc233","#45d483","#b07cff"];
    var order=shuffle(Q.o.map(function(_,i){return i;}));
    Q.o.forEach(function(o,k){var b=document.createElement("button");b.className="bl-b"+(Q.qa?" qa":"")+(o.t.length<=3?" one":"");var col=C[(k+round)%C.length];
      b.style.setProperty("--c",col);b.innerHTML='<span class="bl-in">'+gxTxt(o,Q.qa)+'</span><i class="bl-str"></i>';
      var bw=Math.min(lane-10,190);b.style.width=bw+"px";b.style.left=(order[k]*lane+(lane-bw)/2)+"px";b.style.top=(H+20)+"px";
      sky.appendChild(b);live.push(b);
      var delay=k*350+Math.random()*300;
      tmo.push(setTimeout(function(){b.style.transition="transform "+dur+"s linear";b.style.transform="translateY("+(-(H+b.offsetHeight+60))+"px)";},delay+30));
      b.addEventListener("transitionend",function(e){if(e.propertyName!=="transform"||done||b.classList.contains("gone"))return;
        if(o.ok){done=true;lives--;streak=0;stat();GS.lose();msg("طار البالون الصحيح! 🎈");reveal(Q);tmo.push(setTimeout(next,1800));}});
      b.onclick=function(){if(done||b.classList.contains("gone"))return;var r=b.getBoundingClientRect(),sr=sky.getBoundingClientRect();
        var y=r.top-sr.top;b.style.transition="none";b.style.transform="translateY(0)";b.style.top=y+"px";b.classList.add("gone");
        burst(sky,r.left-sr.left+r.width/2,y+r.height/2,o.ok?col:"#9aa3b5");
        if(o.ok){done=true;streak++;var pts=10+Math.min(streak-1,5)*5;score+=pts;GS.pop();GS.ding(streak);stat();b.classList.add("pop");
          msg((streak>1?"سلسلة ×"+an(streak)+"! ":"أحسنت! ")+"+"+an(pts));live.forEach(function(x){if(x!==b){x.classList.add("fade");}});tmo.push(setTimeout(next,1300));}
        else{lives--;streak=0;stat();GS.buzz();b.classList.add("bad");msg("ليست هذه!");if(lives<=0){done=true;reveal(Q);tmo.push(setTimeout(over,1600));}}};
    });}
  function reveal(Q){live.forEach(function(b,i){if(Q.o[i]&&Q.o[i].ok){b.classList.add("right");}else b.classList.add("fade");});}
  function msg(t){var m=body.querySelector(".bl-msg");m.textContent=t;m.classList.remove("on");void m.offsetWidth;m.classList.add("on");}
  function burst(sky,x,y,c){for(var i=0;i<14;i++){var p=document.createElement("i");p.className="bl-p";p.style.background=c;p.style.left=x+"px";p.style.top=y+"px";
      var a=Math.random()*Math.PI*2,d=40+Math.random()*60;p.style.setProperty("--dx",Math.cos(a)*d+"px");p.style.setProperty("--dy",Math.sin(a)*d+"px");sky.appendChild(p);setTimeout(function(q){return function(){q.remove();};}(p),700);}}
  function over(){clear();var b=gxBest("bln:best",score);if(b.rec&&score>0){GS.win();gxConfetti(G.el);}else GS.lose();
    body.innerHTML='<div class="gx-card"><div class="gx-emoji">'+(b.rec&&score>0?'🏆':'🎈')+'</div><h3>انتهت اللعبة</h3><p class="gx-big">'+an(score)+' نقطة</p>'+
      '<p>'+(b.rec&&score>0?'رقم قياسي جديد!':'أفضل نتيجة: '+an(b.best))+' • وصلت إلى السؤال '+an(round)+'</p><button class="gx-go" data-go>العب مرة أخرى</button><button class="gx-go alt" data-x>رجوع</button></div>';
    body.querySelector("[data-go]").onclick=start;body.querySelector("[data-x]").onclick=G.close;}
  intro();
}

/* ================= ٢) صح أم خطأ؟ (سباق الوقت) ================= */
function openTF(pool,title){
  if(!pool||pool.length<3)return alert("لا توجد أسئلة كافية لهذه اللعبة بعد.");
  var G=gxShell("tfg","صح أم خطأ؟","gx-tf"),body=G.body,dur=60,tleft,score,combo,best,answered,right,timer=null,cur,lock2;
  G.onclose=function(){clearInterval(timer);};
  function intro(){G.stat.innerHTML="";body.innerHTML='<div class="gx-card"><div class="gx-emoji">⚡</div><h3>صح أم خطأ؟</h3><p>'+esc(title||"")+'</p>'+
    '<p>تظهر عبارة: سؤال وإجابة مقترحة. قرّر بسرعة: هل الإجابة <b style="color:#16a34a">صحيحة</b> أم <b style="color:#dc2626">خاطئة</b>؟ الإجابات المتتالية الصحيحة تضاعف نقاطك!</p>'+
    '<p><b>مدة السباق</b></p><div class="gx-opts">'+[30,60,90].map(function(s){return '<button data-d="'+s+'" class="'+(s===dur?'on':'')+'">'+an(s)+' ثانية</button>';}).join("")+'</div>'+
    '<button class="gx-go" data-go>ابدأ السباق</button></div>';
    body.querySelectorAll("[data-d]").forEach(function(b){b.onclick=function(){dur=+b.getAttribute("data-d");body.querySelectorAll("[data-d]").forEach(function(x){x.classList.toggle("on",x===b);});};});
    body.querySelector("[data-go]").onclick=countdown;}
  function countdown(){var n=3;body.innerHTML='<div class="tf-cd">'+an(n)+'</div>';GS.click();
    var t=setInterval(function(){n--;var c=body.querySelector(".tf-cd");if(!c)return clearInterval(t);if(n>0){c.textContent=an(n);c.classList.remove("on");void c.offsetWidth;c.classList.add("on");GS.click();}
      else{clearInterval(t);tone([[880,0,.25]]);start();}},800);}
  function start(){tleft=dur;score=0;combo=0;best=0;answered=0;right=0;
    body.innerHTML='<div class="tf-bar"><i></i></div><div class="tf-combo"></div><div class="tf-card"><p class="tf-q"></p><div class="tf-a"></div></div>'+
      '<div class="tf-btns"><button class="tf-b yes" data-v="1"><span>✔</span>صح</button><button class="tf-b no" data-v="0"><span>✘</span>خطأ</button></div>';
    body.querySelectorAll(".tf-b").forEach(function(b){b.onclick=function(){pick(b.getAttribute("data-v")==="1");};});
    stat();deal();clearInterval(timer);
    timer=setInterval(function(){tleft--;body.querySelector(".tf-bar i").style.width=(tleft/dur*100)+"%";stat();if(tleft<=5&&tleft>0)GS.click();if(tleft<=0){clearInterval(timer);over();}},1000);}
  function stat(){G.stat.innerHTML='<span>⏱ '+an(Math.max(tleft,0))+'</span><span>⭐ '+an(score)+'</span>';}
  function deal(){lock2=false;var q=pool[Math.floor(Math.random()*pool.length)],isT=Math.random()<.5,k=q.a;
    if(!isT){var w=q.c.map(function(_,i){return i;}).filter(function(i){return i!==q.a;});k=w[Math.floor(Math.random()*w.length)];}
    cur={ok:isT};var c=body.querySelector(".tf-card");c.classList.remove("in","good","bad");void c.offsetWidth;c.classList.add("in");
    body.querySelector(".tf-q").innerHTML=qtx(q.q);body.querySelector(".tf-a").innerHTML=q.qa?'<span class="q">﴿ '+esc(q.c[k])+' ﴾</span>':qtx(q.c[k]);}
  function pick(v){if(lock2||tleft<=0)return;lock2=true;answered++;var c=body.querySelector(".tf-card"),ok=v===cur.ok;
    if(ok){right++;combo++;best=Math.max(best,combo);var mult=combo>=8?4:combo>=5?3:combo>=3?2:1;score+=10*mult;GS.ding(combo);c.classList.add("good");
      var cb=body.querySelector(".tf-combo");cb.textContent=mult>1?"مضاعفة ×"+an(mult)+" 🔥":"";cb.classList.remove("on");void cb.offsetWidth;if(mult>1)cb.classList.add("on");}
    else{combo=0;GS.buzz();c.classList.add("bad");body.querySelector(".tf-combo").textContent="";if(navigator.vibrate)try{navigator.vibrate(120);}catch(e){}}
    stat();setTimeout(deal,ok?380:750);}
  function kd(e){if(!document.getElementById("tfg"))return document.removeEventListener("keydown",kd);if(!body.querySelector(".tf-b"))return;
    if(e.key==="ArrowRight")pick(true);else if(e.key==="ArrowLeft")pick(false);}
  document.addEventListener("keydown",kd);
  function over(){var b=gxBest("tf:best:"+dur,score),acc=answered?Math.round(right/answered*100):0;if(b.rec&&score>0){GS.win();gxConfetti(G.el);}else GS.lose();
    body.innerHTML='<div class="gx-card"><div class="gx-emoji">'+(b.rec&&score>0?'🏆':'⚡')+'</div><h3>انتهى الوقت!</h3><p class="gx-big">'+an(score)+' نقطة</p>'+
      '<p>إجابات صحيحة: '+an(right)+' من '+an(answered)+' (دقة '+an(acc)+'٪) • أطول سلسلة: '+an(best)+'</p><p>'+(b.rec&&score>0?'رقم قياسي جديد!':'أفضل نتيجة: '+an(b.best))+'</p>'+
      '<button class="gx-go" data-go>سباق جديد</button><button class="gx-go alt" data-x>رجوع</button></div>';
    body.querySelector("[data-go]").onclick=countdown;body.querySelector("[data-x]").onclick=G.close;}
  intro();
}

/* ================= ٣) عجلة الأسئلة (فريقان) ================= */
function openWHL(pool,title){
  if(!pool||pool.length<3)return alert("لا توجد أسئلة كافية لهذه اللعبة بعد.");
  var G=gxShell("whl","عجلة الأسئلة","gx-whl"),body=G.body,names=["الفريق الأول","الفريق الثاني"],rounds=8,sc,turn,left,qs,qi,rot=0,spinning=false,raf=null,timer=null;
  var SEG=[{v:10,c:"#ff5d7a"},{v:50,c:"#ffc233"},{v:20,c:"#3fa9ff"},{v:100,c:"#b07cff"},{v:30,c:"#45d483"},{v:"×٢",x:2,c:"#ff8a3d"},{v:40,c:"#22c1c3"},{v:"🎁",g:25,c:"#f472b6"}];
  G.onclose=function(){cancelAnimationFrame(raf);clearInterval(timer);};
  function intro(){G.stat.innerHTML="";body.innerHTML='<div class="gx-card"><div class="gx-emoji">🎡</div><h3>عجلة الأسئلة</h3><p>'+esc(title||"")+'</p>'+
    '<p>يدير كل فريق العجلة ليعرف قيمة سؤاله، ثم يجيب. الإجابة الصحيحة تضيف النقاط. خانة (×٢) تضاعف رصيد الفريق إذا أجاب صحيحًا، وخانة 🎁 هدية ٢٥ نقطة مباشرة!</p>'+
    '<div class="gx-names"><label>الفريق الأول<input maxlength="18" value="'+esc(names[0])+'" data-n="0"></label><label>الفريق الثاني<input maxlength="18" value="'+esc(names[1])+'" data-n="1"></label></div>'+
    '<p><b>عدد الأسئلة</b></p><div class="gx-opts">'+[6,8,12].map(function(n){return '<button data-r="'+n+'" class="'+(n===rounds?'on':'')+'">'+an(n)+'</button>';}).join("")+'</div>'+
    '<button class="gx-go" data-go>ابدأ</button></div>';
    body.querySelectorAll("[data-r]").forEach(function(b){b.onclick=function(){rounds=+b.getAttribute("data-r");body.querySelectorAll("[data-r]").forEach(function(x){x.classList.toggle("on",x===b);});};});
    body.querySelector("[data-go]").onclick=function(){body.querySelectorAll("[data-n]").forEach(function(i){var v=i.value.trim();if(v)names[+i.getAttribute("data-n")]=v;});start();};}
  function wheelSvg(){var n=SEG.length,a=360/n,h='';SEG.forEach(function(s,i){var a0=(i*a-90-a/2)*Math.PI/180,a1=((i+1)*a-90-a/2)*Math.PI/180;
      h+='<path d="M0 0 L'+(Math.cos(a0)*100).toFixed(2)+' '+(Math.sin(a0)*100).toFixed(2)+' A100 100 0 0 1 '+(Math.cos(a1)*100).toFixed(2)+' '+(Math.sin(a1)*100).toFixed(2)+' Z" fill="'+s.c+'" stroke="#fff" stroke-width="1.5"/>'+
      '<text transform="rotate('+(i*a)+') translate(0 -66)" text-anchor="middle" dominant-baseline="middle" font-size="'+(typeof s.v==="number"?15:16)+'" font-weight="800" fill="#fff" font-family="Tajawal,sans-serif">'+(typeof s.v==="number"?an(s.v):s.v)+'</text>';});
    return '<svg viewBox="-110 -110 220 220" class="wh-svg"><circle r="108" fill="#1b2350"/>'+[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15].map(function(i){var t=i*22.5*Math.PI/180;return '<circle cx="'+(Math.cos(t)*104).toFixed(1)+'" cy="'+(Math.sin(t)*104).toFixed(1)+'" r="2.6" fill="#ffd76a"/>';}).join("")+
      '<g class="wh-rot">'+h+'</g><circle r="16" fill="#fff" stroke="#1b2350" stroke-width="4"/><circle r="6" fill="#ffd76a"/></svg>';}
  function start(){sc=[0,0];turn=0;left=rounds;qs=shuffle(pool);qi=0;rot=0;
    body.innerHTML='<div class="wh-score"><div class="wh-t t0"><b></b><span></span></div><div class="wh-left"></div><div class="wh-t t1"><b></b><span></span></div></div>'+
      '<div class="wh-main"><div class="wh-wheel"><div class="wh-ptr"></div>'+wheelSvg()+'<button class="wh-spin" data-spin>أدِر العجلة</button></div><div class="wh-play"></div></div>';
    body.querySelector(".wh-t.t0 b").textContent=names[0];body.querySelector(".wh-t.t1 b").textContent=names[1];board();ready();}
  function board(){body.querySelector(".wh-t.t0 span").textContent=an(sc[0]);body.querySelector(".wh-t.t1 span").textContent=an(sc[1]);
    body.querySelector(".wh-t.t0").classList.toggle("now",turn===0);body.querySelector(".wh-t.t1").classList.toggle("now",turn===1);
    body.querySelector(".wh-left").textContent="باقي "+an(left);}
  function ready(){var b=body.querySelector("[data-spin]");b.disabled=false;b.textContent="أدِر العجلة";
    body.querySelector(".wh-play").innerHTML='<div class="wh-turn t'+turn+'">دور: '+esc(names[turn])+'</div><p class="wh-hint">اضغط «أدِر العجلة» لتعرف قيمة السؤال 🎡</p>';
    b.onclick=spin;}
  function spin(){if(spinning)return;spinning=true;var b=body.querySelector("[data-spin]");b.disabled=true;b.textContent="…";GS.whoosh();
    var n=SEG.length,a=360/n,target=Math.floor(Math.random()*n),extra=360*(4+Math.floor(Math.random()*3));
    var cur=((rot%360)+360)%360,want=(360-target*a)%360,delta=extra+((want-cur+360)%360)+(Math.random()*a*.6-a*.3);
    var from=rot,to=rot+delta,t0=performance.now(),D=4200,lastSeg=null,g=body.querySelector(".wh-rot");
    function ease(t){return 1-Math.pow(1-t,3.2);}
    function frame(now){var t=Math.min(1,(now-t0)/D),r=from+(to-from)*ease(t);g.setAttribute("transform","rotate("+r+")");
      var seg=Math.floor((((-r%360)+360+a/2)%360)/a);if(seg!==lastSeg){if(lastSeg!==null)GS.click();lastSeg=seg;var p=body.querySelector(".wh-ptr");p.classList.remove("hit");void p.offsetWidth;p.classList.add("hit");}
      if(t<1)raf=requestAnimationFrame(frame);else{rot=to;spinning=false;landed(SEG[Math.floor((((-to%360)+360+a/2)%360)/a)]);}}
    raf=requestAnimationFrame(frame);}
  function landed(s){var play=body.querySelector(".wh-play");
    if(s.g){sc[turn]+=s.g;GS.win();play.innerHTML='<div class="wh-turn t'+turn+'">🎁 هدية!</div><p class="wh-big">+'+an(s.g)+' نقطة لـ '+esc(names[turn])+'</p>';board();
      return setTimeout(function(){turn=1-turn;board();ready();},1800);}
    tone([[523,0,.12],[784,.1,.2]]);var Q=gxMk(qs[qi++%qs.length]),L="أبجد",val=s.x?"مضاعفة الرصيد":an(s.v)+" نقطة";
    play.innerHTML='<div class="wh-turn t'+turn+'">'+esc(names[turn])+' • السؤال بقيمة: '+val+' <span class="wh-tm">٢٠</span></div><div class="wh-q">'+qtx(Q.q)+'</div><div class="wh-ans">'+
      Q.o.map(function(o,k){return '<button class="wh-a'+(Q.qa?' qa':'')+'" data-k="'+k+'"><b>'+L[k]+'</b><span>'+gxTxt(o,Q.qa)+'</span></button>';}).join("")+'</div><div class="wh-msg"></div>';
    var busy=false,tl=20,tm=play.querySelector(".wh-tm");clearInterval(timer);
    function done(k){if(busy)return;busy=true;clearInterval(timer);var bs=play.querySelectorAll(".wh-a"),ok=k>-1&&Q.o[k].ok;Q.o.forEach(function(o,j){if(o.ok)bs[j].classList.add("ok");});
      if(k>-1&&!ok)bs[k].classList.add("no");var m=play.querySelector(".wh-msg");
      if(ok){var gain=s.x?Math.max(sc[turn],10):s.v;sc[turn]+=gain;GS.win();m.textContent="صحيح! +"+an(gain)+" نقطة";}else{GS.buzz();m.textContent=k<0?"انتهى الوقت!":"إجابة خاطئة!";}
      board();left--;setTimeout(function(){if(left<=0)return end();turn=1-turn;board();ready();},2000);}
    play.querySelectorAll(".wh-a").forEach(function(b){b.onclick=function(){done(+b.getAttribute("data-k"));};});
    timer=setInterval(function(){tl--;tm.textContent=an(Math.max(tl,0));tm.classList.toggle("low",tl<=5);if(tl<=5&&tl>0)GS.click();if(tl<=0)done(-1);},1000);}
  function end(){var w=sc[0]===sc[1]?-1:sc[0]>sc[1]?0:1;GS.win();gxConfetti(G.el);
    body.querySelector(".wh-play").innerHTML='<div class="gx-card"><div class="gx-emoji">🏆</div><h3>'+(w<0?'تعادل!':'فاز '+esc(names[w])+'!')+'</h3><p class="gx-big">'+an(sc[0])+' — '+an(sc[1])+'</p>'+
      '<button class="gx-go" data-go>جولة جديدة</button><button class="gx-go alt" data-s>تغيير الفريقين</button></div>';
    body.querySelector("[data-spin]").disabled=true;
    body.querySelector("[data-go]").onclick=start;body.querySelector("[data-s]").onclick=intro;}
  intro();
}

/* ================= الاختبار المباشر للصف (مثل كاهوت) ================= */
/* ---- طبقة الاتصال: Firebase Realtime Database عبر REST + البث الحي (SSE)،
        أو "local" للتجربة على جهاز واحد في نافذتين ---- */
function lvDB(){var u=String(window.LIVE_DB||"").trim().replace(/\/+$/,"");if(!u&&location.protocol.indexOf("http")===0)u="server";return u;}
function getAt(o,seg){for(var i=0;i<seg.length;i++){if(o==null||typeof o!=="object")return null;o=o[seg[i]];}return o===undefined?null:o;}
function setAt(root,seg,v){if(!seg.length)return v;root=(root&&typeof root==="object")?root:{};var o=root;
  for(var i=0;i<seg.length-1;i++){if(!o[seg[i]]||typeof o[seg[i]]!=="object")o[seg[i]]={};o=o[seg[i]];}
  if(v===null)delete o[seg[seg.length-1]];else o[seg[seg.length-1]]=v;return root;}
function segs(p){return String(p).split("/").filter(Boolean);}
var LocalT={
  load:function(){try{return JSON.parse(localStorage.getItem("livedb")||"{}");}catch(e){return {};}},
  save:function(t){try{localStorage.setItem("livedb",JSON.stringify(t));}catch(e){}LocalT.fire();},
  set:function(p,v){var t=LocalT.load();t=setAt(t,segs(p),JSON.parse(JSON.stringify(v)))||{};LocalT.save(t);return Promise.resolve();},
  update:function(p,o){var t=LocalT.load();Object.keys(o).forEach(function(k){t=setAt(t,segs(p+"/"+k),o[k]===undefined?null:JSON.parse(JSON.stringify(o[k])))||{};});LocalT.save(t);return Promise.resolve();},
  remove:function(p){return LocalT.set(p,null);},
  subs:[],fire:function(){LocalT.subs.forEach(function(s){s();});},
  on:function(p,cb){var last;function chk(){var v=getAt(LocalT.load(),segs(p)),j=JSON.stringify(v);if(j!==last){last=j;cb(v);}}
    function st(e){if(e.key==="livedb")chk();}window.addEventListener("storage",st);LocalT.subs.push(chk);var iv=setInterval(chk,700);setTimeout(chk,0);
    return function(){window.removeEventListener("storage",st);LocalT.subs=LocalT.subs.filter(function(x){return x!==chk;});clearInterval(iv);};}
};
var FireT={
  url:function(p){return lvDB()+"/"+segs(p).join("/")+".json";},
  req:function(m,p,v){return fetch(FireT.url(p),{method:m,body:v===undefined?undefined:JSON.stringify(v)}).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r;});},
  set:function(p,v){return FireT.req("PUT",p,v);},update:function(p,o){return FireT.req("PATCH",p,o);},remove:function(p){return FireT.req("DELETE",p);},
  on:function(p,cb){var cache=null,es=null,closed=false,retry=null;
    function open(){es=new EventSource(FireT.url(p));
      function h(patch){return function(e){var m;try{m=JSON.parse(e.data);}catch(_){return;}if(!m)return;var s=segs(m.path);
        if(patch){Object.keys(m.data||{}).forEach(function(k){cache=setAt(cache,s.concat(segs(k)),m.data[k]);});}else cache=setAt(cache,s,m.data);cb(cache);};}
      es.addEventListener("put",h(false));es.addEventListener("patch",h(true));
      es.onerror=function(){if(closed)return;es.close();retry=setTimeout(open,2000);};}
    open();return function(){closed=true;clearTimeout(retry);if(es)es.close();};}
};
var ServerT={
  post:function(op,p,v){return (window.STP&&STP.ready?STP.ready:Promise.resolve()).then(function(){return STP.post("live_op",{op:op,path:segs(p).join("/"),v:v===undefined?null:v});});},
  set:function(p,v){return ServerT.post("set",p,v);},update:function(p,o){return ServerT.post("update",p,o);},remove:function(p){return ServerT.post("remove",p);},
  on:function(p,cb){var last,stop=false,tm=null,P=segs(p).join("/");
    function tick(){if(stop)return;fetch("portal/api/index.php?a=live_get&p="+encodeURIComponent(P)+"&_="+Date.now(),{credentials:"same-origin",cache:"no-store"}).then(function(r){return r.json();})
      .then(function(j){if(stop)return;var v=j&&j.v!==undefined?j.v:null,s=JSON.stringify(v);if(s!==last){last=s;cb(v);}}).catch(function(){})
      .then(function(){if(!stop)tm=setTimeout(tick,document.hidden?3000:900);});}
    tick();return function(){stop=true;clearTimeout(tm);};}
};
function T(){var d=lvDB();return d==="local"?LocalT:d==="server"?ServerT:FireT;}
function lvReady(){var u=lvDB();return u==="local"||u==="server"||/^https:\/\/[\w.-]+\.(firebaseio\.com|firebasedatabase\.app)$/.test(u);}

var SHP=[{c:"#e21b3c",s:"▲"},{c:"#1368ce",s:"◆"},{c:"#d89e00",s:"●"},{c:"#26890c",s:"■"}];
var LS={join:function(){tone([[660,0,.08,"triangle"],[990,.07,.12,"triangle"]]);},tick:function(){tone([[900,0,.04,"square"]]);},
  gong:function(){tone([[196,0,.9,"triangle"],[294,0,.9,"sine"],[392,.02,.9,"sine"]]);},
  ok:function(){tone([[523,0,.12],[659,.1,.12],[784,.2,.25]]);},no:function(){tone([[200,0,.35,"sawtooth"]]);},
  lb:function(){tone([[392,0,.12],[523,.12,.12],[659,.24,.2]]);},
  end:function(){tone([[523,0,.18],[659,.16,.18],[784,.32,.18],[1047,.48,.5],[784,.85,.15],[1047,1,.7]]);noise(2,800,3000,.2,.3);}};
function code6(){return String(Math.floor(100000+Math.random()*900000));}
function joinUrl(code){return location.href.split("#")[0]+"#live="+code;}

/* LV2-BEGIN */
/* ---------------- الاختبار المباشر: دخول حر حتى ٥٠ طالبًا + إدارة الطلاب + دردشة مفلترة ---------------- */
function lv2css(){if(document.getElementById("lv2-css"))return;var st=document.createElement("style");st.id="lv2-css";st.textContent=[
"#lvs .gx-body,#lvh .gx-body{position:relative;overflow:hidden;padding:0}",
"body:has(#lvs) #stclk,body:has(#lvh) #stclk,body:has(#lvs) #wbfab,body:has(#lvh) #wbfab,body:has(#lvs) #crs-close,body:has(#lvh) #crs-close,body:has(.qg) #stclk,body:has(.qg) #wbfab,body:has(.qg) #crs-close{display:none!important}",
".lv2{position:absolute;inset:8px;display:flex;gap:10px;min-height:0}",
".lv2-main{flex:1;min-width:0;position:relative;overflow:auto;display:flex;flex-direction:column;border-radius:18px}",
".lv2-main>.gx-card{margin:auto}",
".lv2-chat{width:300px;flex:none;display:flex;flex-direction:column;background:rgba(15,10,40,.55);border:1px solid rgba(255,255,255,.14);border-radius:18px;overflow:hidden;color:#fff}",
".lv2-ch-h{display:flex;align-items:center;gap:6px;padding:10px 12px;font-weight:800;background:rgba(255,255,255,.08)}.lv2-ch-h b{flex:1}",
".lv2-ch-h select{font:inherit;font-size:12px;border-radius:8px;border:0;padding:3px 4px;max-width:150px}",
".lv2-chx{display:none;border:0;background:rgba(255,255,255,.15);color:#fff;border-radius:8px;width:30px;height:30px;font-size:15px;cursor:pointer}",
".lv2-msgs{flex:1;overflow:auto;padding:8px 10px;display:flex;flex-direction:column;gap:6px}",
".lv2-m{background:rgba(255,255,255,.1);border-radius:12px;padding:6px 10px;font-size:14px;line-height:1.55;word-break:break-word;position:relative;animation:tfIn .3s}",
".lv2-m b{color:#fde68a;font-size:12.5px;display:block}.lv2-m.h{background:rgba(250,204,21,.22);border:1px solid rgba(250,204,21,.5)}.lv2-m.h b{color:#fde047}.lv2-m.me{background:rgba(56,189,248,.22)}",
".lv2-m .del{position:absolute;top:4px;left:6px;border:0;background:rgba(239,68,68,.85);color:#fff;border-radius:6px;font-size:11px;padding:1px 6px;cursor:pointer}",
".lv2-pre{display:flex;flex-wrap:wrap;gap:5px;padding:6px 8px;border-top:1px solid rgba(255,255,255,.1)}",
".lv2-pre button{border:0;background:rgba(255,255,255,.14);color:#fff;border-radius:99px;padding:4px 9px;font:inherit;font-size:12.5px;cursor:pointer}.lv2-pre button:hover{background:rgba(255,255,255,.25)}",
".lv2-in{display:flex;gap:6px;padding:8px}.lv2-in input{flex:1;min-width:0;border:0;border-radius:10px;padding:9px 10px;font:inherit;font-size:14px}",
".lv2-in button{border:0;border-radius:10px;padding:0 12px;font:inherit;font-weight:800;background:#facc15;color:#111;cursor:pointer}",
".lv2-err{min-height:0;margin:0 10px 8px;font-size:12.5px;font-weight:700;color:#fca5a5}.lv2-err:empty{display:none}",
".lv2-off{padding:10px;text-align:center;color:#cbd5e1;font-weight:700;font-size:13px}",
".lv2-fab{display:none;position:absolute;left:10px;bottom:10px;z-index:30;width:54px;height:54px;border-radius:50%;border:0;background:#facc15;font-size:24px;box-shadow:0 8px 20px rgba(0,0,0,.35);cursor:pointer}",
".lv2-fab i{position:absolute;top:-2px;right:-2px;min-width:20px;height:20px;border-radius:99px;background:#ef4444;color:#fff;font-size:12px;font-style:normal;font-weight:800;display:none;align-items:center;justify-content:center;padding:0 4px}.lv2-fab i.on{display:flex}",
"@media(max-width:780px){.lv2-chat{position:absolute;left:0;right:0;bottom:0;width:auto;height:62%;z-index:40;transform:translateY(110%);transition:transform .25s;background:#1e1b4b}.lv2.co .lv2-chat{transform:none}.lv2-fab{display:block}.lv2-chx{display:block}}",
".lv2-ov{position:absolute;inset:0;z-index:25;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;background:rgba(15,23,42,.88);color:#fff;font-weight:800;font-size:22px;text-align:center;padding:20px;border-radius:18px}",
".lv2-dlg{position:absolute;inset:0;z-index:60;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55);padding:14px}",
".lv2-box{background:#fff;color:#1e1b4b;border-radius:20px;padding:18px;width:min(460px,100%);max-height:90%;overflow:auto;text-align:center;box-shadow:0 20px 50px rgba(0,0,0,.4)}",
".lv2-box h3{margin:0 0 8px}.lv2-box input,.lv2-box textarea{width:100%;box-sizing:border-box;border:2px solid #c7d2fe;border-radius:12px;padding:9px;font:inherit;margin:6px 0}",
".lv2-box .row{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-top:8px}",
".lv2-box button{border:0;border-radius:12px;padding:9px 14px;font:inherit;font-weight:800;cursor:pointer;background:#eef2ff;color:#3730a3}.lv2-box button.p{background:#4338ca;color:#fff}.lv2-box button.r{background:#fee2e2;color:#b91c1c}",
".lv2-warn{border:3px solid #f59e0b}.lv2-warn .big{font-size:52px}",
".lv2-pl{display:flex;flex-direction:column;gap:6px;text-align:right}.lv2-pr{display:flex;align-items:center;gap:6px;background:#f8fafc;border-radius:12px;padding:6px 8px}.lv2-pr b{flex:1;font-size:15px}.lv2-pr small{color:#64748b}",
".lv2-pr button{padding:6px 8px;font-size:13px}",
".lv2-codeb{width:auto!important;padding:0 12px!important;margin-inline-end:6px;background:#facc15!important;color:#111!important;font:inherit!important;font-weight:900!important;font-size:19px!important;letter-spacing:2px;direction:ltr;border-radius:12px!important;animation:lvPulse 2.4s infinite}",
"@keyframes lvPulse{0%,100%{box-shadow:0 0 0 0 rgba(250,204,21,.6)}50%{box-shadow:0 0 0 6px rgba(250,204,21,0)}}",
".lv2-big{position:absolute;inset:0;z-index:80;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:linear-gradient(135deg,#1e1b4b,#4c1d95);color:#fff;text-align:center;padding:16px;cursor:zoom-out}",
".lv2-big .bc{font-size:clamp(64px,17vw,240px);font-weight:900;letter-spacing:.08em;direction:ltr;line-height:1;color:#fde047;text-shadow:0 6px 30px rgba(0,0,0,.4)}",
".lv2-big img{width:min(42vh,70vw);height:auto;background:#fff;border-radius:18px;padding:8px}",
".lv2-big .bu{font-size:clamp(14px,2.2vw,22px);opacity:.9;direction:ltr;word-break:break-all}.lv2-big .bh{font-size:clamp(18px,3vw,32px);font-weight:800}",
".lv2-big .bx{position:absolute;top:12px;left:12px;border:0;border-radius:12px;padding:10px 16px;font:inherit;font-weight:800;background:rgba(255,255,255,.18);color:#fff;cursor:pointer}",
".lv2-toast{position:absolute;left:50%;bottom:18px;transform:translateX(-50%);z-index:90;background:rgba(15,23,42,.92);color:#fff;font-weight:800;padding:10px 16px;border-radius:14px;font-size:14px;max-width:90%;text-align:center;animation:tfIn .25s}",
".lv-chip{cursor:pointer}.lv-chip.p{opacity:.55;text-decoration:line-through}.lv-chip .g{font-size:11px;color:#7c3aed;margin-inline-start:4px}"
].join("\n");document.head.appendChild(st);}
function lv2layout(body,host){lv2css();
  body.innerHTML='<div class="lv2"><div class="lv2-main"></div><aside class="lv2-chat"><div class="lv2-ch-h"><b>💬 الدردشة</b>'+(host?'<select data-cm title="الدردشة"><option value="free">مفتوحة (مفلترة)</option><option value="preset">الرسائل الجاهزة فقط</option><option value="off">مغلقة</option></select>':'')+'<button class="lv2-chx" aria-label="إغلاق">✕</button></div>'+
    '<div class="lv2-msgs" aria-live="polite"></div><div class="lv2-pre"></div><form class="lv2-in" autocomplete="off"><input maxlength="100" placeholder="'+(host?'رسالة من المعلم للجميع…':'اكتب رسالة مناسبة…')+'"><button>إرسال</button></form><p class="lv2-err"></p></aside><button class="lv2-fab" aria-label="الدردشة">💬<i></i></button></div>';
  var L=body.querySelector(".lv2"),fab=L.querySelector(".lv2-fab"),unread=0,badge=fab.querySelector("i");
  fab.onclick=function(){L.classList.add("co");unread=0;badge.classList.remove("on");};L.querySelector(".lv2-chx").onclick=function(){L.classList.remove("co");};
  return {L:L,main:L.querySelector(".lv2-main"),msgs:L.querySelector(".lv2-msgs"),pre:L.querySelector(".lv2-pre"),form:L.querySelector(".lv2-in"),err:L.querySelector(".lv2-err"),cm:L.querySelector("[data-cm]"),
    bump:function(n){if(L.classList.contains("co")||getComputedStyle(fab).display==="none")return;unread+=n;badge.textContent=an(unread);badge.classList.toggle("on",unread>0);}};}
var LV2PRE=["👍 فهمت","👏 أحسنتم","🔥 رائع!","😀 ممتع","🤔 سؤال صعب","⏳ نحتاج وقتًا أكثر","🙋 عندي سؤال","🎉 هيا بنا!","💪 سأحاول مرة أخرى","❤️ شكرًا أستاذ"];
function lv2chat(U,base,me,isHost,onDel){var lastId=0,mode="free",sending=false;
  function send(t,p){if(sending)return;sending=true;U.err.textContent="";
    STP.post("live_op",{op:"chat",path:base,v:{t:t,p:p?1:0}}).then(function(){U.form.querySelector("input").value="";}).catch(function(e){U.err.textContent=e.message;}).then(function(){sending=false;});}
  U.pre.innerHTML=LV2PRE.map(function(t){return '<button type="button">'+esc(t)+'</button>';}).join("");
  U.pre.querySelectorAll("button").forEach(function(b){b.onclick=function(){send(b.textContent,true);};});
  U.form.onsubmit=function(e){e.preventDefault();var t=U.form.querySelector("input").value.trim();if(t)send(t,false);};
  return {render:function(list,cm){mode=cm||"free";list=list||[];
      U.form.style.display=(isHost||mode==="free")?"":"none";U.pre.style.display=(!isHost&&(mode==="free"||mode==="preset"))?"":"none";
      var off=!isHost&&mode==="off",mut=!isHost&&mode==="muted";
      var html=off?'<div class="lv2-off">🔒 أغلق المعلم الدردشة الآن</div>':list.map(function(m){return '<div class="lv2-m'+(m.h?' h':'')+(m.i===me?' me':'')+'"><b>'+esc(m.n||"")+'</b>'+esc(m.t||"")+(isHost?'<button class="del" data-del="'+m.id+'">حذف</button>':'')+'</div>';}).join("")+(list.length||off?'':'<div class="lv2-off">لا توجد رسائل بعد</div>')+(mut?'<div class="lv2-off">🔇 أوقف المعلم رسائلك</div>':'');
      var newest=list.length?list[list.length-1].id:0,nw=newest>lastId?list.filter(function(m){return m.id>lastId;}).length:0;
      var atEnd=U.msgs.scrollHeight-U.msgs.scrollTop-U.msgs.clientHeight<40;U.msgs.innerHTML=html;if(atEnd||nw)U.msgs.scrollTop=U.msgs.scrollHeight;
      if(nw&&lastId){U.bump(nw);tone([[880,0,.06,"triangle"]]);}lastId=Math.max(lastId,newest);
      if(isHost)U.msgs.querySelectorAll("[data-del]").forEach(function(b){b.onclick=function(){onDel(+b.getAttribute("data-del"));};});}};}
function lv2dlg(root,html,cls){var d=document.createElement("div");d.className="lv2-dlg";d.innerHTML='<div class="lv2-box '+(cls||"")+'">'+html+'</div>';root.appendChild(d);
  d.addEventListener("click",function(e){if(e.target===d)d.remove();});return d;}

/* ---------------- شاشة المعلم ---------------- */
function lvHost(pool,lessonName){
  if(!lvReady())return alert("الاختبار المباشر يحتاج إلى ربط قاعدة البيانات أولًا (LIVE_DB). راجع التعليمات.");
  if(!pool||!pool.length)return alert("لا توجد أسئلة لهذا الدرس بعد.");
  var G=gxShell("lvh","الاختبار المباشر","gx-live"),db=T(),code=code6(),base="live/"+code,SRV=lvDB()==="server";
  var nQ=Math.min(10,pool.length),dur=20,qs=[],qi=-1,players={},answers={},scores={},mods={},offA=null,offP=null,offC=null,timer=null,tl=0,phase="setup",chatList=[];
  var QG=window.QGAME,gm=QG?QG.pick(pool):"mlg",qst=[],reported=false;if(QG)QG.css();
  var U=lv2layout(G.body,true),body=U.main;if(!SRV)U.L.querySelector(".lv2-chat").style.display="none";U.L.querySelector(".lv2-chat").style.visibility="hidden";
  G.onclose=function(){clearInterval(timer);if(offA)offA();if(offP)offP();if(offC)offC();if(phase!=="setup")db.remove(base);};
  var CH=lv2chat(U,base,"",true,function(id){chatList=chatList.filter(function(m){return m.id!==id;});CH.render(chatList,"free");db.set(base+"/chat",chatList);});
  if(U.cm)U.cm.onchange=function(){db.set(base+"/meta/chat",U.cm.value);};
  function active(){return Object.keys(players).filter(function(id){return !(mods[id]&&mods[id].p);});}
  function bigCode(){var o=G.el.querySelector(".lv2-big");if(o){o.remove();return;}var url=joinUrl(code);o=document.createElement("div");o.className="lv2-big";
    o.innerHTML='<button class="bx">✕ تصغير</button><div class="bh">انضم الآن إلى الاختبار</div><img alt="باركود الدخول" src="https://api.qrserver.com/v1/create-qr-code/?size=480x480&margin=8&data='+encodeURIComponent(url)+'"><div class="bc">'+code.replace(/(\d{3})(\d{3})/,"$1 $2")+'</div><div class="bu">'+esc(url)+'</div>';
    var im=o.querySelector("img");im.onerror=function(){im.remove();};o.onclick=function(){o.remove();};G.el.appendChild(o);}
  function stat(){G.stat.innerHTML=phase==="setup"?'':'<button class="gx-ib lv2-codeb" data-code title="اضغط لتكبير الرمز والباركود">🔑 '+code.replace(/(\d{3})(\d{3})/,"$1 $2")+' <span style="font-size:15px;opacity:.65">⤢</span></button><button class="gx-ib" data-pls style="width:auto;padding:0 12px;font:inherit;font-weight:800;color:#fff">👥 '+an(Object.keys(players).length)+'/٥٠</button>';
    var b=G.stat.querySelector("[data-pls]");if(b)b.onclick=plList;var cb=G.stat.querySelector("[data-code]");if(cb)cb.onclick=bigCode;}
  function nm(id){return (players[id]&&players[id].n)||"طالب";}
  /* إدارة طالب: تعديل الاسم، إيقاف مؤقت، كتم الدردشة، تحذير، حذف */
  function plMenu(id){if(!players[id])return;var m=mods[id]||{},d=lv2dlg(G.el,'<h3>👤 '+esc(nm(id))+'</h3><p style="margin:0;color:#64748b;font-size:13px">'+(players[id].role==="guest"?"دخل بدون حساب":(players[id].cls?esc(players[id].cls):"بحسابه"))+'</p>'+
      '<div class="row"><button data-a="ren">✏️ تعديل الاسم</button><button data-a="pause">'+(m.p?'▶️ استئناف':'⏸ إيقاف مؤقت')+'</button><button data-a="mute">'+(m.m?'💬 السماح بالرسائل':'🔇 منع الرسائل')+'</button>'+
      '<button data-a="warn">⚠️ رسالة تحذير</button><button class="r" data-a="kick">❌ حذف من الاختبار</button></div><div class="row"><button data-a="x">إغلاق</button></div>');
    d.querySelectorAll("[data-a]").forEach(function(b){b.onclick=function(){var a=b.getAttribute("data-a");d.remove();
      if(a==="ren"){var e=lv2dlg(G.el,'<h3>✏️ تعديل الاسم</h3><input maxlength="20" value="'+esc(nm(id))+'"><div class="row"><button class="p" data-s>حفظ</button><button data-x>إلغاء</button></div>');var i=e.querySelector("input");i.focus();i.select();
        e.querySelector("[data-x]").onclick=function(){e.remove();};e.querySelector("[data-s]").onclick=function(){var v=i.value.trim().replace(/[<>]/g,"");if(v.length<2)return;e.remove();players[id].n=v;db.set(base+"/pl/"+id+"/n",v);drawPl();};}
      else if(a==="pause"){m.p=m.p?0:1;mods[id]=m;db.set(base+"/mod/"+id+"/p",m.p?1:null);drawPl();counts();}
      else if(a==="mute"){m.m=m.m?0:1;mods[id]=m;db.set(base+"/mod/"+id+"/m",m.m?1:null);}
      else if(a==="warn"){var W=["⚠️ التزم بآداب المشاركة","⚠️ ركّز في الأسئلة من فضلك","⚠️ الرسائل للمشاركة المفيدة فقط","⚠️ هذا تحذير أخير"],
        e2=lv2dlg(G.el,'<h3>⚠️ رسالة تحذير إلى '+esc(nm(id))+'</h3><div class="row">'+W.map(function(w){return '<button data-w>'+esc(w)+'</button>';}).join("")+'</div><textarea rows="2" maxlength="120" placeholder="أو اكتب التحذير…"></textarea><div class="row"><button class="p" data-s>إرسال</button><button data-x>إلغاء</button></div>');
        function sendW(t){e2.remove();m.w=t;mods[id]=m;db.update(base+"/mod/"+id,{w:t,wt:Date.now()});}
        e2.querySelectorAll("[data-w]").forEach(function(x){x.onclick=function(){sendW(x.textContent);};});e2.querySelector("[data-x]").onclick=function(){e2.remove();};
        e2.querySelector("[data-s]").onclick=function(){var t=e2.querySelector("textarea").value.trim().replace(/[<>]/g,"");if(t)sendW(t);};}
      else if(a==="kick"){var e3=lv2dlg(G.el,'<h3>❌ حذف '+esc(nm(id))+' من الاختبار؟</h3><p>لن يستطيع العودة إلى هذا الاختبار.</p><div class="row"><button class="r" data-s>نعم، احذفه</button><button data-x>إلغاء</button></div>');
        e3.querySelector("[data-x]").onclick=function(){e3.remove();};e3.querySelector("[data-s]").onclick=function(){e3.remove();mods[id]={k:1};delete players[id];delete scores[id];
          db.update(base+"/mod/"+id,{k:1});db.remove(base+"/pl/"+id);drawPl();stat();counts();};}};});}
  function plList(){var ids=Object.keys(players);var d=lv2dlg(G.el,'<h3>👥 الطلاب المشاركون ('+an(ids.length)+' من ٥٠)</h3><div class="lv2-pl">'+(ids.length?ids.map(function(id){var m=mods[id]||{};
      return '<div class="lv2-pr"><b>'+esc(nm(id))+(m.p?' ⏸':'')+(m.m?' 🔇':'')+'</b><small>'+(scores[id]?an(scores[id].s)+' نقطة':'')+'</small><button data-id="'+esc(id)+'">إدارة</button></div>';}).join(""):'<p>لم ينضم أحد بعد.</p>')+'</div><div class="row"><button data-x>إغلاق</button></div>');
    d.querySelector("[data-x]").onclick=function(){d.remove();};d.querySelectorAll("[data-id]").forEach(function(b){b.onclick=function(){d.remove();plMenu(b.getAttribute("data-id"));};});}
  function drawPl(){var pl=body.querySelector(".lv-pl");if(!pl)return;pl.innerHTML=Object.keys(players).map(function(id){var m=mods[id]||{};return '<span class="lv-chip'+(m.p?' p':'')+'" data-id="'+esc(id)+'">'+esc(nm(id))+(players[id].role==="guest"?'':'<span class="g">✔</span>')+'</span>';}).join("");
    pl.querySelectorAll("[data-id]").forEach(function(c){c.onclick=function(){plMenu(c.getAttribute("data-id"));};});}
  function setup(){body.innerHTML='<div class="gx-card"><div class="gx-emoji">📡</div><h3>اختبار مباشر للصف</h3><p>'+esc(lessonName||"")+'</p>'+
    '<p>يمسح الطلاب الباركود بجوالاتهم ويكتبون أسماءهم (بحساب أو بدون، حتى ٥٠ طالبًا)، ثم يجيبون معًا. النقاط للأسرع والأدق!</p>'+
    '<p><b>عدد الأسئلة</b></p><div class="gx-opts">'+[5,10,15].filter(function(n){return n<pool.length;}).concat([pool.length]).map(function(n){return '<button data-n="'+n+'" class="'+(n===nQ?'on':'')+'">'+(n===pool.length?'الكل ('+an(n)+')':an(n))+'</button>';}).join("")+'</div>'+
    '<p><b>وقت كل سؤال</b></p><div class="gx-opts">'+[10,20,30,60].map(function(s){return '<button data-d="'+s+'" class="'+(s===dur?'on':'')+'">'+an(s)+' ث</button>';}).join("")+'</div>'+
    (QG?'<p><b>اللعبة</b></p><div class="qg-pk" style="background:#1e1b4b;color:#fff;border-radius:18px;padding:4px 12px 8px;margin:6px 0 12px;text-align:center">'+QG.picker(pool,gm,gm)+'</div>':'')+
    '<button class="gx-go" data-go>إنشاء الغرفة</button></div>';
    body.querySelectorAll("[data-g]").forEach(function(b){b.onclick=function(){gm=b.getAttribute("data-g");body.querySelectorAll("[data-g]").forEach(function(x){x.classList.toggle("on",x===b);});};});
    body.querySelectorAll("[data-n]").forEach(function(b){b.onclick=function(){nQ=+b.getAttribute("data-n");body.querySelectorAll("[data-n]").forEach(function(x){x.classList.toggle("on",x===b);});};});
    body.querySelectorAll("[data-d]").forEach(function(b){b.onclick=function(){dur=+b.getAttribute("data-d");body.querySelectorAll("[data-d]").forEach(function(x){x.classList.toggle("on",x===b);});};});
    body.querySelector("[data-go]").onclick=create;}
  function create(){qs=shuffle(pool).slice(0,nQ).map(function(q){var o=shuffle(q.c.map(function(t,k){return {t:t,ok:k===q.a};})).slice(0,4);
      if(!o.some(function(x){return x.ok;}))o[0]={t:q.c[q.a],ok:true};o=shuffle(o);return {q:q.q,qa:!!q.qa,c:o.map(function(x){return x.t;}),a:o.findIndex(function(x){return x.ok;})};});
    phase="lobby";body.innerHTML='<div class="gx-card"><p>جارٍ إنشاء الغرفة…</p></div>';
    db.set(base,{meta:{lesson:lessonName||"",at:Date.now(),chat:"free"},st:{ph:"lobby",n:qs.length,g:(window.EDU_G&&EDU_G())||""}}).then(function(){
      if(SRV){U.L.querySelector(".lv2-chat").style.visibility="";offC=db.on(base+"/chat",function(v){chatList=Array.isArray(v)?v:(v?Object.keys(v).map(function(k){return v[k];}):[]);CH.render(chatList,"free");});}
      lobby();}).catch(function(e){phase="setup";
      body.innerHTML='<div class="gx-card"><h3>تعذّر الاتصال</h3><p>'+esc(e&&e.message||"تحقّق من اتصال الإنترنت ثم حاول مرة أخرى.")+'</p><button class="gx-go" data-x>رجوع</button></div>';
      body.querySelector("[data-x]").onclick=G.close;});}
  function lobby(){var url=joinUrl(code);stat();
    body.innerHTML='<div class="lv-lobby"><div class="lv-join"><div class="lv-qr"><img alt="باركود الدخول" src="https://api.qrserver.com/v1/create-qr-code/?size=360x360&margin=8&data='+encodeURIComponent(url)+'"></div>'+
      '<div class="lv-code"><small>رمز الدخول</small><b>'+code.replace(/(\d{3})(\d{3})/,"$1 $2")+'</b><small class="lv-url">'+esc(url)+'</small></div></div>'+
      '<div class="lv-room"><div class="lv-cnt"><span>👥</span><b>٠</b> طالب انضمّ <small style="opacity:.7">(الحد ٥٠)</small></div><p style="margin:0;font-size:13px;opacity:.85">اضغط اسم أي طالب لتعديله أو إيقافه أو تحذيره أو حذفه.</p><div class="lv-pl"></div><button class="gx-go" data-start disabled>ابدأ الاختبار</button></div></div>';
    var img=body.querySelector(".lv-qr img");img.onerror=function(){img.parentNode.innerHTML='<p class="lv-noqr">افتح الرابط أو أدخل الرمز</p>';};
    body.querySelector("[data-start]").onclick=nextQ;var jc=body.querySelector(".lv-join");if(jc){jc.style.cursor="zoom-in";jc.title="اضغط للتكبير";jc.onclick=bigCode;}
    offP=db.on(base+"/pl",function(v){var before=Object.keys(players).length;players=v||{};var ids=Object.keys(players),n=ids.length;
      if(n>before)LS.join();var c=body.querySelector(".lv-cnt b");if(c)c.textContent=an(n);drawPl();stat();
      var sb=body.querySelector("[data-start]");if(sb)sb.disabled=n<1;
      if(phase==="q")counts();});}
  function nextQ(){qi++;if(qi>=qs.length)return finish();phase="q";answers={};var Q=qs[qi],at=Date.now();
    var GE=QG?QG.eff(gm,{c:Q.c}):"mlg";
    db.update(base+"/st",{ph:"q",qi:qi,n:qs.length,dur:dur,at:at,gm:GE,ok:null,g:(window.EDU_G&&EDU_G())||"",q:{t:Q.q,qa:Q.qa,c:Q.c}});
    body.innerHTML='<div class="lv-qtop">'+(QG?'<span class="lv-num">'+QG.BY[GE].ic+' '+QG.BY[GE].n+'</span>':'')+'<span class="lv-num">السؤال '+an(qi+1)+' من '+an(qs.length)+'</span><span class="lv-tm">'+an(dur)+'</span><span class="lv-ac">أجاب ٠</span></div>'+
      '<div class="lv-q">'+qtx(Q.q)+'</div><div class="lv-ch">'+Q.c.map(function(c,k){return '<div class="lv-o" style="--c:'+SHP[k].c+'"><i>'+SHP[k].s+'</i><span>'+(Q.qa?'﴿ '+esc(c)+' ﴾':qtx(c))+'</span><em></em></div>';}).join("")+'</div>'+
      '<div class="lv-ctl"><button class="gx-go alt" data-skip>إنهاء الوقت الآن</button></div>';
    body.querySelector("[data-skip]").onclick=reveal;LS.gong();
    if(offA)offA();offA=db.on(base+"/an/"+qi,function(v){answers=v||{};counts();});
    tl=dur;clearInterval(timer);timer=setInterval(function(){tl--;var t=body.querySelector(".lv-tm");if(t){t.textContent=an(Math.max(tl,0));t.classList.toggle("low",tl<=5);}
      if(tl<=5&&tl>0)LS.tick();if(tl<=0)reveal();},1000);}
  function counts(){var act=active(),n=act.filter(function(id){return answers[id];}).length,p=act.length,el=body.querySelector(".lv-ac");if(el)el.textContent="أجاب "+an(n)+" من "+an(p);
    if(phase==="q"&&p>0&&n>=p)setTimeout(function(){if(phase==="q")reveal();},600);}
  function reveal(){if(phase!=="q")return;phase="rev";clearInterval(timer);if(offA){offA();offA=null;}var Q=qs[qi],dist=[0,0,0,0],upd={};
    Object.keys(players).forEach(function(id){var s=scores[id]||{s:0,st:0},a=answers[id],ok=!!a&&a.c===Q.a,gain=0;if(a&&a.c>=0&&a.c<4)dist[a.c]++;
      if(ok){s.st=(s.st||0)+1;gain=Math.round(1000*(1-Math.min(1,Math.max(0,(a.t||0)/1000/dur))/2))+Math.min(s.st-1,5)*100;}else s.st=0;
      s.s=(s.s||0)+gain;s.g=gain;s.ok=ok;s.ans=!!a;s.okc=(s.okc||0)+(ok?1:0);scores[id]=s;});
    var ids=Object.keys(players),nok=ids.filter(function(id){return scores[id]&&scores[id].ok;}).length;qst[qi]={q:Q.q,pct:ids.length?nok/ids.length*100:0};
    var rank=Object.keys(scores).filter(function(id){return players[id];}).sort(function(a,b){return scores[b].s-scores[a].s;});rank.forEach(function(id,i){scores[id].r=i+1;upd[id]={qi:qi,s:scores[id].s,g:scores[id].g,ok:scores[id].ok,ans:scores[id].ans,r:i+1,st:scores[id].st,of:rank.length};});
    db.set(base+"/sc",upd);db.update(base+"/st",{ph:"rev",ok:Q.a});LS.gong();
    var tot=Math.max(1,dist.reduce(function(a,b){return a+b;},0));
    body.querySelectorAll(".lv-o").forEach(function(o,k){o.classList.add(k===Q.a?"right":"dim");o.querySelector("em").textContent=an(dist[k]);o.style.setProperty("--w",(dist[k]/tot*100)+"%");});
    body.querySelector(".lv-ctl").innerHTML='<button class="gx-go" data-lb>لوحة الصدارة</button>';body.querySelector("[data-lb]").onclick=board;}
  function board(){phase="lb";LS.lb();db.update(base+"/st",{ph:"lb"});
    var rank=Object.keys(scores).filter(function(id){return players[id];}).sort(function(a,b){return scores[b].s-scores[a].s;}).slice(0,5);
    body.innerHTML='<div class="lv-lb"><h3>لوحة الصدارة</h3>'+rank.map(function(id,i){return '<div class="lv-row" style="--d:'+(i*.12)+'s"><b>'+an(i+1)+'</b><span>'+esc(nm(id))+'</span><em>'+an(scores[id].s)+'</em>'+(scores[id].st>=2?'<i>🔥'+an(scores[id].st)+'</i>':'')+'</div>';}).join("")+
      '</div><div class="lv-ctl"><button class="gx-go" data-nx>'+(qi<qs.length-1?'السؤال التالي':'النتائج النهائية')+'</button></div>';
    body.querySelector("[data-nx]").onclick=nextQ;}
  function finish(){phase="end";LS.end();gxConfetti(G.el);db.update(base+"/st",{ph:"end"});
    var rank=Object.keys(scores).filter(function(id){return players[id];}).sort(function(a,b){return scores[b].s-scores[a].s;}),pod=[1,0,2].filter(function(i){return rank[i];});
    body.innerHTML='<div class="lv-pod">'+pod.map(function(i){var id=rank[i];return '<div class="lv-p p'+(i+1)+'"><div class="lv-medal">'+["🥇","🥈","🥉"][i]+'</div><b>'+esc(nm(id))+'</b><span>'+an(scores[id].s)+'</span><div class="lv-col">'+an(i+1)+'</div></div>';}).join("")+'</div>'+
      '<div class="lv-rest">'+rank.slice(3).map(function(id,i){return '<span>'+an(i+4)+'. '+esc(nm(id))+' — '+an(scores[id].s)+'</span>';}).join("")+'</div>'+
      '<div class="lv-ctl"><p class="lv-rep" style="font-weight:700;margin:6px 0">⏳ جارٍ إرسال التقرير إلى بريدك…</p><button class="gx-go" data-x>إنهاء الجلسة</button></div>';
    body.querySelector("[data-x]").onclick=G.close;
    if(!reported&&window.STP&&STP.me){reported=true;var L=window.__lesson||{},asked=qst.filter(Boolean).length||qs.length;
      STP.post("live_report",{code:code,route:L.route||"",game:QG?QG.BY[gm].n:"اختيار من متعدد",questions:qst.filter(Boolean),players:Object.keys(players).map(function(id){var s=scores[id]||{};return {id:id,ok:s.okc||0,n:asked,pts:s.s||0};})})
        .then(function(j){var e=body.querySelector(".lv-rep");if(e)e.textContent=j.sent?"📧 أُرسل التقرير (PDF) إلى بريدك "+(j.to||""):"✅ حُفظت النتائج. أضف بريدك من «حسابي» ليصلك التقرير.";})
        .catch(function(e){var x=body.querySelector(".lv-rep");if(x)x.textContent="⚠️ "+e.message;});}}
  setup();
}

/* ---------------- شاشة الطالب (بحساب أو بدون) ----------------
   يظهر الاختبار وحده بملء الشاشة: لا تُغلقه إيماءة الرجوع أو السحب، والخروج بزر واضح مع تأكيد،
   ويمكن للمشارك العودة بالرمز نفسه (أو تلقائيًّا بعد إعادة تحميل الصفحة) مع الاحتفاظ بنقاطه. */
var LVK="lv:j";
function lvSaved(){try{var o=JSON.parse(localStorage.getItem(LVK)||"null");if(o&&o.c&&Date.now()-o.t<4*3600e3)return o;}catch(e){}return null;}
function lvSave(o){try{if(o)localStorage.setItem(LVK,JSON.stringify(o));else localStorage.removeItem(LVK);}catch(e){}}
function lvJoin(code){
  if(!lvReady())return alert("الاختبار المباشر غير مفعّل في هذه الصفحة.");
  var H=document.documentElement;H.classList.add("lvk");
  var G=gxShell("lvs","اختبار مباشر","gx-live"),db=T(),SRV=lvDB()==="server",base,me="",myName="",rk="",st,sc,mod,shownAt,answered,lastPh,lastQi,ctl=null,stop=true,poll=null,offs=[],lastWt,first,joinedAt,chatL,cm,over=false;
  function reset(){st=null;sc=null;mod={};shownAt=0;answered=-1;lastPh="";lastQi=-1;lastWt=0;first=true;joinedAt=0;chatL=[];cm="free";over=false;}reset();
  var U=lv2layout(G.body,false),body=U.main;U.L.querySelector(".lv2-chat").style.display="none";
  var CH=lv2chat(U,"","",false);
  var xb=G.el.querySelector('.gx-top [data-a="x"]');if(xb){xb.setAttribute("aria-label","خروج من الاختبار");xb.title="خروج";}
  /* إيماءة الرجوع في الجوال لا تغلق الاختبار */
  function guard(){try{history.pushState({lvg:1},"",location.href);}catch(e){}}
  function onPop(){if(!document.getElementById("lvs"))return;guard();toast("للخروج من الاختبار اضغط زر ✕ في الأعلى");}
  guard();window.addEventListener("popstate",onPop);
  function toast(t){var o=G.el.querySelector(".lv2-toast");if(o)o.remove();o=document.createElement("div");o.className="lv2-toast";o.textContent=t;G.el.appendChild(o);setTimeout(function(){o.remove();},2600);}
  function halt(){stop=true;clearTimeout(poll);offs.forEach(function(f){f();});offs=[];if(ctl){ctl.stop();ctl=null;}}
  var realClose=G.close;
  G.onclose=function(){halt();window.removeEventListener("popstate",onPop);H.classList.remove("lvk");if(location.hash.indexOf("#live=")===0)history.replaceState(null,"",location.href.split("#")[0]);};
  /* زر ✕ و Esc: تأكيد ثم شاشة الخروج (لا يظهر الموقع إلا باختيار صريح) */
  G.close=function(){if(G.el.querySelector(".lv2-dlg"))return;
    if(me&&!stop&&!over){var d=lv2dlg(G.el,'<div class="big" style="font-size:46px">🚪</div><h3>الخروج من الاختبار؟</h3><p style="margin:0;color:#475569">نقاطك محفوظة، ويمكنك العودة في أي وقت بالرمز نفسه.</p><div class="row"><button class="r" data-y>خروج</button><button class="p" data-n>متابعة الاختبار</button></div>');
      d.querySelector("[data-n]").onclick=function(){d.remove();};d.querySelector("[data-y]").onclick=function(){d.remove();out();};}
    else if(!me&&body.querySelector(".lv-form")&&!H.classList.contains("lvk-link"))realClose();
    else out();};
  function out(){halt();var can=me&&!over&&code;G.stat.innerHTML="";U.L.querySelector(".lv2-chat").style.display="none";
    body.innerHTML='<div class="gx-card"><div class="gx-emoji">👋</div><h3>'+(over?'انتهى الاختبار':'خرجت من الاختبار')+'</h3>'+(can?'<p>نقاطك محفوظة. يمكنك العودة الآن وإكمال الاختبار.</p><button class="gx-go" data-back>🔁 العودة إلى الاختبار</button>':'')+
      '<button class="gx-go" data-new style="background:#6366f1">🙋 الدخول برمز آخر</button><p style="margin-top:14px"><button data-site style="border:0;background:none;color:#64748b;text-decoration:underline;font:inherit;cursor:pointer">فتح الموقع</button></p></div>';
    var b=body.querySelector("[data-back]");if(b)b.onclick=function(){join(code,myName);};
    body.querySelector("[data-new]").onclick=function(){me="";code="";form();};body.querySelector("[data-site]").onclick=realClose;}
  var logged=!!(window.STP&&STP.me);
  function form(msg){halt();body.innerHTML='<div class="gx-card"><div class="gx-emoji">🙋</div><h3>انضم إلى الاختبار</h3><p style="color:#64748b;margin:-4px 0 8px;font-size:.95em">اكتب الرمز المكوّن من ٦ أرقام الظاهر على شاشة معلمك</p>'+(msg?'<p style="color:#dc2626;font-weight:700">'+esc(msg)+'</p>':'')+
    '<div class="lv-form"><label>رمز الدخول<input inputmode="numeric" maxlength="7" dir="ltr" data-c value="'+esc(code||"")+'" placeholder="الرمز من شاشة المعلم"></label>'+
    '<label>اسمك<input maxlength="20" data-n value="'+esc(myName)+'" placeholder="اكتب اسمك"'+(logged?' readonly':'')+'></label></div>'+(logged?'<p style="font-size:13px;color:#64748b;margin:0">تدخل باسم حسابك</p>':'')+'<button class="gx-go" data-go>دخول</button></div>';
    var n=body.querySelector("[data-n]"),c=body.querySelector("[data-c]");setTimeout(function(){try{(code&&!logged?n:c).focus();}catch(e){}},50);
    body.querySelector("[data-go]").onclick=go;n.onkeydown=c.onkeydown=function(e){if(e.key==="Enter")go();};}
  function go(){var c=body.querySelector("[data-c]").value.replace(/\D/g,""),n=body.querySelector("[data-n]").value.trim().replace(/[<>]/g,"");
    if(c.length!==6)return form("رمز الدخول من ٦ أرقام.");if(n.length<2)return form("اكتب اسمك (حرفان على الأقل).");join(c,n);}
  function join(c,n){halt();reset();var sv=lvSaved();rk=sv&&sv.c===c&&sv.rk?sv.rk:"";
    code=c;myName=n;base="live/"+code;body.innerHTML='<div class="gx-card"><p>جارٍ الدخول…</p><div class="lv-dots"><i></i><i></i><i></i></div></div>';
    if(location.hash!=="#live="+code)try{history.replaceState(history.state,"",location.href.split("#")[0]+"#live="+code);}catch(e){}
    STP.post("live_op",{op:"join",path:base,v:{n:n,rk:rk}}).then(function(j){me=j.id;myName=j.n||n;rk=j.rk||rk;joinedAt=Date.now();stop=false;
      lvSave({c:code,n:myName,rk:rk,t:Date.now()});G.stat.innerHTML='<span>'+esc(myName)+'</span>';if(j.back)toast("✅ عدت إلى الاختبار، ونقاطك محفوظة");
      if(SRV)U.L.querySelector(".lv2-chat").style.display="";CH=lv2chat(U,base,me,false);listen();})
      .catch(function(e){var m=e&&e.message||"تعذّر الدخول";if(/أخرجك|انتهى|لا يوجد/.test(m))lvSave(null);me="";form(m);});}
  function listen(){
    if(SRV){(function tick(){if(stop)return;fetch("portal/api/index.php?a=live_get&p="+encodeURIComponent(base)+"&me="+encodeURIComponent(me)+"&_="+Date.now(),{credentials:"same-origin",cache:"no-store"})
        .then(function(r){return r.json();}).then(function(j){if(!stop)apply(j&&j.v);}).catch(function(){}).then(function(){if(!stop)poll=setTimeout(tick,document.hidden?3000:1000);});})();}
    else{var S={};function upd(){apply(S.st===undefined?undefined:{st:S.st,sc:S.sc,mod:S.mod,in:1,chat:[],cm:"off"});}
      offs.push(db.on(base+"/st",function(v){S.st=v;upd();}));offs.push(db.on(base+"/sc/"+me,function(v){S.sc=v;upd();}));offs.push(db.on(base+"/mod/"+me,function(v){S.mod=v;upd();}));}}
  function ended(t,e,clr){halt();over=true;if(clr)lvSave(null);body.innerHTML='<div class="gx-card"><div class="gx-emoji">'+(e||"👋")+'</div><h3>'+t+'</h3><button class="gx-go" data-x>🙋 الدخول برمز آخر</button></div>';body.querySelector("[data-x]").onclick=function(){me="";code="";form();};}
  function apply(v){if(v===undefined)return;
    if(!v||!v.st){if(!first||st)return ended("انتهت الجلسة. شكرًا لمشاركتك!","👋",1);first=false;return;}
    first=false;mod=v.mod||{};
    if(mod.k||(!v.in&&Date.now()-joinedAt>4000))return ended("أخرجك المعلم من هذا الاختبار","🚫",1);
    if(mod.wt&&mod.wt!==lastWt){var fresh=!lastWt?Date.now()-mod.wt<60000:true;lastWt=mod.wt;if(fresh)warn(mod.w);}
    if(JSON.stringify(v.chat||[])!==JSON.stringify(chatL)||v.cm!==cm||!!mod.m!==!!CH.mm){CH.mm=!!mod.m;chatL=v.chat||[];cm=v.cm||"free";CH.render(chatL,mod.m?"muted":cm);}
    var scCh=JSON.stringify(v.sc)!==JSON.stringify(sc);sc=v.sc;st=v.st;render(scCh);paused();}
  function warn(t){tone([[660,0,.15,"square"],[440,.18,.25,"square"]]);var d=lv2dlg(G.el,'<div class="big">⚠️</div><h3>تنبيه من المعلم</h3><p style="font-size:18px;font-weight:700">'+esc(t||"")+'</p><div class="row"><button class="p" data-x>حسنًا</button></div>',"lv2-warn");d.querySelector("[data-x]").onclick=function(){d.remove();};}
  function paused(){var ov=U.L.querySelector(".lv2-ov.pz");if(mod.p&&!ov){ov=document.createElement("div");ov.className="lv2-ov pz";ov.innerHTML='<div style="font-size:52px">⏸</div>أوقفك المعلم مؤقتًا<small style="font-weight:700;opacity:.8">انتظر حتى يسمح لك بالمتابعة</small>';body.appendChild(ov);}
    else if(!mod.p&&ov)ov.remove();}
  function render(force){var key=st.ph+":"+st.qi;if(!force&&key===lastPh)return;var same=key===lastPh;lastPh=key;
    if(st.ph!=="q"&&ctl){ctl.stop();ctl=null;}
    if(st.ph==="lobby"){body.innerHTML='<div class="gx-card"><div class="gx-emoji">✅</div><h3>أنت في الاختبار!</h3><p>أهلًا <b>'+esc(myName)+'</b>، انتظر حتى يبدأ المعلم…</p><div class="lv-dots"><i></i><i></i><i></i></div></div>';}
    else if(st.ph==="q"){if(same&&ctl)return;if(st.qi!==lastQi){lastQi=st.qi;answered=-1;shownAt=Date.now();}var qq=st.q||{c:[]};if(ctl)ctl.stop();
      if(window.QGAME){ctl=QGAME.round(body,{game:st.gm||"mlg",q:{q:qq.t||"",c:qq.c||[],qa:qq.qa},idx:st.qi,n:st.n,dur:st.dur||20,start:shownAt,score:sc?sc.s:0,
        onPick:function(k,ms){if(answered>-1)return;if(mod.p){ctl.wait("⏸ أنت موقوف مؤقتًا");return;}answered=k;db.set(base+"/an/"+st.qi+"/"+me,{c:k,t:ms});setTimeout(function(){if(ctl&&lastPh==="q:"+st.qi)ctl.wait('<div style="font-size:46px">⏳</div>تم إرسال إجابتك<br><small style="font-weight:700;opacity:.8">انتظر حتى يكشف المعلم الإجابة…</small>');},500);},
        onTimeout:function(){if(ctl)ctl.wait('<div style="font-size:46px">⌛</div>انتهى الوقت');}});}
      paused();}
    else if(st.ph==="rev"||st.ph==="lb"){if(!sc||sc.qi!==st.qi){body.innerHTML='<div class="gx-card"><p>جارٍ حساب النتائج…</p></div>';lastPh="";return;}
      var ok=sc.ok&&sc.ans;if(st.ph==="rev"&&!body.querySelector(".lv-res"))(ok?LS.ok:LS.no)();
      body.innerHTML='<div class="lv-res '+(ok?'good':'bad')+'" style="margin:auto"><div class="lv-big">'+(ok?'✔':'✘')+'</div><h3>'+(ok?'إجابة صحيحة!':sc.ans?'إجابة خاطئة':'لم تُجب في الوقت')+'</h3>'+
        (ok?'<p class="lv-gain">+'+an(sc.g)+'</p>':'')+(sc.st>=2?'<p>🔥 سلسلة '+an(sc.st)+' إجابات صحيحة</p>':'')+'<p class="lv-rank">ترتيبك: '+an(sc.r)+' من '+an(sc.of||sc.r)+' • نقاطك: '+an(sc.s)+'</p></div>';}
    else if(st.ph==="end"){var r=sc?sc.r:0;if(r&&r<=3){LS.end();gxConfetti(G.el);}halt();over=true;lvSave(null);
      body.innerHTML='<div class="gx-card"><div class="gx-emoji">'+(r===1?'🥇':r===2?'🥈':r===3?'🥉':'🎉')+'</div><h3>انتهى الاختبار!</h3><p class="gx-big">'+(r?'المركز '+an(r):'')+'</p><p>نقاطك: '+an(sc?sc.s:0)+'</p><button class="gx-go" data-x>🙋 الدخول برمز آخر</button></div>';
      body.querySelector("[data-x]").onclick=function(){me="";code="";form();};}}
  body.innerHTML='<div class="gx-card"><p>جارٍ التحميل…</p></div>';
  (window.STP?STP.ready:Promise.resolve(null)).then(function(u){logged=!!u;var sv=lvSaved();if(u)myName=u.name;else if(sv&&sv.n)myName=sv.n;
    if(code&&sv&&sv.c===code&&(u||sv.n))return join(code,myName);   /* عودة تلقائية بعد إعادة التحميل */
    if(!code&&sv)code=sv.c;form();});
}
window.LIVE={host:lvHost,join:lvJoin,ready:lvReady};
/* LV2-END */

/* ================= الخرائط الذهنية التفاعلية ================= */
var MMC=["#4f46e5","#0891b2","#db2777","#059669","#d97706","#7c3aed","#dc2626","#0d9488"];
function openMM(maps,lessonName,start){
  if(!maps||!maps.length)return;
  var el=document.createElement("div");el.id="mm";el.setAttribute("role","dialog");el.setAttribute("aria-label","الخرائط الذهنية");
  el.innerHTML='<div class="mm-top"><button class="mm-ib" data-a="x" aria-label="إغلاق">'+ico("x")+'</button><div class="mm-title"></div>'+
    '<div class="mm-maps"><button class="mm-ib mm-tx" data-a="mp" aria-label="الخريطة السابقة">السابق</button><span class="mm-mi"></span><button class="mm-ib mm-tx" data-a="mn" aria-label="الخريطة التالية">التالي</button></div></div>'+
    '<div class="mm-view"><div class="mm-stage"><svg class="mm-links"></svg></div><div class="mm-hint">اضغط أو اسحب لإظهار الفرع التالي</div></div>'+
    '<div class="mm-ctrl"><button class="mm-b mm-tx" data-a="prev" aria-label="السابق">السابق</button>'+
    '<span class="mm-cnt"></span><button class="mm-b mm-tx" data-a="next" aria-label="التالي">التالي</button>'+
    '<button class="mm-b" data-a="all" aria-label="نظرة شاملة" title="نظرة شاملة"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg></button>'+
    '<button class="mm-b" data-a="show" aria-label="إظهار الكل" title="إظهار الكل"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg></button>'+
    '<button class="mm-b" data-a="restart" aria-label="من البداية"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg></button></div>';
  document.body.appendChild(el);lock(true);
  var view=el.querySelector(".mm-view"),stage=el.querySelector(".mm-stage"),svgL=el.querySelector(".mm-links"),cnt=el.querySelector(".mm-cnt"),hint=el.querySelector(".mm-hint");
  var mi=Math.max(0,Math.min(start||0,maps.length-1)),nodes=[],links=[],steps=0,cur=0,overview=false,portrait=false,SW=1600,SH=900,blocks=[];
  el.querySelector(".mm-maps").style.display=maps.length>1?"":"none";
  function build(){
    var M=maps[mi];el.querySelector(".mm-title").textContent=M.title||"";el.querySelector(".mm-mi").textContent=an(mi+1)+" / "+an(maps.length);
    stage.querySelectorAll(".mm-n").forEach(function(n){n.remove();});svgL.innerHTML="";nodes=[];links=[];blocks=[];
    var vw=view.clientWidth,vh=view.clientHeight;portrait=vw/vh<1.05;
    function mk(kind,text,color,ic){var d=document.createElement("div");d.className="mm-n mm-"+kind;d.style.setProperty("--c",color||"#4f46e5");
      d.innerHTML=(ic?'<i>'+esc(ic)+'</i>':'')+'<span>'+qtx(text)+'</span>';stage.appendChild(d);return d;}
    var c=mk("c",M.center,"#1e1b4b",M.icon);var cN={el:c,step:0};nodes.push(cN);var s=0;
    M.branches.forEach(function(b,i){var col=b.color||MMC[i%MMC.length],bn={el:mk("br",b.t,col,b.i),step:++s,col:col,kids:[]};nodes.push(bn);links.push({a:cN,b:bn,col:col,k:"cb"});
      (b.c||[]).forEach(function(t){var kn={el:mk("k",t,col),step:++s};nodes.push(kn);bn.kids.push(kn);links.push({a:bn,b:kn,col:col,k:"bk"});});
      blocks.push(bn);});
    steps=s;
    // widths by layout, then measure heights
    var CW=portrait?520:360,BW=portrait?520:260,KW=portrait?470:280;
    c.style.width=CW+"px";nodes.forEach(function(n){if(n.el.classList.contains("mm-br"))n.el.style.width=BW+"px";else if(n.el.classList.contains("mm-k"))n.el.style.width=KW+"px";n.h=n.el.offsetHeight;n.w=n.el.offsetWidth;});
    var G=16;
    if(!portrait){
      SW=1600;var nR=Math.ceil(blocks.length/2),sides=[blocks.slice(0,nR),blocks.slice(nR)],maxH=0;
      sides.forEach(function(side){var tot=0;side.forEach(function(b){b.bh=Math.max(b.h,b.kids.reduce(function(a,k){return a+k.h+G;},-G));tot+=b.bh;});tot+=Math.max(0,side.length-1)*44;side.tot=tot;maxH=Math.max(maxH,tot);});
      SH=Math.max(820,maxH+140);cN.x=SW/2;cN.y=SH/2;
      sides.forEach(function(side,si){var dir=si===0?1:-1,y=SH/2-side.tot/2;
        side.forEach(function(b){b.x=SW/2+dir*390;b.y=y+b.bh/2;var ky=b.y-(b.kids.reduce(function(a,k){return a+k.h+G;},-G))/2;
          b.kids.forEach(function(k){k.x=SW/2+dir*690;k.y=ky+k.h/2;ky+=k.h+G;});y+=b.bh+44;});});
    }else{
      SW=640;cN.x=SW/2;cN.y=40+cN.h/2;var y=cN.y+cN.h/2+60;
      blocks.forEach(function(b){b.x=SW/2;b.y=y+b.h/2;y+=b.h+22;b.kids.forEach(function(k){k.x=SW/2-(BW-KW)/2-10;k.y=y+k.h/2;y+=k.h+G;});y+=40;});
      SH=y+20;
    }
    stage.style.width=SW+"px";stage.style.height=SH+"px";svgL.setAttribute("viewBox","0 0 "+SW+" "+SH);svgL.setAttribute("width",SW);svgL.setAttribute("height",SH);
    nodes.forEach(function(n){n.el.style.left=(n.x-n.w/2)+"px";n.el.style.top=(n.y-n.h/2)+"px";});
    links.forEach(function(L){var a=L.a,b=L.b,d;
      if(!portrait){var dir=b.x>a.x?1:-1,x1=a.x+dir*a.w/2,x2=b.x-dir*b.w/2,mx=(x1+x2)/2;d="M"+x1+" "+a.y+" C"+mx+" "+a.y+" "+mx+" "+b.y+" "+x2+" "+b.y;}
      else if(L.k==="cb"){var xs=a.x+a.w/2-30;d="M"+xs+" "+(a.y+a.h/2)+" C"+xs+" "+(b.y-40)+" "+(b.x+b.w/2-30)+" "+(b.y-60)+" "+(b.x+b.w/2-30)+" "+(b.y-b.h/2);}
      else{var bx=a.x+a.w/2-18;d="M"+bx+" "+(a.y+a.h/2)+" L"+bx+" "+b.y+" L"+(b.x+b.w/2)+" "+b.y;}
      var p=document.createElementNS("http://www.w3.org/2000/svg","path");p.setAttribute("d",d);p.setAttribute("stroke",L.col);p.setAttribute("class","mm-l");
      svgL.appendChild(p);var len=p.getTotalLength();p.style.strokeDasharray=len;p.style.strokeDashoffset=len;L.p=p;});
    paint(true);
  }
  function bbox(list){var x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;list.forEach(function(n){x0=Math.min(x0,n.x-n.w/2);x1=Math.max(x1,n.x+n.w/2);y0=Math.min(y0,n.y-n.h/2);y1=Math.max(y1,n.y+n.h/2);});return [x0,y0,x1,y1];}
  function focus(list,instant){var b=bbox(list),pad=portrait?24:50,vw=view.clientWidth,vh=view.clientHeight,bw=b[2]-b[0]+pad*2,bh=b[3]-b[1]+pad*2;
    var s=Math.min(vw/bw,vh/bh,portrait?1.15:1.35),tx=vw/2-(b[0]+b[2])/2*s,ty=vh/2-(b[1]+b[3])/2*s;
    if(portrait&&bh*s>vh){ty=pad*s-b[1]*s+10;}
    stage.style.transition=instant?"none":"transform .8s cubic-bezier(.3,.9,.3,1)";stage.style.transform="translate("+tx+"px,"+ty+"px) scale("+s+")";}
  function paint(instant){
    nodes.forEach(function(n){n.el.classList.toggle("on",n.step<=cur);n.el.classList.toggle("now",n.step===cur);});
    links.forEach(function(L){var on=L.b.step<=cur;L.p.style.strokeDashoffset=on?0:L.p.style.strokeDasharray;L.p.classList.toggle("on",on);});
    cnt.textContent=an(cur)+" / "+an(steps);hint.style.opacity=cur<steps?"":"0";
    var last=nodes.filter(function(n){return n.step===cur;})[0],blk=null;
    blocks.forEach(function(b){if(b.step<=cur&&(b.kids.length?b.kids[b.kids.length-1].step:b.step)>=cur)blk=b;});
    if(overview||cur===0||(!portrait&&cur>=steps&&cur>0))focus(cur===0&&!overview?[nodes[0]]:nodes.filter(function(n){return overview||n.step<=cur;}),instant);
    else if(blk)focus(portrait?[blk].concat(blk.kids.filter(function(k){return k.step<=cur;})):[nodes[0],blk].concat(blk.kids),instant);
    el.querySelector('[data-a="all"]').classList.toggle("on",overview);
  }
  function next(){if(cur<steps){cur++;overview=false;GS.click();tone([[520+cur*12,0,.08,"triangle"]]);paint();}else if(!overview){overview=true;paint();}}
  function back(){if(overview&&cur>=steps){overview=false;}if(cur>0){cur--;paint();}}
  function setMap(i){mi=(i+maps.length)%maps.length;cur=0;overview=false;build();}
  var sx=null,sy=0,swiped=false;
  view.addEventListener("pointerdown",function(e){sx=e.clientX;sy=e.clientY;});
  view.addEventListener("pointerup",function(e){if(sx===null)return;var dx=e.clientX-sx,dy=e.clientY-sy;sx=null;
    if(Math.abs(dx)>40&&Math.abs(dx)>Math.abs(dy)*1.2){swiped=true;if(dx>0)next();else back();setTimeout(function(){swiped=false;},350);}});
  view.addEventListener("click",function(){if(swiped){swiped=false;return;}next();});
  el.addEventListener("click",function(e){var b=e.target.closest("[data-a]");if(!b)return;var a=b.getAttribute("data-a");
    if(a==="x")return close();if(a==="next")next();if(a==="prev")back();if(a==="restart"){cur=0;overview=false;paint();}
    if(a==="all"){overview=!overview;paint();}if(a==="show"){cur=steps;overview=true;paint();}
    if(a==="mp")setMap(mi-1);if(a==="mn")setMap(mi+1);});
  function kd(e){var k=e.key;if(k==="Escape")close();else if(k==="ArrowLeft"||k===" "||k==="Enter"){e.preventDefault();next();}else if(k==="ArrowRight"||k==="Backspace"){e.preventDefault();back();}}
  document.addEventListener("keydown",kd);
  var rt;function rs(){clearTimeout(rt);rt=setTimeout(function(){var c=cur,o=overview;build();cur=c;overview=o;paint(true);},150);}
  window.addEventListener("resize",rs);
  function close(){window.removeEventListener("resize",rs);document.removeEventListener("keydown",kd);el.remove();lock(false);}
  if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){if(document.body.contains(el)){var c=cur;build();cur=c;paint(true);}});
  build();
}
window.MMAP={open:openMM};

/* ================= قسم الطلاب: الدرجات والنقاط والسلوك والحضور ================= */
var CLSK="cls:v1";
var DEFB=[{e:"🙋",n:"مشاركة",p:1},{e:"🤝",n:"تعاون",p:1},{e:"🌟",n:"إجابة متميزة",p:2},{e:"📚",n:"حل الواجب",p:1},{e:"🧹",n:"نظام وترتيب",p:1},{e:"💡",n:"إبداع",p:2},
  {e:"🔇",n:"إزعاج",p:-1},{e:"📕",n:"عدم حل الواجب",p:-1},{e:"⏰",n:"تأخّر",p:-1},{e:"🙈",n:"عدم الانتباه",p:-1}];
function clsLoad(){var d;try{d=JSON.parse(localStorage.getItem(CLSK)||"null");}catch(e){}
  if(!d||!d.classes)d={classes:[],beh:DEFB.slice(),teacher:"",school:"",cur:null};if(!d.beh||!d.beh.length)d.beh=DEFB.slice();return d;}
function clsSave(d){try{localStorage.setItem(CLSK,JSON.stringify(d));return true;}catch(e){alert("تعذّر الحفظ: مساحة التخزين ممتلئة. قلّل الصور أو صدّر نسخة احتياطية.");return false;}}
function uid(){return Math.random().toString(36).slice(2,9);}
window.CLSDATA={load:function(){return clsLoad();},save:function(d){return clsSave(d);},beh:DEFB};
/* صور رمزية جاهزة للبنين والبنات */
var SKIN=["#f8d5b5","#eec39a","#d7a77a","#b98257","#8d5a3b"],BGC=["#c7d2fe","#bbf7d0","#fde68a","#fbcfe8","#bae6fd","#ddd6fe","#fed7aa","#a7f3d0"];
function avSvg(k){var g=k.charAt(0),i=+k.slice(1)||0,sk=SKIN[i%5],bg=BGC[(i*3+(g==="g"?1:0))%8],h="";
  var hairC=["#2b1d14","#4a2e1b","#1f1f1f","#6b3e26","#3b2a20","#7a4b2a","#222","#5a3825"][i%8];
  if(g==="b"){var cap=i%4===3;h='<path d="M18 92c4-18 18-26 32-26s28 8 32 26Z" fill="'+["#3b82f6","#10b981","#f59e0b","#ef4444","#8b5cf6","#0ea5e9","#14b8a6","#6366f1"][i%8]+'"/>'+
      '<circle cx="50" cy="44" r="22" fill="'+sk+'"/>'+(cap?'<path d="M27 38a23 23 0 0 1 46 0Z" fill="#e11d48"/><path d="M50 36h28v5H50Z" fill="#be123c"/>':
      (i%4===1?'<path d="M28 42c0-16 9-22 22-22s22 6 22 22c-4-8-10-10-22-10s-18 2-22 10Z" fill="'+hairC+'"/>':'<path d="M28 40c2-14 10-19 22-19s20 5 22 19c-6-6-14-8-22-8s-16 2-22 8Z" fill="'+hairC+'"/>'+(i%4===2?'<path d="M30 30q20-14 40 0" stroke="'+hairC+'" stroke-width="6" fill="none"/>':'')));}
  else{var hij=i<6;if(hij){var hc=["#ec4899","#8b5cf6","#0ea5e9","#14b8a6","#f97316","#64748b","#e11d48","#22c55e"][i%8];
      h='<path d="M16 94c3-20 16-30 34-30s31 10 34 30Z" fill="'+hc+'"/><path d="M24 50a26 28 0 0 1 52 0v14c0 12-12 22-26 22s-26-10-26-22Z" fill="'+hc+'"/>'+
        '<ellipse cx="50" cy="48" rx="17" ry="19" fill="'+sk+'"/><path d="M24 50a26 28 0 0 1 52 0" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="3"/>';}
    else{h='<path d="M18 94c3-18 16-28 32-28s29 10 32 28Z" fill="'+["#f472b6","#a78bfa","#38bdf8","#34d399"][i%4]+'"/><path d="M26 46c0-18 10-26 24-26s24 8 24 26v26c-6-4-8-14-8-22-6 4-26 4-32 0 0 8-2 18-8 22Z" fill="'+hairC+'"/>'+
        '<circle cx="50" cy="45" r="19" fill="'+sk+'"/><path d="M31 40c4-10 10-14 19-14s15 4 19 14c-8-4-30-4-38 0Z" fill="'+hairC+'"/>'+(i%2?'<circle cx="70" cy="30" r="5" fill="#f43f5e"/>':'');}}
  var face='<circle cx="43" cy="'+(g==="g"&&i<6?47:45)+'" r="2.6" fill="#1f2937"/><circle cx="57" cy="'+(g==="g"&&i<6?47:45)+'" r="2.6" fill="#1f2937"/>'+
    '<path d="M43 '+(g==="g"&&i<6?55:53)+'q7 6 14 0" stroke="#9f1239" stroke-width="2.6" fill="none" stroke-linecap="round"/><circle cx="38" cy="52" r="3" fill="#fb7185" opacity=".35"/><circle cx="62" cy="52" r="3" fill="#fb7185" opacity=".35"/>';
  return '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><rect width="100" height="100" fill="'+bg+'"/>'+h+face+'</svg>';}
function avHtml(s){if(s.av&&s.av.indexOf("data:")===0)return '<img src="'+s.av+'" alt="">';return avSvg(s.av||((s.g==="g"?"g":"b")+(s.name.length%8)));}
function shrinkImg(file,cb){var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var S=200,c=document.createElement("canvas"),m=Math.min(im.width,im.height);
  c.width=S;c.height=S;c.getContext("2d").drawImage(im,(im.width-m)/2,(im.height-m)/2,m,m,0,0,S,S);cb(c.toDataURL("image/jpeg",.78));};im.onerror=function(){alert("تعذّرت قراءة الصورة.");};im.src=r.result;};r.readAsDataURL(file);}
var CS={plus:function(){tone([[784,0,.1,"triangle"],[1047,.08,.18,"triangle"],[1319,.16,.22,"sine"]]);},minus:function(){tone([[330,0,.18,"triangle"],[247,.12,.3,"triangle"]]);},
  tap:function(){tone([[880,0,.04,"triangle"]]);},save:function(){tone([[660,0,.06],[990,.06,.1]]);}};
function today(){var d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");}
function evalOf(p){return p>=90?["ممتاز","#16a34a"]:p>=80?["جيد جدًّا","#0891b2"]:p>=65?["جيد","#4f46e5"]:p>=50?["مقبول","#d97706"]:["يحتاج إلى دعم","#dc2626"];}
function lvl(p){return p>=100?["👑","أسطورة"]:p>=60?["🏆","بطل"]:p>=30?["🥇","متميز"]:p>=10?["⭐","نجم"]:["🌱","مبتدئ"];}

function openCLS(again){
  if(!(window.STP&&STP.isStaff())&&!again&&location.protocol.indexOf("http")===0){
    fetch("portal/api/index.php?a=me&_="+Date.now(),{credentials:"same-origin",cache:"no-store"}).then(function(r){return r.json();}).then(function(j){STP.me=j.user||null;STP.csrf=j.csrf||STP.csrf;openCLS(true);}).catch(function(){openCLS(true);});return;}
  if(!(window.STP&&STP.isStaff())){if(confirm("قسم الطلاب خاص بالمعلمين.\nسجّل الدخول بحساب المعلم للوصول إليه."))location.href=PORTAL_URL();return;}
  var D=clsLoad(),tab="stu",sel=null,el=document.createElement("div");el.id="cls";el.setAttribute("role","dialog");el.setAttribute("aria-label","قسم الطلاب");
  el.innerHTML='<div class="cl-top"><button class="cl-ib" data-a="x" aria-label="إغلاق">'+ico("x")+'</button><div class="cl-ttl">قسم الطلاب</div>'+
    '<select class="cl-sel" aria-label="الفصل"></select><button class="cl-ib cl-crt" data-a="crt" aria-label="شهادات التكريم" title="شهادات التكريم للفصل">🏅</button><button class="cl-ib" data-a="snd" aria-label="الصوت">'+ico(muted?"mute":"snd")+'</button></div>'+
    '<div class="cl-tabs">'+[["stu","👥 الطلاب"],["pts","⭐ الصدارة"],["grd","📝 الدرجات"],["att","✅ الحضور"],["set","⚙️ الإعدادات"]].map(function(t){return '<button data-t="'+t[0]+'">'+t[1]+'</button>';}).join("")+'</div>'+
    '<div class="cl-body"></div>';
  document.body.appendChild(el);lock(true);
  var body=el.querySelector(".cl-body"),selEl=el.querySelector(".cl-sel");
  function C(){return D.classes.filter(function(c){return c.id===D.cur;})[0]||D.classes[0]||null;}
  /* المعلم المسجّل في البوابة: تُحفظ البيانات على الخادم أيضًا، فتظهر على أي جهاز */
  var cloudT=null,cloudOn=false;
  function cloudSave(){if(!cloudOn)return;clearTimeout(cloudT);cloudT=setTimeout(function(){var b=el.querySelector(".cl-cloud");if(b)b.textContent="☁️ جارٍ الحفظ…";
    STP.post("cls_save",{data:JSON.stringify(D)}).then(function(){if(b)b.textContent="☁️ محفوظ على حسابك";}).catch(function(){if(b)b.textContent="⚠️ لم يُحفظ على الخادم";});},900);}
  function save(){var r=clsSave(D);cloudSave();return r;}
  function close(){el.remove();lock(!!document.getElementById("gmh"));document.removeEventListener("keydown",kd);}
  function kd(e){if(e.key==="Escape"){var m=el.querySelector(".cl-modal");if(m)m.remove();else close();}}document.addEventListener("keydown",kd);
  el.querySelector(".cl-top").onclick=function(e){var b=e.target.closest("[data-a]");if(!b)return;if(b.getAttribute("data-a")==="x")close();else if(b.getAttribute("data-a")==="crt"){var cc=C();window.CERTS&&CERTS.open(cc?cc.name:"");var cr=document.getElementById("crt");if(cr)cr.style.zIndex="2147483200";}else{muted=!muted;b.innerHTML=ico(muted?"mute":"snd");}};
  el.querySelectorAll("[data-t]").forEach(function(b){b.onclick=function(){tab=b.getAttribute("data-t");CS.tap();draw();};});
  selEl.onchange=function(){if(selEl.value==="+")return newClass();D.cur=selEl.value;save();draw();};
  function fillSel(){var c=C();selEl.innerHTML=D.classes.map(function(x){return '<option value="'+x.id+'"'+(c&&x.id===c.id?' selected':'')+'>'+esc(x.name)+'</option>';}).join("")+'<option value="+">+ فصل جديد</option>';
    if(!D.classes.length)selEl.value="+";}
  function newClass(){var n=prompt("اسم الفصل (مثال: ١٠/٣):","");if(!n||!n.trim()){fillSel();return;}var c={id:uid(),name:n.trim(),students:[],assess:[],att:{}};D.classes.push(c);D.cur=c.id;save();CS.save();draw();}
  function modal(html,cls){var m=document.createElement("div");m.className="cl-modal";m.innerHTML='<div class="cl-sheet '+(cls||"")+'">'+html+'</div>';
    m.onclick=function(e){if(e.target===m)m.remove();};el.appendChild(m);return m;}
  function draw(){fillSel();el.querySelectorAll("[data-t]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-t")===tab);});var c=C();
    if(!c&&tab!=="set"){body.innerHTML='<div class="cl-empty"><div class="gx-emoji">🏫</div><h3>ابدأ بإنشاء فصلك الأول</h3><p>أضف الفصل ثم أسماء الطلاب، وابدأ بمنح النقاط وتسجيل الدرجات والحضور.</p><button class="gx-go" data-new>+ إنشاء فصل</button>'+
      '<p class="cl-note">🔒 تُحفظ البيانات على هذا الجهاز فقط ولا تُرفع إلى الإنترنت. استخدم «نسخة احتياطية» في الإعدادات لنقلها لجهاز آخر.</p></div>';
      body.querySelector("[data-new]").onclick=newClass;return;}
    ({stu:drawStu,pts:drawBoard,grd:drawGrades,att:drawAtt,set:drawSet})[tab](c);}
  /* ---- الطلاب ---- */
  function drawStu(c){var S=c.students;
    body.innerHTML='<div class="cl-bar"><button class="cl-btn pri" data-add>+ طالب</button><button class="cl-btn" data-all>⭐ للفصل كله</button><button class="cl-btn" data-rnd>🎲 اختيار عشوائي</button>'+
      '<span class="cl-sum">'+an(S.length)+' طالب • '+an(S.reduce(function(a,s){return a+(s.pts||0);},0))+' نقطة</span></div>'+
      (S.length?'<div class="cl-grid">'+S.map(function(s){var L=lvl(s.pts||0);return '<div class="cl-card" data-s="'+s.id+'"><button class="cl-more" data-p="'+s.id+'" aria-label="ملف الطالب">⋯</button>'+
        '<div class="cl-av">'+avHtml(s)+'</div><b>'+esc(s.name)+'</b><span class="cl-pt'+((s.pts||0)<0?' neg':'')+'">'+L[0]+' '+an(s.pts||0)+'</span></div>';}).join("")+'</div>'
       :'<div class="cl-empty"><p>لا يوجد طلاب بعد. اضغط «+ طالب» للإضافة.</p></div>');
    body.querySelector("[data-add]").onclick=function(){editStu(null);};
    body.querySelector("[data-all]").onclick=function(){if(S.length)award(null);};
    body.querySelector("[data-rnd]").onclick=function(){if(S.length)pick();};
    body.querySelectorAll(".cl-card").forEach(function(cd){cd.onclick=function(e){if(e.target.closest(".cl-more"))return;award(cd.getAttribute("data-s"));};});
    body.querySelectorAll(".cl-more").forEach(function(b){b.onclick=function(){profile(b.getAttribute("data-p"));};});}
  function stu(id){return C().students.filter(function(s){return s.id===id;})[0];}
  function award(id){var s=id?stu(id):null,B=D.beh;
    var m=modal('<div class="cl-sh-h">'+(s?'<div class="cl-av sm">'+avHtml(s)+'</div><h3>'+esc(s.name)+'</h3>':'<h3>⭐ نقاط للفصل كله</h3>')+'<button class="cl-x">✕</button></div>'+
      '<p class="cl-lbl">إيجابي</p><div class="cl-bh">'+B.map(function(b,i){return b.p>0?'<button class="cl-bb pos" data-b="'+i+'"><i>'+esc(b.e)+'</i><span>'+esc(b.n)+'</span><em>+'+an(b.p)+'</em></button>':'';}).join("")+'</div>'+
      '<p class="cl-lbl">يحتاج إلى تحسين</p><div class="cl-bh">'+B.map(function(b,i){return b.p<0?'<button class="cl-bb neg" data-b="'+i+'"><i>'+esc(b.e)+'</i><span>'+esc(b.n)+'</span><em>'+an(b.p)+'</em></button>':'';}).join("")+'</div>');
    m.querySelector(".cl-x").onclick=function(){m.remove();};
    m.querySelectorAll("[data-b]").forEach(function(btn){btn.onclick=function(){var b=B[+btn.getAttribute("data-b")],list=s?[s]:C().students;
      list.forEach(function(x){x.pts=(x.pts||0)+b.p;x.log=x.log||[];x.log.unshift({t:Date.now(),e:b.e,n:b.n,p:b.p});if(x.log.length>150)x.log.length=150;});save();m.remove();
      (b.p>0?CS.plus:CS.minus)();drawStu(C());list.forEach(function(x){var cd=body.querySelector('[data-s="'+x.id+'"]');if(!cd)return;cd.classList.add(b.p>0?"pop":"shake");
        var f=document.createElement("div");f.className="cl-float "+(b.p>0?"pos":"neg");f.textContent=(b.p>0?"+":"")+an(b.p)+" "+b.e;cd.appendChild(f);setTimeout(function(){f.remove();cd.classList.remove("pop","shake");},1300);});
      if(b.p>0&&!s&&window.gxConfetti)gxConfetti(el);};});}
  function pick(){var S=C().students,m=modal('<div class="cl-pick"><div class="cl-av lg"></div><h3>…</h3></div>','center'),i=0,n=18+Math.floor(Math.random()*S.length),av=m.querySelector(".cl-av"),h=m.querySelector("h3");
    (function step(){var s=S[i%S.length];av.innerHTML=avHtml(s);h.textContent=s.name;GS.click();i++;if(i<n)setTimeout(step,60+i*i*.9);else{CS.plus();av.classList.add("win");gxConfetti(el);
      m.querySelector(".cl-pick").insertAdjacentHTML("beforeend",'<button class="gx-go" data-again>اختيار آخر</button>');m.querySelector("[data-again]").onclick=function(){m.remove();pick();};}})();}
  function editStu(id){var fg=window.EDU_G&&EDU_G()==="f",s=id?stu(id):{id:uid(),name:"",g:fg?"g":"b",av:fg?"g0":"b0",phone:"",tg:"",notes:"",pts:0,log:[],marks:{}},av=s.av;
    var m=modal('<div class="cl-sh-h"><h3>'+(id?'تعديل بيانات الطالب':'إضافة طالب')+'</h3><button class="cl-x">✕</button></div>'+
      '<div class="cl-form"><div class="cl-avpick"><div class="cl-av lg cur"></div><label class="cl-btn">📷 صورة الطالب<input type="file" accept="image/*" hidden data-f></label></div>'+
      '<label>الاسم<input data-n maxlength="40" value="'+esc(s.name)+'"></label>'+
      '<div class="cl-gen" data-nog><button data-g="b">👦 طالب</button><button data-g="g">👧 طالبة</button></div>'+
      '<p class="cl-lbl">صورة رمزية</p><div class="cl-avs"></div>'+
      '<label>رقم جوال ولي الأمر (واتساب) <small>بالمفتاح الدولي، مثال: 96550000000</small><input data-ph inputmode="tel" dir="ltr" value="'+esc(s.phone||"")+'"></label>'+
      '<label>معرّف تليجرام (اختياري) <small>بدون @</small><input data-tg dir="ltr" value="'+esc(s.tg||"")+'"></label>'+
      '<label>ملاحظات<textarea data-no rows="2">'+esc(s.notes||"")+'</textarea></label></div>'+
      '<div class="cl-act"><button class="gx-go" data-sv>حفظ</button>'+(id?'<button class="cl-btn danger" data-del>🗑 حذف الطالب</button>':'')+'</div>');
    var g=s.g;function avs(){m.querySelector(".cl-avs").innerHTML=[0,1,2,3,4,5,6,7].map(function(i){var k=g+i;return '<button data-av="'+k+'" class="'+(av===k?'on':'')+'">'+avSvg(k)+'</button>';}).join("");
      m.querySelectorAll("[data-av]").forEach(function(b){b.onclick=function(){av=b.getAttribute("data-av");CS.tap();avs();cur();};});
      m.querySelectorAll("[data-g]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-g")===g);});}
    function cur(){m.querySelector(".cl-av.cur").innerHTML=avHtml({av:av,g:g,name:s.name||"x"});}
    m.querySelectorAll("[data-g]").forEach(function(b){b.onclick=function(){g=b.getAttribute("data-g");if(!av||av.indexOf("data:")!==0)av=g+(av?av.slice(1):"0");avs();cur();};});
    m.querySelector("[data-f]").onchange=function(e){var f=e.target.files[0];if(f)shrinkImg(f,function(u){av=u;cur();avs();});};
    avs();cur();m.querySelector(".cl-x").onclick=function(){m.remove();};
    m.querySelector("[data-sv]").onclick=function(){var n=m.querySelector("[data-n]").value.trim();if(!n)return alert("اكتب اسم الطالب.");
      s.name=n;s.g=g;s.av=av;s.phone=m.querySelector("[data-ph]").value.replace(/\D/g,"");s.tg=m.querySelector("[data-tg]").value.trim().replace(/^@/,"");s.notes=m.querySelector("[data-no]").value.trim();
      if(!id)C().students.push(s);if(save()!==false){CS.save();m.remove();if(el.querySelector(".cl-modal"))el.querySelectorAll(".cl-modal").forEach(function(x){x.remove();});draw();if(id)profile(id);}};
    var del=m.querySelector("[data-del]");if(del)del.onclick=function(){if(!confirm("حذف "+s.name+" نهائيًّا مع كل بياناته؟"))return;var c=C();c.students=c.students.filter(function(x){return x.id!==s.id;});
      Object.keys(c.att).forEach(function(d){delete c.att[d][s.id];});save();el.querySelectorAll(".cl-modal").forEach(function(x){x.remove();});CS.minus();draw();};}
  function stats(c,s){var a={p:0,a:0,l:0};Object.keys(c.att).forEach(function(d){var v=c.att[d][s.id];if(v)a[v]++;});
    var tot=0,max=0;c.assess.forEach(function(x){var v=s.marks&&s.marks[x.id];if(v!==undefined&&v!==""){tot+=+v;max+=+x.max;}});return {att:a,tot:tot,max:max,pct:max?Math.round(tot/max*100):null};}
  function report(c,s){var st=stats(c,s),girl=s.g==="g",L=[];
    L.push("السلام عليكم ورحمة الله، ولي أمر "+(girl?"الطالبة":"الطالب")+" "+s.name+" المحترم،");
    L.push("تقرير "+(girl?"ابنتكم":"ابنكم")+" في فصل "+c.name+(D.school?" – "+D.school:"")+":");
    L.push("⭐ النقاط: "+(s.pts||0)+" ("+lvl(s.pts||0)[1]+")");
    if(c.assess.length){L.push("📝 الدرجات:");c.assess.forEach(function(x){var v=s.marks&&s.marks[x.id];L.push("• "+x.n+": "+(v===undefined||v===""?"—":v)+" / "+x.max);});
      if(st.pct!==null)L.push("المجموع: "+st.tot+" / "+st.max+" ("+st.pct+"%) – "+evalOf(st.pct)[0]);}
    L.push("✅ الحضور: حاضر "+st.att.p+" • غائب "+st.att.a+" • متأخر "+st.att.l);
    var pos=(s.log||[]).filter(function(x){return x.p>0;}).slice(0,3).map(function(x){return x.n;}),neg=(s.log||[]).filter(function(x){return x.p<0;}).slice(0,3).map(function(x){return x.n;});
    if(pos.length)L.push("🌟 أبرز الإيجابيات: "+pos.join("، "));if(neg.length)L.push("🔔 يحتاج إلى متابعة: "+neg.join("، "));
    if(s.notes)L.push("🗒 ملاحظات: "+s.notes);L.push("مع تحيات "+(D.teacher||(window.EDU_G&&EDU_G()==="f"?"المعلمة":"المعلم"))+" 🌷");return L.join("\n");}
  function profile(id){var c=C(),s=stu(id),st=stats(c,s),L=lvl(s.pts||0),e=st.pct!==null?evalOf(st.pct):null;CS.tap();
    var m=modal('<div class="cl-sh-h"><h3>ملف الطالب</h3><button class="cl-x">✕</button></div>'+
      '<div class="cl-prof"><div class="cl-av lg">'+avHtml(s)+'</div><h2>'+esc(s.name)+'</h2><span class="cl-badge">'+L[0]+' '+L[1]+'</span></div>'+
      '<div class="cl-kpis"><div><b>'+an(s.pts||0)+'</b><span>نقطة</span></div><div><b>'+(st.pct===null?'—':an(st.pct)+'٪')+'</b><span>'+(e?e[0]:'الدرجات')+'</span></div>'+
      '<div><b>'+an(st.att.p)+'</b><span>حضور</span></div><div><b>'+an(st.att.a)+'</b><span>غياب</span></div></div>'+
      (c.assess.length?'<p class="cl-lbl">الدرجات</p><div class="cl-marks">'+c.assess.map(function(x){var v=s.marks&&s.marks[x.id];return '<div><span>'+esc(x.n)+'</span><b>'+(v===undefined||v===""?'—':an(v))+' / '+an(x.max)+'</b></div>';}).join("")+'</div>':'')+
      '<p class="cl-lbl">آخر السلوكيات</p><div class="cl-log">'+((s.log||[]).slice(0,12).map(function(x){var d=new Date(x.t);return '<div class="'+(x.p>0?'pos':'neg')+'"><i>'+esc(x.e)+'</i><span>'+esc(x.n)+'</span><em>'+(x.p>0?'+':'')+an(x.p)+'</em><small>'+an(d.getDate())+'/'+an(d.getMonth()+1)+'</small></div>';}).join("")||'<p class="cl-note">لا يوجد سجل بعد.</p>')+'</div>'+
      (s.notes?'<p class="cl-lbl">ملاحظات</p><p class="cl-notes">'+esc(s.notes)+'</p>':'')+
      '<div class="cl-act">'+(s.phone?'<button class="cl-btn wa" data-wa>واتساب</button>':'')+'<button class="cl-btn tg" data-tg>تليجرام</button><button class="cl-btn" data-cp>نسخ التقرير</button>'+
      '<button class="cl-btn" data-ed>✏️ تعديل</button><button class="cl-btn" data-rs>تصفير النقاط</button></div>'+
      (s.phone?'':'<p class="cl-note">لإرسال التقرير عبر واتساب أضف رقم ولي الأمر من «تعديل».</p>'),"tall");
    m.querySelector(".cl-x").onclick=function(){m.remove();};
    var msg=report(c,s);
    var wa=m.querySelector("[data-wa]");if(wa)wa.onclick=function(){window.open("https://wa.me/"+s.phone+"?text="+encodeURIComponent(msg),"_blank");};
    m.querySelector("[data-tg]").onclick=function(){copy(msg);var u=s.tg?"https://t.me/"+encodeURIComponent(s.tg):"https://t.me/share/url?url="+encodeURIComponent(" ")+"&text="+encodeURIComponent(msg);
      window.open(u,"_blank");if(s.tg)toast("نُسخ التقرير، الصقه في المحادثة");};
    m.querySelector("[data-cp]").onclick=function(){copy(msg);toast("تم نسخ التقرير");};
    m.querySelector("[data-ed]").onclick=function(){editStu(id);};
    m.querySelector("[data-rs]").onclick=function(){if(confirm("تصفير نقاط "+s.name+"؟")){s.pts=0;s.log=[];save();m.remove();draw();profile(id);}};}
  function copy(t){try{navigator.clipboard.writeText(t);}catch(e){var a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();try{document.execCommand("copy");}catch(_){}a.remove();}}
  function toast(t){var d=document.createElement("div");d.className="cl-toast";d.textContent=t;el.appendChild(d);setTimeout(function(){d.remove();},2200);}
  /* ---- الصدارة ---- */
  function drawBoard(c){var R=c.students.slice().sort(function(a,b){return (b.pts||0)-(a.pts||0);}),top=[1,0,2].filter(function(i){return R[i];});
    body.innerHTML=R.length?'<div class="cl-pod">'+top.map(function(i){var s=R[i];return '<div class="cl-pd p'+(i+1)+'"><div class="cl-av md">'+avHtml(s)+'</div><b>'+esc(s.name)+'</b><span>'+an(s.pts||0)+'</span><div class="cl-col">'+["🥇","🥈","🥉"][i]+'</div></div>';}).join("")+'</div>'+
      '<div class="cl-rank">'+R.map(function(s,i){var L=lvl(s.pts||0);return '<div style="--d:'+(i*.05)+'s"><b>'+an(i+1)+'</b><div class="cl-av xs">'+avHtml(s)+'</div><span>'+esc(s.name)+'</span><i>'+L[0]+'</i><em>'+an(s.pts||0)+'</em></div>';}).join("")+'</div>'
      :'<div class="cl-empty"><p>أضف طلابًا لتظهر لوحة الصدارة.</p></div>';
    if(R.length&&(R[0].pts||0)>0)CS.save();}
  /* ---- الدرجات ---- */
  function drawGrades(c){var S=c.students,A=c.assess;
    body.innerHTML='<div class="cl-bar"><button class="cl-btn pri" data-na>+ تقييم</button><button class="cl-btn" data-csv>⬇️ تصدير Excel</button><span class="cl-sum">اكتب الدرجة مباشرة في الجدول</span></div>'+
      (A.length&&S.length?'<div class="cl-tw"><table class="cl-tbl"><thead><tr><th>الطالب</th>'+A.map(function(x){return '<th><button data-ea="'+x.id+'">'+esc(x.n)+'<small>من '+an(x.max)+'</small></button></th>';}).join("")+'<th>المجموع</th><th>التقدير</th></tr></thead><tbody>'+
        S.map(function(s){var st=stats(c,s),e=st.pct!==null?evalOf(st.pct):null;return '<tr><td><div class="cl-nm"><div class="cl-av xs">'+avHtml(s)+'</div>'+esc(s.name)+'</div></td>'+
          A.map(function(x){var v=s.marks&&s.marks[x.id];return '<td><input inputmode="decimal" data-sid="'+s.id+'" data-aid="'+x.id+'" value="'+(v===undefined?"":esc(v))+'"></td>';}).join("")+
          '<td class="cl-tot" data-tot="'+s.id+'">'+(st.max?an(st.tot)+' / '+an(st.max):'—')+'</td><td data-ev="'+s.id+'">'+(e?'<span class="cl-ev" style="--c:'+e[1]+'">'+e[0]+'</span>':'—')+'</td></tr>';}).join("")+'</tbody></table></div>'
       :'<div class="cl-empty"><p>'+(S.length?'أضف تقييمًا (مثل: اختبار قصير ١، واجب، مشاركة) لتبدأ برصد الدرجات.':'أضف طلابًا أولًا من تبويب «الطلاب».')+'</p></div>');
    body.querySelector("[data-na]").onclick=function(){editAssess(null);};
    body.querySelector("[data-csv]").onclick=function(){csv(c);};
    body.querySelectorAll("[data-ea]").forEach(function(b){b.onclick=function(){editAssess(b.getAttribute("data-ea"));};});
    body.querySelectorAll("input[data-sid]").forEach(function(i){i.onchange=function(){var s=stu(i.getAttribute("data-sid")),a=c.assess.filter(function(x){return x.id===i.getAttribute("data-aid");})[0],v=i.value.trim().replace(/[٠-٩]/g,function(d){return "٠١٢٣٤٥٦٧٨٩".indexOf(d);});
      if(v!==""&&(isNaN(+v)||+v<0||+v>+a.max)){i.classList.add("bad");CS.minus();return toast("الدرجة بين ٠ و "+an(a.max));}i.classList.remove("bad");s.marks=s.marks||{};if(v==="")delete s.marks[a.id];else s.marks[a.id]=+v;save();CS.tap();
      var st=stats(c,s),e=st.pct!==null?evalOf(st.pct):null;body.querySelector('[data-tot="'+s.id+'"]').textContent=st.max?an(st.tot)+' / '+an(st.max):'—';
      body.querySelector('[data-ev="'+s.id+'"]').innerHTML=e?'<span class="cl-ev" style="--c:'+e[1]+'">'+e[0]+'</span>':'—';};
      i.onkeydown=function(e){if(e.key==="Enter"){e.preventDefault();var all=[].slice.call(body.querySelectorAll("input[data-sid]")),k=all.indexOf(i),cols=c.assess.length,n=all[k+cols]||all[k+1];if(n)n.focus();}};});}
  function editAssess(aid){var c=C(),a=aid?c.assess.filter(function(x){return x.id===aid;})[0]:{id:uid(),n:"",max:10};
    var m=modal('<div class="cl-sh-h"><h3>'+(aid?'تعديل التقييم':'تقييم جديد')+'</h3><button class="cl-x">✕</button></div><div class="cl-form"><label>اسم التقييم<input data-n value="'+esc(a.n)+'" placeholder="اختبار قصير ١"></label>'+
      '<label>الدرجة العظمى<input data-m inputmode="numeric" value="'+esc(a.max)+'"></label></div><div class="cl-act"><button class="gx-go" data-sv>حفظ</button>'+(aid?'<button class="cl-btn danger" data-del>🗑 حذف التقييم</button>':'')+'</div>');
    m.querySelector(".cl-x").onclick=function(){m.remove();};
    m.querySelector("[data-sv]").onclick=function(){var n=m.querySelector("[data-n]").value.trim(),mx=+m.querySelector("[data-m]").value.replace(/[٠-٩]/g,function(d){return "٠١٢٣٤٥٦٧٨٩".indexOf(d);});
      if(!n||!(mx>0))return alert("اكتب اسم التقييم والدرجة العظمى.");a.n=n;a.max=mx;if(!aid)c.assess.push(a);save();CS.save();m.remove();draw();};
    var d=m.querySelector("[data-del]");if(d)d.onclick=function(){if(!confirm("حذف التقييم ودرجاته؟"))return;c.assess=c.assess.filter(function(x){return x.id!==aid;});c.students.forEach(function(s){if(s.marks)delete s.marks[aid];});save();m.remove();draw();};}
  function csv(c){var rows=[["الطالب"].concat(c.assess.map(function(x){return x.n+" ("+x.max+")";})).concat(["المجموع","النسبة","التقدير","النقاط","حضور","غياب","تأخر"])];
    c.students.forEach(function(s){var st=stats(c,s);rows.push([s.name].concat(c.assess.map(function(x){var v=s.marks&&s.marks[x.id];return v===undefined?"":v;})).concat([st.max?st.tot+"/"+st.max:"",st.pct===null?"":st.pct+"%",st.pct===null?"":evalOf(st.pct)[0],s.pts||0,st.att.p,st.att.a,st.att.l]));});
    var t="\ufeff"+rows.map(function(r){return r.map(function(v){v=String(v);return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}).join(",");}).join("\r\n");
    var a=document.createElement("a");a.href=URL.createObjectURL(new Blob([t],{type:"text/csv;charset=utf-8"}));a.download="درجات "+c.name+".csv";document.body.appendChild(a);a.click();a.remove();}
  /* ---- الحضور ---- */
  function drawAtt(c,day){day=day||today();var A=c.att[day]||{},S=c.students,cnt={p:0,a:0,l:0};S.forEach(function(s){if(A[s.id])cnt[A[s.id]]++;});
    body.innerHTML='<div class="cl-bar"><input type="date" class="cl-date" value="'+day+'"><button class="cl-btn" data-allp>✅ الكل حاضر</button>'+
      '<span class="cl-sum">حاضر '+an(cnt.p)+' • غائب '+an(cnt.a)+' • متأخر '+an(cnt.l)+'</span></div>'+
      (S.length?'<div class="cl-att">'+S.map(function(s){var v=A[s.id]||"";return '<div class="cl-ar"><div class="cl-av xs">'+avHtml(s)+'</div><span>'+esc(s.name)+'</span><div class="cl-seg">'+
        [["p","حاضر"],["l","متأخر"],["a","غائب"]].map(function(o){return '<button data-sid="'+s.id+'" data-v="'+o[0]+'" class="'+o[0]+(v===o[0]?' on':'')+'">'+o[1]+'</button>';}).join("")+'</div></div>';}).join("")+'</div>'
       :'<div class="cl-empty"><p>أضف طلابًا أولًا.</p></div>');
    body.querySelector(".cl-date").onchange=function(e){drawAtt(c,e.target.value||today());};
    body.querySelector("[data-allp]").onclick=function(){c.att[day]=c.att[day]||{};S.forEach(function(s){c.att[day][s.id]="p";});save();CS.plus();drawAtt(c,day);};
    body.querySelectorAll(".cl-seg button").forEach(function(b){b.onclick=function(){c.att[day]=c.att[day]||{};var id=b.getAttribute("data-sid"),v=b.getAttribute("data-v");
      if(c.att[day][id]===v)delete c.att[day][id];else c.att[day][id]=v;save();(v==="a"?CS.minus:CS.tap)();drawAtt(c,day);};});}
  /* ---- الإعدادات ---- */
  function drawSet(c){body.innerHTML='<div class="cl-set">'+
    '<section><h4>بياناتك</h4><div class="cl-form"><label>اسم المعلم/ة (يظهر في رسائل أولياء الأمور)<input data-tn value="'+esc(D.teacher||"")+'"></label><label>المدرسة<input data-sc value="'+esc(D.school||"")+'"></label></div></section>'+
    (c?'<section><h4>الفصل الحالي: '+esc(c.name)+'</h4><div class="cl-act"><button class="cl-btn" data-rn>✏️ إعادة تسمية</button><button class="cl-btn" data-rsall>تصفير نقاط الفصل</button><button class="cl-btn danger" data-dc>🗑 حذف الفصل</button></div></section>':'')+
    '<section><h4>السلوكيات والنقاط</h4><div class="cl-bl">'+D.beh.map(function(b,i){return '<div><input class="e" data-be="'+i+'" value="'+esc(b.e)+'" maxlength="4"><input data-bn="'+i+'" value="'+esc(b.n)+'"><input class="p" data-bp="'+i+'" value="'+b.p+'" inputmode="numeric"><button data-bd="'+i+'" aria-label="حذف">✕</button></div>';}).join("")+
      '</div><div class="cl-act"><button class="cl-btn" data-ba>+ سلوك</button><button class="cl-btn pri" data-bs>حفظ السلوكيات</button></div></section>'+
    '<section><h4>النسخ الاحتياطي</h4><p class="cl-note">🔒 البيانات محفوظة على هذا الجهاز فقط. صدّر نسخة احتياطية بانتظام، أو لنقلها إلى جهاز آخر.</p><div class="cl-act"><button class="cl-btn" data-ex>⬇️ تصدير نسخة</button><label class="cl-btn">⬆️ استيراد نسخة<input type="file" accept=".json,application/json" hidden data-im></label></div></section></div>';
    var q=function(s){return body.querySelector(s);};
    q("[data-tn]").onchange=function(e){D.teacher=e.target.value.trim();save();CS.tap();};q("[data-sc]").onchange=function(e){D.school=e.target.value.trim();save();CS.tap();};
    if(c){q("[data-rn]").onclick=function(){var n=prompt("الاسم الجديد للفصل:",c.name);if(n&&n.trim()){c.name=n.trim();save();draw();}};
      q("[data-rsall]").onclick=function(){if(confirm("تصفير نقاط جميع طلاب "+c.name+"؟")){c.students.forEach(function(s){s.pts=0;s.log=[];});save();CS.minus();}};
      q("[data-dc]").onclick=function(){if(!confirm("حذف فصل "+c.name+" وكل بياناته نهائيًّا؟"))return;D.classes=D.classes.filter(function(x){return x.id!==c.id;});D.cur=D.classes[0]?D.classes[0].id:null;save();draw();};}
    function readB(){body.querySelectorAll("[data-bn]").forEach(function(i){var k=+i.getAttribute("data-bn");D.beh[k].n=i.value.trim()||D.beh[k].n;D.beh[k].e=body.querySelector('[data-be="'+k+'"]').value.trim()||"⭐";
      var p=parseInt(body.querySelector('[data-bp="'+k+'"]').value.replace(/[٠-٩]/g,function(d){return "٠١٢٣٤٥٦٧٨٩".indexOf(d);}),10);D.beh[k].p=isNaN(p)||p===0?1:Math.max(-10,Math.min(10,p));});}
    q("[data-bs]").onclick=function(){readB();save();CS.save();toast("تم حفظ السلوكيات");drawSet(c);};
    q("[data-ba]").onclick=function(){readB();D.beh.push({e:"⭐",n:"سلوك جديد",p:1});drawSet(c);};
    body.querySelectorAll("[data-bd]").forEach(function(b){b.onclick=function(){readB();D.beh.splice(+b.getAttribute("data-bd"),1);if(!D.beh.length)D.beh=DEFB.slice();drawSet(c);};});
    q("[data-ex]").onclick=function(){var a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(D)],{type:"application/json"}));a.download="نسخة-قسم-الطلاب-"+today()+".json";document.body.appendChild(a);a.click();a.remove();};
    q("[data-im]").onchange=function(e){var f=e.target.files[0];if(!f)return;var r=new FileReader();r.onload=function(){try{var n=JSON.parse(r.result);if(!n.classes)throw 0;
      if(!confirm("استبدال البيانات الحالية بالنسخة المستوردة؟"))return;D=n;if(!D.beh||!D.beh.length)D.beh=DEFB.slice();save();CS.save();toast("تم الاستيراد");draw();}catch(_){alert("الملف غير صالح.");}};r.readAsText(f);};}
  if(!D.cur&&D.classes[0])D.cur=D.classes[0].id;draw();
  if(window.STP)STP.ready.then(function(me){if(!me||me.role!=="teacher"||!document.body.contains(el))return;cloudOn=true;
    var tag=document.createElement("span");tag.className="cl-cloud";tag.textContent="☁️ مزامنة…";el.querySelector(".cl-top").insertBefore(tag,el.querySelector(".cl-sel"));
    STP.post("cls_load").then(function(r){if(r.data){try{var n=JSON.parse(r.data);if(n&&n.classes){D=n;if(!D.beh||!D.beh.length)D.beh=DEFB.slice();clsSave(D);draw();}}catch(e){}tag.textContent="☁️ محفوظ على حسابك";}
      else{if(D.classes.length)cloudSave();tag.textContent="☁️ محفوظ على حسابك";}}).catch(function(){tag.textContent="⚠️ بدون مزامنة";});});
}
window.CLS={open:openCLS};

/* ================= ألعاب إضافية ================= */
var G3S={hop:function(){tone([[520,0,.06,"triangle"]]);},up:function(){[0,1,2,3,4,5].forEach(function(i){tone([[400+i*90,i*.07,.1,"triangle"]]);});},
  down:function(){[0,1,2,3,4,5].forEach(function(i){tone([[700-i*80,i*.08,.12,"sawtooth"]]);});},dice:function(){for(var i=0;i<8;i++)tone([[300+Math.random()*500,i*.06,.04,"square"]]);},
  flip:function(){noise(.12,1800,900,.18);},buzzer:function(){tone([[880,0,.35,"square"],[660,0,.35,"square"]]);},place:function(){tone([[392,0,.08],[523,.06,.14]]);}};
function gxQModal(G,Q,title,secs,cb){var m=document.createElement("div");m.className="g3-qm";var L="أبجد";
  m.innerHTML='<div class="g3-qc"><div class="g3-qh"><span>'+title+'</span><b class="g3-t">'+an(secs)+'</b></div><div class="g3-qt">'+qtx(Q.q)+'</div><div class="g3-qa">'+
    Q.o.map(function(o,k){return '<button data-k="'+k+'"'+(Q.qa?' class="qa"':'')+'><b>'+L[k]+'</b><span>'+gxTxt(o,Q.qa)+'</span></button>';}).join("")+'</div></div>';
  G.el.appendChild(m);var tl=secs,done=false,t=setInterval(function(){tl--;var e=m.querySelector(".g3-t");if(e){e.textContent=an(Math.max(tl,0));e.classList.toggle("low",tl<=5);}if(tl<=5&&tl>0)GS.click();if(tl<=0)fin(-1);},1000);
  function fin(k){if(done)return;done=true;clearInterval(t);var bs=m.querySelectorAll(".g3-qa button"),ok=k>-1&&Q.o[k].ok;Q.o.forEach(function(o,j){if(o.ok)bs[j].classList.add("ok");});if(k>-1&&!ok)bs[k].classList.add("no");
    (ok?GS.ding:GS.buzz)(3);setTimeout(function(){m.remove();cb(ok);},1500);}
  m.querySelectorAll(".g3-qa button").forEach(function(b){b.onclick=function(){fin(+b.getAttribute("data-k"));};});
  var oldClose=G.onclose;G.onclose=function(){clearInterval(t);if(oldClose)oldClose();};}
function g3Teams(body,title,emoji,intro,opts,go){var names=opts.names.slice();
  body.innerHTML='<div class="gx-card"><div class="gx-emoji">'+emoji+'</div><h3>'+title+'</h3><p>'+intro+'</p><div class="gx-names g3-names">'+names.map(function(n,i){return '<label>'+["الفريق الأول","الفريق الثاني","الفريق الثالث","الفريق الرابع"][i]+'<input maxlength="16" data-n="'+i+'" value="'+esc(n)+'"></label>';}).join("")+'</div>'+
    (opts.counts?'<p><b>عدد الفرق</b></p><div class="gx-opts">'+opts.counts.map(function(c){return '<button data-c="'+c+'" class="'+(c===names.length?'on':'')+'">'+an(c)+'</button>';}).join("")+'</div>':'')+
    '<button class="gx-go" data-go>ابدأ</button></div>';
  body.querySelectorAll("[data-c]").forEach(function(b){b.onclick=function(){var c=+b.getAttribute("data-c"),all=["الفريق الأزرق","الفريق الأحمر","الفريق الأخضر","الفريق الأصفر"];
    body.querySelectorAll("[data-n]").forEach(function(i){names[+i.getAttribute("data-n")]=i.value.trim()||names[+i.getAttribute("data-n")];});
    opts.names=all.slice(0,c).map(function(d,i){return names[i]||d;});g3Teams(body,title,emoji,intro,opts,go);};});
  body.querySelector("[data-go]").onclick=function(){body.querySelectorAll("[data-n]").forEach(function(i){var v=i.value.trim();if(v)names[+i.getAttribute("data-n")]=v;});go(names);};}
var TC=["#3b82f6","#ef4444","#22c55e","#eab308"];

/* ---------- ١) إكس-أو التعليمية ---------- */
function openXO(pool,title){if(!pool||pool.length<3)return alert("لا توجد أسئلة كافية لهذه اللعبة بعد.");
  var G=gxShell("g3xo","إكس-أو التعليمية","g3-xo"),body=G.body,names,score=[0,0],board,turn,qs,qi;
  function setup(){G.stat.innerHTML="";g3Teams(body,"إكس-أو التعليمية","❌⭕",'اختر خانة، ثم أجب عن سؤالها لتضع علامتك فيها. أول فريق يكمل صفًّا أو عمودًا أو قطرًا يفوز!',{names:["فريق ❌","فريق ⭕"]},function(n){names=n;score=[0,0];round();});}
  function round(){board=Array(9).fill(-1);turn=Math.random()<.5?0:1;qs=shuffle(pool);qi=0;draw();}
  function draw(win){G.stat.innerHTML='<span style="background:'+TC[0]+'">❌ '+an(score[0])+'</span><span style="background:'+TC[1]+'">⭕ '+an(score[1])+'</span>';
    body.innerHTML='<div class="xo-turn t'+turn+'">'+(win?'':'دور: '+esc(names[turn])+' '+(turn?'⭕':'❌'))+'</div><div class="xo-board">'+board.map(function(v,i){
      return '<button class="xo-c'+(v>-1?' f'+v:'')+(win&&win.indexOf(i)>-1?' w':'')+'" data-i="'+i+'"'+(v>-1||win?' disabled':'')+'>'+(v===0?'<svg viewBox="0 0 100 100"><path d="M22 22L78 78M78 22L22 78"/></svg>':v===1?'<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="30"/></svg>':'<em>'+an(i+1)+'</em>')+'</button>';}).join("")+'</div><div class="xo-msg"></div>';
    body.querySelectorAll(".xo-c:not([disabled])").forEach(function(b){b.onclick=function(){var i=+b.getAttribute("data-i");GS.click();b.classList.add("pick");
      if(qi>=qs.length){qs=shuffle(pool);qi=0;}gxQModal(G,gxMk(qs[qi++]),esc(names[turn])+' – الخانة '+an(i+1),20,function(ok){if(ok){board[i]=turn;G3S.place();}else{msg("لم تُحتسب الخانة، ينتقل الدور.");}check();});};});}
  function msg(t){var m=body.querySelector(".xo-msg");if(m)m.textContent=t;}
  function check(){var L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]],w=null;L.forEach(function(l){if(board[l[0]]>-1&&board[l[0]]===board[l[1]]&&board[l[1]]===board[l[2]])w=l;});
    if(w){var t=board[w[0]];score[t]++;draw(w);GS.win();gxConfetti(G.el,t?["#ef4444","#fca5a5","#fff"]:["#3b82f6","#93c5fd","#fff"]);end("🏆 فاز "+esc(names[t])+"!");return;}
    if(board.every(function(v){return v>-1;})){draw([]);GS.lose();end("تعادل!");return;}turn=1-turn;draw();}
  function end(t){body.insertAdjacentHTML("beforeend",'<div class="gx-card g3-end"><h3>'+t+'</h3><button class="gx-go" data-r>جولة جديدة</button><button class="gx-go alt" data-s>تغيير الفريقين</button></div>');
    body.querySelector("[data-r]").onclick=round;body.querySelector("[data-s]").onclick=setup;}
  setup();}

/* ---------- ٢) السلّم والثعبان ---------- */
function openSNK(pool,title){if(!pool||pool.length<3)return alert("لا توجد أسئلة كافية لهذه اللعبة بعد.");
  var G=gxShell("g3snk","السلّم والثعبان","g3-snk"),body=G.body,names,pos,turn,qs,qi,busy=false,N=30,COLS=5;
  var LAD={3:11,8:16,14:24,19:27},SNK={13:5,21:9,26:17,29:20};
  function setup(){G.stat.innerHTML="";g3Teams(body,"السلّم والثعبان","🎲🐍",'ارمِ النرد، ثم أجب عن السؤال: الإجابة الصحيحة تحرّكك بعدد النرد. اصعد السلالم واحذر الثعابين! أول من يصل إلى المربع ٣٠ يفوز.',
    {names:["الفريق الأزرق","الفريق الأحمر"],counts:[2,3,4]},function(n){names=n;start();});}
  function cell(n){var r=Math.floor((n-1)/COLS),c=(n-1)%COLS;if(r%2)c=COLS-1-c;return {x:(COLS-1-c)*100+50,y:(5-r)*100+50};}
  function start(){pos=names.map(function(){return 0;});turn=0;qs=shuffle(pool);qi=0;
    var cells="";for(var n=1;n<=N;n++){var p=cell(n);cells+='<g><rect x="'+(p.x-50)+'" y="'+(p.y-50)+'" width="100" height="100" fill="'+((Math.floor((n-1)/COLS)+n)%2?'#fef3c7':'#fde68a')+'" stroke="#f59e0b" stroke-width="1.5"/>'+
      '<text x="'+(p.x+34)+'" y="'+(p.y-28)+'" font-size="20" font-weight="800" fill="#92400e" text-anchor="middle" font-family="Tajawal,sans-serif">'+an(n)+'</text></g>';}
    var p30=cell(30);cells+='<text x="'+p30.x+'" y="'+(p30.y+18)+'" font-size="40" text-anchor="middle">🏁</text>';
    var lad="";Object.keys(LAD).forEach(function(a){var p=cell(+a),q=cell(LAD[a]),dx=q.x-p.x,dy=q.y-p.y,l=Math.hypot(dx,dy),nx=-dy/l*13,ny=dx/l*13;
      lad+='<g stroke="#7c4a1e" stroke-width="7" stroke-linecap="round"><line x1="'+(p.x+nx)+'" y1="'+(p.y+ny)+'" x2="'+(q.x+nx)+'" y2="'+(q.y+ny)+'"/><line x1="'+(p.x-nx)+'" y1="'+(p.y-ny)+'" x2="'+(q.x-nx)+'" y2="'+(q.y-ny)+'"/>';
      for(var k=1;k<Math.floor(l/26);k++){var t=k*26/l;lad+='<line x1="'+(p.x+nx+dx*t)+'" y1="'+(p.y+ny+dy*t)+'" x2="'+(p.x-nx+dx*t)+'" y2="'+(p.y-ny+dy*t)+'" stroke-width="5"/>';}lad+='</g>';});
    var snk="";Object.keys(SNK).forEach(function(a,i){var p=cell(+a),q=cell(SNK[a]),mx=(p.x+q.x)/2+(i%2?60:-60),my=(p.y+q.y)/2,c=["#16a34a","#9333ea","#dc2626","#0891b2"][i%4];
      snk+='<path d="M'+p.x+' '+p.y+' Q'+mx+' '+my+' '+q.x+' '+q.y+'" stroke="'+c+'" stroke-width="16" fill="none" stroke-linecap="round" opacity=".9"/><path d="M'+p.x+' '+p.y+' Q'+mx+' '+my+' '+q.x+' '+q.y+'" stroke="#fff" stroke-width="3" stroke-dasharray="4 14" fill="none" opacity=".7"/>'+
        '<circle cx="'+p.x+'" cy="'+p.y+'" r="14" fill="'+c+'"/><circle cx="'+(p.x-5)+'" cy="'+(p.y-4)+'" r="3" fill="#fff"/><circle cx="'+(p.x+5)+'" cy="'+(p.y-4)+'" r="3" fill="#fff"/>';});
    body.innerHTML='<div class="sn-wrap"><div class="sn-board"><svg viewBox="0 0 500 670">'+cells+lad+snk+'<g class="sn-tok"></g></svg></div><div class="sn-side"><div class="sn-pl"></div>'+
      '<div class="sn-dice"><div class="sn-d">🎲</div><button class="gx-go" data-roll>ارمِ النرد</button></div><div class="sn-msg"></div></div></div>';
    body.querySelector("[data-roll]").onclick=roll;draw();}
  function draw(){var tk="";pos.forEach(function(v,i){var p=v?cell(v):{x:-60+0,y:560};if(!v)p={x:465-i*40,y:635};var o=[[-18,-18],[18,-18],[-18,18],[18,18]][i];
      tk+='<g transform="translate('+(p.x+(v?o[0]:0))+' '+(p.y+(v?o[1]:0))+')" class="sn-t'+(i===turn?' now':'')+'"><circle r="16" fill="'+TC[i]+'" stroke="#fff" stroke-width="4"/><text y="6" font-size="16" font-weight="800" fill="#fff" text-anchor="middle">'+an(i+1)+'</text></g>';});
    body.querySelector(".sn-tok").innerHTML=tk;
    body.querySelector(".sn-pl").innerHTML=names.map(function(n,i){return '<div class="'+(i===turn?'now':'')+'" style="--c:'+TC[i]+'"><i>'+an(i+1)+'</i><span>'+esc(n)+'</span><b>'+an(pos[i])+'</b></div>';}).join("");
    G.stat.innerHTML='<span style="background:'+TC[turn]+'">دور: '+esc(names[turn])+'</span>';}
  function msg(t){body.querySelector(".sn-msg").textContent=t;}
  function roll(){if(busy)return;busy=true;var d=body.querySelector(".sn-d"),n=1+Math.floor(Math.random()*6),k=0;G3S.dice();body.querySelector("[data-roll]").disabled=true;
    var F=["⚀","⚁","⚂","⚃","⚄","⚅"],iv=setInterval(function(){d.textContent=F[Math.floor(Math.random()*6)];d.classList.toggle("sp");if(++k>9){clearInterval(iv);d.textContent=F[n-1];msg("النرد: "+an(n)+" — أجب عن السؤال لتتحرك");
      if(qi>=qs.length){qs=shuffle(pool);qi=0;}setTimeout(function(){gxQModal(G,gxMk(qs[qi++]),esc(names[turn])+' • النرد '+an(n),25,function(ok){if(ok)move(n);else{msg("إجابة غير صحيحة، يبقى الفريق مكانه.");next();}});},500);}},80);}
  function move(n){var t=Math.min(N,pos[turn]+n),step=function(){if(pos[turn]<t){pos[turn]++;G3S.hop();draw();setTimeout(step,260);}else after();};step();}
  function after(){var p=pos[turn];if(LAD[p]){msg("سلّم! 🪜 صعود إلى "+an(LAD[p]));G3S.up();setTimeout(function(){pos[turn]=LAD[p];draw();check();},700);}
    else if(SNK[p]){msg("ثعبان! 🐍 نزول إلى "+an(SNK[p]));G3S.down();setTimeout(function(){pos[turn]=SNK[p];draw();check();},700);}else check();}
  function check(){if(pos[turn]>=N){GS.win();gxConfetti(G.el,[TC[turn],"#ffd76a","#fff"]);body.querySelector(".sn-dice").innerHTML='<div class="gx-card g3-end"><h3>🏆 فاز '+esc(names[turn])+'!</h3><button class="gx-go" data-r>جولة جديدة</button><button class="gx-go alt" data-s>تغيير الفرق</button></div>';
      body.querySelector("[data-r]").onclick=start;body.querySelector("[data-s]").onclick=setup;return;}next();}
  function next(){setTimeout(function(){turn=(turn+1)%names.length;busy=false;var b=body.querySelector("[data-roll]");if(b)b.disabled=false;draw();G3S.place();},900);}
  setup();}

/* ---------- ٣) بطاقات الذاكرة ---------- */
function openMEM(pool,title){var src=[];
  (pool.cards||[]).forEach(function(c){if(c.f.length<=40&&c.b.length<=70)src.push({a:c.f,b:c.b});});
  if(src.length<4)pool.forEach(function(q){var r=q.c[q.a];if(q.q.length<=70&&r.length<=45&&!q.qa)src.push({a:q.q.replace(/[:：]\s*$/,""),b:r});});
  if(src.length<3)return alert("لا توجد بطاقات كافية لهذه اللعبة بعد.");
  var G=gxShell("g3mem","بطاقات الذاكرة","g3-mem"),body=G.body,cards,open=[],moves,matched,t0,timer=null,np=6;
  G.onclose=function(){clearInterval(timer);};
  function intro(){G.stat.innerHTML="";body.innerHTML='<div class="gx-card"><div class="gx-emoji">🃏</div><h3>بطاقات الذاكرة</h3><p>'+esc(title||"")+'</p><p>اقلب بطاقتين في كل مرة، وطابق كل مفهوم أو سؤال (أزرق) مع معناه أو إجابته (برتقالي) بأقل عدد من المحاولات!</p>'+
    '<p><b>عدد الأزواج</b></p><div class="gx-opts">'+[4,6,8].filter(function(n){return n<=src.length||n===4;}).map(function(n){return '<button data-p="'+n+'" class="'+(n===Math.min(np,src.length)?'on':'')+'">'+an(Math.min(n,src.length))+'</button>';}).join("")+'</div><button class="gx-go" data-go>ابدأ</button></div>';
    body.querySelectorAll("[data-p]").forEach(function(b){b.onclick=function(){np=+b.getAttribute("data-p");body.querySelectorAll("[data-p]").forEach(function(x){x.classList.toggle("on",x===b);});};});
    body.querySelector("[data-go]").onclick=start;}
  function start(){var ps=shuffle(src).slice(0,Math.min(np,src.length));cards=shuffle([].concat.apply([],ps.map(function(p,i){return [{id:i,t:p.a,k:"a"},{id:i,t:p.b,k:"b"}];})));open=[];moves=0;matched=0;t0=Date.now();
    body.innerHTML='<div class="mem-grid n'+cards.length+'">'+cards.map(function(c,i){return '<button class="mem-c" data-i="'+i+'"><span class="mem-in"><span class="mem-f">؟</span><span class="mem-b '+c.k+'">'+qtx(c.t)+'</span></span></button>';}).join("")+'</div>';
    body.querySelectorAll(".mem-c").forEach(function(b){b.onclick=function(){flip(+b.getAttribute("data-i"),b);};});
    clearInterval(timer);timer=setInterval(stat,1000);stat();}
  function stat(){var s=Math.floor((Date.now()-t0)/1000);G.stat.innerHTML='<span>⏱ '+an(Math.floor(s/60))+':'+an(String(s%60).padStart(2,"0"))+'</span><span>🔁 '+an(moves)+'</span>';}
  function flip(i,b){if(open.length>=2||b.classList.contains("on")||b.classList.contains("ok"))return;b.classList.add("on");G3S.flip();open.push([i,b]);
    if(open.length===2){moves++;stat();var A=cards[open[0][0]],B=cards[open[1][0]];
      if(A.id===B.id&&A.k!==B.k){setTimeout(function(){open.forEach(function(x){x[1].classList.add("ok");});open=[];matched++;GS.ding(matched);if(matched*2===cards.length)win();},450);}
      else setTimeout(function(){open.forEach(function(x){x[1].classList.remove("on");x[1].classList.add("nope");setTimeout(function(){x[1].classList.remove("nope");},400);});open=[];GS.buzz();},1000);}}
  function win(){clearInterval(timer);var s=Math.floor((Date.now()-t0)/1000),pairs=cards.length/2,st=moves<=pairs+2?3:moves<=pairs*2?2:1,b=gxBest("mem:"+pairs,1000-moves);GS.win();gxConfetti(G.el);
    setTimeout(function(){body.innerHTML='<div class="gx-card"><div class="gx-emoji">'+"⭐".repeat(st)+'</div><h3>أحسنت! طابقت جميع البطاقات</h3><p class="gx-big">'+an(moves)+' محاولة</p><p>الوقت: '+an(s)+' ثانية'+(b.rec?' • رقم قياسي جديد!':'')+'</p>'+
      '<button class="gx-go" data-go>العب مرة أخرى</button><button class="gx-go alt" data-x>رجوع</button></div>';body.querySelector("[data-go]").onclick=start;body.querySelector("[data-x]").onclick=G.close;},800);}
  intro();}

/* ---------- ٤) الكلمات المبعثرة ---------- */
function stripAr(s){return String(s).replace(/[\u064B-\u0652\u0670\u0640]/g,"").replace(/[«»().،:؛!؟]/g,"").trim();}
function openSCR(pool,title){var src=[],seen={};
  function add(w,p){w=stripAr(w);if(!w||seen[w])return;var L=w.replace(/\s/g,"").length;if(L<3||L>12||w.split(/\s+/).length>2)return;seen[w]=1;src.push({w:w,p:p});}
  (pool.cards||[]).forEach(function(c){add(c.f,c.b);if(stripAr(c.b).length<=12)add(c.b,"معنى: "+c.f);});
  pool.forEach(function(q){if(!q.qa)add(q.c[q.a],q.q);});
  if(src.length<3)return alert("لا توجد كلمات كافية لهذه اللعبة بعد.");
  var G=gxShell("g3scr","الكلمات المبعثرة","g3-scr"),body=G.body,list,idx,score,cur,slots,hints;
  function intro(){G.stat.innerHTML="";body.innerHTML='<div class="gx-card"><div class="gx-emoji">🔤</div><h3>الكلمات المبعثرة</h3><p>'+esc(title||"")+'</p><p>اقرأ التلميح، ثم رتّب الحروف المبعثرة لتكوّن الكلمة الصحيحة. اضغط على الحرف لوضعه، واضغط على الخانة لإرجاعه.</p><button class="gx-go" data-go>ابدأ</button></div>';
    body.querySelector("[data-go]").onclick=function(){list=shuffle(src).slice(0,8);idx=0;score=0;word();};}
  function word(){if(idx>=list.length)return over();cur=list[idx];hints=0;var letters=Array.from(cur.w.replace(/\s/g,"")),sh=shuffle(letters.map(function(l,i){return {l:l,i:i};}));
    if(sh.map(function(x){return x.l;}).join("")===letters.join("")&&letters.length>1)sh.reverse();slots=letters.map(function(){return null;});
    var words=cur.w.split(/\s+/),k=0,slotHtml=words.map(function(w){return '<div class="scr-word">'+Array.from(w).map(function(){return '<button class="scr-s" data-s="'+(k++)+'"></button>';}).join("")+'</div>';}).join("");
    G.stat.innerHTML='<span>'+an(idx+1)+' / '+an(list.length)+'</span><span>⭐ '+an(score)+'</span>';
    body.innerHTML='<div class="scr-hint"><small>التلميح</small>'+qtx(cur.p)+'</div><div class="scr-slots">'+slotHtml+'</div><div class="scr-tiles">'+sh.map(function(x,j){return '<button class="scr-t" data-j="'+j+'" data-l="'+esc(x.l)+'">'+esc(x.l)+'</button>';}).join("")+'</div>'+
      '<div class="scr-act"><button class="gx-go alt" data-h>💡 تلميح</button><button class="gx-go alt" data-sk>تخطّي</button></div><div class="scr-msg"></div>';
    body.querySelectorAll(".scr-t").forEach(function(t){t.onclick=function(){var e=slots.indexOf(null);if(e<0||t.classList.contains("used"))return;slots[e]=t;t.classList.add("used");GS.click();paint();test();};});
    body.querySelectorAll(".scr-s").forEach(function(s){s.onclick=function(){var i=+s.getAttribute("data-s");if(!slots[i]||slots[i].lock)return;slots[i].classList.remove("used");slots[i]=null;GS.click();paint();};});
    body.querySelector("[data-h]").onclick=function(){var letters=Array.from(cur.w.replace(/\s/g,""));for(var i=0;i<letters.length;i++){if(!slots[i]||slots[i].getAttribute("data-l")!==letters[i]){
        if(slots[i]){slots[i].classList.remove("used");slots[i]=null;}var t=[].slice.call(body.querySelectorAll(".scr-t:not(.used)")).filter(function(x){return x.getAttribute("data-l")===letters[i];})[0];
        if(!t){var o=slots.indexOf(slots.filter(function(x){return x&&!x.lock&&x.getAttribute("data-l")===letters[i];})[0]);if(o>-1){t=slots[o];slots[o]=null;}}
        if(t){t.classList.add("used");t.lock=true;slots[i]=t;hints++;G3S.place();}break;}}paint();test();};
    body.querySelector("[data-sk]").onclick=function(){reveal(false);};}
  function paint(){body.querySelectorAll(".scr-s").forEach(function(s,i){s.textContent=slots[i]?slots[i].getAttribute("data-l"):"";s.classList.toggle("f",!!slots[i]);s.classList.toggle("lk",!!(slots[i]&&slots[i].lock));});}
  function test(){if(slots.indexOf(null)>-1)return;var g=slots.map(function(t){return t.getAttribute("data-l");}).join(""),w=cur.w.replace(/\s/g,"");
    if(g===w){var pts=Math.max(2,10-hints*3);score+=pts;GS.win();body.querySelector(".scr-slots").classList.add("good");body.querySelector(".scr-msg").textContent="أحسنت! +"+an(pts);setTimeout(function(){idx++;word();},1300);}
    else{GS.buzz();var sl=body.querySelector(".scr-slots");sl.classList.remove("bad");void sl.offsetWidth;sl.classList.add("bad");}}
  function reveal(){var w=Array.from(cur.w.replace(/\s/g,""));body.querySelectorAll(".scr-s").forEach(function(s,i){s.textContent=w[i];s.classList.add("f","lk");});GS.lose();body.querySelector(".scr-msg").textContent="الكلمة: "+cur.w;setTimeout(function(){idx++;word();},1600);}
  function over(){var b=gxBest("scr:best",score);if(score>0)gxConfetti(G.el);GS.win();body.innerHTML='<div class="gx-card"><div class="gx-emoji">🏅</div><h3>انتهت الكلمات!</h3><p class="gx-big">'+an(score)+' نقطة</p><p>'+(b.rec&&score>0?'رقم قياسي جديد!':'أفضل نتيجة: '+an(b.best))+'</p>'+
    '<button class="gx-go" data-go>العب مرة أخرى</button><button class="gx-go alt" data-x>رجوع</button></div>';body.querySelector("[data-go]").onclick=function(){list=shuffle(src).slice(0,8);idx=0;score=0;word();};body.querySelector("[data-x]").onclick=G.close;}
  intro();}

/* ---------- ٥) الجرس السريع (فريقان على شاشة واحدة) ---------- */
function openBUZ(pool,title){if(!pool||pool.length<3)return alert("لا توجد أسئلة كافية لهذه اللعبة بعد.");
  var G=gxShell("g3buz","الجرس السريع","g3-buz"),body=G.body,names,sc,qs,qi,state,lockT=[0,0],rounds=10,rn,tmr=null,first;
  G.onclose=function(){clearTimeout(tmr);document.removeEventListener("keydown",kd);};
  function kd(e){if(!body.querySelector(".bz-pads"))return;var k=e.key.toLowerCase();if(k==="l"||k==="arrowright")press(0);if(k==="a"||k==="arrowleft")press(1);}
  document.addEventListener("keydown",kd);
  function setup(){G.stat.innerHTML="";g3Teams(body,"الجرس السريع","🔔",'يظهر السؤال، ثم يُفتح الجرس: أول فريق يضغط جرسه يجيب. الإجابة الصحيحة نقطة، والخاطئة تمنح الفريق الآخر فرصة. الضغط قبل فتح الجرس يوقف الفريق ثانيتين! (لوحة المفاتيح: L للفريق الأول، A للثاني)',
    {names:["الفريق الأزرق","الفريق الأحمر"]},function(n){names=n;sc=[0,0];qs=shuffle(pool);qi=0;rn=0;round();});}
  function stat(){G.stat.innerHTML='<span style="background:'+TC[0]+'">'+esc(names[0])+' '+an(sc[0])+'</span><span style="background:'+TC[1]+'">'+esc(names[1])+' '+an(sc[1])+'</span>';}
  function round(){if(rn>=rounds)return end();rn++;if(qi>=qs.length){qs=shuffle(pool);qi=0;}var Q=gxMk(qs[qi++]);state="wait";first=-1;stat();
    body.innerHTML='<div class="bz-top"><span>السؤال '+an(rn)+' من '+an(rounds)+'</span></div><div class="bz-q">'+qtx(Q.q)+'</div><div class="bz-st">استعدّوا…</div>'+
      '<div class="bz-pads">'+[0,1].map(function(i){return '<button class="bz-p t'+i+'" data-t="'+i+'"><span class="bz-bell">🔔</span><b>'+esc(names[i])+'</b><small>'+(i?'A':'L')+'</small></button>';}).join("")+'</div><div class="bz-ans"></div>';
    body.querySelectorAll(".bz-p").forEach(function(b){b.onpointerdown=function(e){e.preventDefault();press(+b.getAttribute("data-t"));};});
    body.Q=Q;tmr=setTimeout(function(){if(state!=="wait")return;state="open";var s=body.querySelector(".bz-st");s.textContent="اضغطوا الآن! 🔔";s.classList.add("go");body.querySelector(".bz-pads").classList.add("open");tone([[1200,0,.12,"square"]]);},1800+Math.random()*1800);}
  function press(t){if(Date.now()<lockT[t])return;if(state==="wait"){lockT[t]=Date.now()+2000;GS.buzz();var p=body.querySelector(".bz-p.t"+t);p.classList.add("lock");setTimeout(function(){p.classList.remove("lock");},2000);return;}
    if(state!=="open"||t===first)return;state="ans";first=first<0?t:first;G3S.buzzer();var p2=body.querySelector(".bz-p.t"+t);p2.classList.add("win");body.querySelector(".bz-pads").classList.remove("open");ask(t);}
  function ask(t){var Q=body.Q,L="أبجد",a=body.querySelector(".bz-ans"),st=body.querySelector(".bz-st");st.textContent="يجيب: "+names[t];st.className="bz-st t"+t;
    a.innerHTML='<div class="bz-ch">'+Q.o.map(function(o,k){return '<button data-k="'+k+'"'+(Q.qa?' class="qa"':'')+'><b>'+L[k]+'</b><span>'+gxTxt(o,Q.qa)+'</span></button>';}).join("")+'</div>';
    var tl=10,iv=setInterval(function(){tl--;if(tl<=3&&tl>0)GS.click();if(tl<=0){clearInterval(iv);res(-1);}},1000);
    a.querySelectorAll("button").forEach(function(b){b.onclick=function(){clearInterval(iv);res(+b.getAttribute("data-k"));};});
    function res(k){var bs=a.querySelectorAll("button"),ok=k>-1&&Q.o[k].ok;a.querySelectorAll("button").forEach(function(x){x.disabled=true;});if(k>-1)bs[k].classList.add(ok?"ok":"no");
      if(ok){sc[t]++;GS.win();st.textContent="✔ نقطة لـ "+names[t];stat();setTimeout(round,1600);}
      else{GS.buzz();var o=1-t;if(first===t&&state==="ans"&&!a.dataset.second){a.dataset.second=1;st.textContent="✘ فرصة لـ "+names[o]+"!";setTimeout(function(){state="ans";ask(o);},1100);}
        else{Q.o.forEach(function(x,j){if(x.ok)bs[j].classList.add("ok");});st.textContent="لا نقاط في هذا السؤال";setTimeout(round,1800);}}}}
  function end(){var w=sc[0]===sc[1]?-1:sc[0]>sc[1]?0:1;GS.win();gxConfetti(G.el);body.innerHTML='<div class="gx-card"><div class="gx-emoji">🏆</div><h3>'+(w<0?'تعادل!':'فاز '+esc(names[w])+'!')+'</h3><p class="gx-big">'+an(sc[0])+' — '+an(sc[1])+'</p>'+
    '<button class="gx-go" data-r>جولة جديدة</button><button class="gx-go alt" data-s>تغيير الفريقين</button></div>';body.querySelector("[data-r]").onclick=function(){sc=[0,0];rn=0;qs=shuffle(pool);qi=0;round();};body.querySelector("[data-s]").onclick=setup;}
  setup();}
window.G3={xo:openXO,snk:openSNK,mem:openMEM,scr:openSCR,buz:openBUZ};

/* ================= الشرح المبسّط للآيات والأبيات ================= */
function openSH(groups,lessonName){if(!groups||!groups.length)return;
  var el=document.createElement("div");el.id="sh";el.setAttribute("role","dialog");el.setAttribute("aria-label","الشرح");var fs=1;try{fs=+localStorage.getItem("sh:fs")||1;}catch(e){}
  el.innerHTML='<div class="sh-top"><button class="sh-ib" data-a="x" aria-label="إغلاق">'+ico("x")+'</button><div class="sh-ttl">الشرح المبسّط</div>'+
    '<span class="sh-zm"><button class="sh-ib" data-a="zm" aria-label="تصغير الخط" title="تصغير الخط">أ−</button><b class="sh-zv">100%</b><button class="sh-ib" data-a="zp" aria-label="تكبير الخط" title="تكبير الخط">أ+</button></span>'+'<button class="sh-ib sh-flb" data-a="fl" aria-label="نافذة عائمة أو ملء الشاشة" title="نافذة عائمة / ملء الشاشة">⧉</button><button class="sh-ib sh-afs" data-a="f" aria-label="إعدادات خط الشرح" title="حجم خط الشرح ونوعه"><span style="font-size:19px;line-height:1">أ<span style="font-size:.6em">أ</span></span><small>الخط</small></button><button class="sh-ib sh-all" data-a="all">إظهار الكل</button>'+(/^#\/arabic(\/|$)/.test(location.hash)&&window.TSK?'<button class="sh-ib'+(TSK.off()?' on':'')+'" data-a="tsk" title="إظهار التشكيل أو إخفاؤه">ـَـ تشكيل</button>':'')+'</div>'+
    '<div class="sh-body"><p class="sh-hint">اضغط على '+(groups.every(function(g){return g.kind==="prose";})?'الفقرة ليظهر توضيح معناها':groups.every(function(g){return g.kind==="quran";})?'الآية ليظهر تفسيرها':'الآية أو البيت ليظهر شرحه')+'</p>'+groups.map(function(g,gi){
      return '<section class="sh-g '+g.kind+'"><h3><span>'+(g.kind==="poem"?"📜":g.kind==="prose"?"📝":"📖")+'</span>'+esc(g.title)+'</h3>'+g.items.map(function(it,i){
        var num=g.kind==="poem"||g.kind==="prose",lbl=g.kind==="quran"?"التفسير":g.kind==="prose"?"المعنى":"الشرح";
        var txt=g.kind==="poem"?'<span class="sh-bayt"><span>'+esc(it.s[0])+'</span><span>'+esc(it.s[1])+'</span></span>':g.kind==="prose"?'<span class="sh-par">'+esc(it.p)+'</span>':'<span class="sh-txt">'+esc(it.t)+' <b class="sh-n">﴿'+an(it.n)+'﴾</b></span>';
        return '<div class="sh-it" style="--d:'+(i*.04)+'s"><button class="sh-h" aria-expanded="false">'+(num?'<i class="sh-num">'+an(i+1)+'</i>':'')+txt+'<em class="sh-ar">⌄</em></button>'+
          '<div class="sh-c"><div class="sh-ci"><p class="sh-exp'+(it.e?'':' sh-none')+'">'+(it.e?'<b>'+lbl+':</b> '+esc(it.e):'لا يوجد شرح مسجّل لهذا المقطع.')+'</p>'+(it.w&&it.w.length?'<div class="sh-w">'+it.w.map(function(w){return '<span><b>'+esc(w[0])+'</b>: '+esc(w[1])+'</span>';}).join("")+'</div>':'')+'</div></div></div>';}).join("")+'</section>';}).join("")+'</div>';
  document.body.appendChild(el);lock(true);var body=el.querySelector(".sh-body");body.style.setProperty("--fs",fs);
  var AP=null,afs=null;if(window.AFSET){AP=AFSET.panel(el,el.querySelector(".sh-afs"));fs=1;body.style.setProperty("--fs",1);
    afs=function(){AFSET.applyTo(body);setTimeout(function(){body.querySelectorAll(".sh-it.open").forEach(function(it){toggle(it,true,1);});},60);};AFSET.on(afs);}
  /* نافذة عائمة: تُسحب من شريطها العلوي، ويُغيَّر حجمها من الزاوية، ويُكبَّر الخط أو يُصغَّر — وتُحفظ الإعدادات */
  var SW=(function(){var K="sh:win",w={};try{w=JSON.parse(localStorage.getItem(K)||"{}")||{};}catch(e){}w.fl=true;
    function sv(){try{localStorage.setItem(K,JSON.stringify(w));}catch(e){}}
    var grip=document.createElement("div");grip.className="sh-grip";grip.title="اسحب لتغيير حجم النافذة";grip.dataset.d="sw";el.appendChild(grip);
    if(!document.getElementById("sh-rzcss")){var cs=document.createElement("style");cs.id="sh-rzcss";cs.textContent="#sh .sh-rz{display:none}#sh.shf .sh-rz{display:block;position:absolute;z-index:4;touch-action:none}#sh.shf .sh-rz-n{top:0;left:18px;right:18px;height:9px;cursor:ns-resize}#sh.shf .sh-rz-s{bottom:0;left:26px;right:18px;height:9px;cursor:ns-resize}#sh.shf .sh-rz-e{right:0;top:18px;bottom:18px;width:9px;cursor:ew-resize}#sh.shf .sh-rz-w{left:0;top:18px;bottom:26px;width:9px;cursor:ew-resize}#sh.shf .sh-rz-ne{top:0;right:0;width:18px;height:18px;cursor:nesw-resize}#sh.shf .sh-rz-nw{top:0;left:0;width:18px;height:18px;cursor:nwse-resize}#sh.shf .sh-rz-se{bottom:0;right:0;width:18px;height:18px;cursor:nwse-resize}#sh .sh-mv{display:none}#sh.shf .sh-mv{display:inline-flex;align-items:center;justify-content:center;font-size:20px;color:#b45309;padding:0 4px;cursor:move;user-select:none}@media (pointer:coarse){#sh.shf .sh-rz-n,#sh.shf .sh-rz-s{height:16px}#sh.shf .sh-rz-e,#sh.shf .sh-rz-w{width:16px}}";document.head.appendChild(cs);}
    var rzs=[grip];["n","s","e","w","ne","nw","se"].forEach(function(d){var h=document.createElement("div");h.className="sh-rz sh-rz-"+d;h.dataset.d=d;h.title="اسحب لتغيير حجم النافذة";el.appendChild(h);rzs.push(h);});
    var mvh=document.createElement("span");mvh.className="sh-mv";mvh.title="اسحب لتحريك النافذة";mvh.textContent="✥";el.querySelector(".sh-top").insertBefore(mvh,el.querySelector(".sh-ttl"));
    function zf(v){v=Math.max(.6,Math.min(2.6,Math.round(v*10)/10));w.zf=v;body.style.setProperty("--fs",v);el.querySelector(".sh-zv").textContent=Math.round(v*100)+"%";}
    function clamp(){if(!w.fl)return;var vw=innerWidth,vh=innerHeight;
      w.w=Math.max(300,Math.min(vw-8,w.w||Math.min(620,vw*.94)));w.h=Math.max(220,Math.min(vh-8,w.h||Math.min(vh*.8,780)));
      if(w.x==null)w.x=vw-w.w-16;if(w.y==null)w.y=Math.max(8,(vh-w.h)/2);
      w.x=Math.max(4-w.w+120,Math.min(vw-120,w.x));w.y=Math.max(4,Math.min(vh-60,w.y));
      el.style.left=w.x+"px";el.style.top=w.y+"px";el.style.width=w.w+"px";el.style.height=w.h+"px";}
    function mode(){el.classList.toggle("shf",!!w.fl);el.querySelector(".sh-flb").classList.toggle("on",!w.fl);
      if(w.fl)clamp();else{el.style.left=el.style.top=el.style.width=el.style.height="";}lock(!w.fl);}
    var top=el.querySelector(".sh-top"),dr=null;
    top.addEventListener("pointerdown",function(e){if(!w.fl||e.button>0||e.target.closest("button,input,.afs-set"))return;dr={k:"m",sx:e.clientX,sy:e.clientY,x:w.x,y:w.y};top.setPointerCapture(e.pointerId);e.preventDefault();});
    rzs.forEach(function(g){g.addEventListener("pointerdown",function(e){if(!w.fl)return;dr={k:"r",d:g.dataset.d,sx:e.clientX,sy:e.clientY,w:w.w,h:w.h,x:w.x,y:w.y};g.setPointerCapture(e.pointerId);e.preventDefault();e.stopPropagation();});});
    function mv(e){if(!dr)return;var dx=e.clientX-dr.sx,dy=e.clientY-dr.sy;
      if(dr.k==="m"){w.x=dr.x+dx;w.y=dr.y+dy;}else{var d=dr.d||"sw",W=dr.w,H=dr.h,X=dr.x,Y=dr.y;if(d.indexOf("e")>=0)W=dr.w+dx;if(d.indexOf("w")>=0){W=dr.w-dx;X=dr.x+dx;}if(d.indexOf("s")>=0)H=dr.h+dy;if(d.indexOf("n")>=0){H=dr.h-dy;Y=dr.y+dy;}if(W<300){if(d.indexOf("w")>=0)X-=300-W;W=300;}if(H<220){if(d.indexOf("n")>=0)Y-=220-H;H=220;}w.w=W;w.h=H;w.x=X;w.y=Y;}clamp();}
    function up(){if(dr){dr=null;sv();}}
    [top].concat(rzs).forEach(function(n){n.addEventListener("pointermove",mv);n.addEventListener("pointerup",up);n.addEventListener("pointercancel",up);});
    top.addEventListener("dblclick",function(e){if(e.target.closest("button"))return;w.fl=!w.fl;mode();sv();});
    function rz(){if(w.fl)clamp();}window.addEventListener("resize",rz);
    zf(+w.zf||1);mode();
    return {act:function(a){if(a==="zp"){zf((w.zf||1)+.1);sv();return true;}if(a==="zm"){zf((w.zf||1)-.1);sv();return true;}if(a==="fl"){w.fl=!w.fl;mode();sv();return true;}return false;},
      off:function(){window.removeEventListener("resize",rz);}};})();
  function close(){if(afs)AFSET.off(afs);SW.off();el.remove();lock(false);document.removeEventListener("keydown",kd);}function kd(e){if(e.key==="Escape"){if(AP&&!AP.el.hidden)return AP.show(false);close();}}document.addEventListener("keydown",kd);
  function toggle(it,on,quiet){var c=it.querySelector(".sh-c"),open=on===undefined?!it.classList.contains("open"):on;it.classList.toggle("open",open);it.querySelector(".sh-h").setAttribute("aria-expanded",open);
    c.style.maxHeight=open?c.firstChild.scrollHeight+40+"px":"0";if(!quiet)tone(open?[[660,0,.06,"triangle"],[880,.05,.1,"triangle"]]:[[520,0,.06,"triangle"]]);}
  body.querySelectorAll(".sh-it").forEach(function(it){it.querySelector(".sh-h").onclick=function(){toggle(it);if(it.classList.contains("open"))setTimeout(function(){var r=it.getBoundingClientRect(),br=body.getBoundingClientRect();if(r.bottom>br.bottom)body.scrollBy({top:r.bottom-br.bottom+16,behavior:"smooth"});},320);};});
  el.querySelector(".sh-top").onclick=function(e){var b=e.target.closest("[data-a]");if(!b)return;var a=b.getAttribute("data-a");if(a==="x")return close();if(SW.act(a))return;
    if(a==="f"&&AP){e.stopPropagation();AP.toggle();}
    if(a==="tsk"&&window.TSK){TSK.toggle();b.classList.toggle("on",TSK.off());}
    if(a==="all"){var all=b.classList.toggle("on");b.textContent=all?"إخفاء الكل":"إظهار الكل";body.querySelectorAll(".sh-it").forEach(function(it){toggle(it,all,1);});tone([[700,0,.08,"triangle"]]);}};
}
window.SHARH={open:openSH};

/* ================= أدوات الصفوف الصغيرة: النطق، الحروف التفاعلية، أمرّر القلم ================= */
var _arVoice=null;
/*KAUD*/var KAUD={"أَنا حَمَدٌ، عُمْري سِتَّةُ أَعْوامٍ، الْقِراءَةُ هِوايَتِيَ الْمُفَضَّلَةُ. أَنا أَمَلُ، أَدْرُسُ في الصَّفِّ الْأَوَّلِ، وَأُحِبُّ وَطَني كَثيرًا.":"000.mp3","ذَهَبَ إِبْراهيمُ مَعَ أُسْرَتِهِ إِلى حَديقَةِ الْحَيَوانِ، شاهَدَ أَسَدًا وَإِوَزَّةً وَأَرانِبَ لَطيفَةً.":"001.mp3","حَرْفُ الألف ما أَحْلاهُ، بِالْحَرَكاتِ زَيَّنّاهُ، فَتْحَةُ أَ، ضَمَّةُ أُ، كَسْرَةُ إِ، بِالْحَرَكاتِ أَنْشَدْناهُ":"002.mp3","يَمْتَلِكُ باسِلٌ بُسْتانًا كَبيرًا، زَرَعَ فيهِ بَصَلًا وَبُرْتُقالًا وَبِطّيخًا.":"003.mp3","حَرْفُ الباء ما أَحْلاهُ، بِالْحَرَكاتِ زَيَّنّاهُ، فَتْحَةُ بَ، ضَمَّةُ بُ، كَسْرَةُ بِ، بِالْحَرَكاتِ أَنْشَدْناهُ":"004.mp3","تَسْنيمُ تُحِبُّ الرَّسْمَ، رَسَمَتْ مَعَ أُخْتِها تُفّاحَةً وَتِمْساحًا وَتاجَ مَلِكٍ.":"005.mp3","حَرْفُ التاء ما أَحْلاهُ، بِالْحَرَكاتِ زَيَّنّاهُ، فَتْحَةُ تَ، ضَمَّةُ تُ، كَسْرَةُ تِ، بِالْحَرَكاتِ أَنْشَدْناهُ":"006.mp3","اشْتَرَتْ ثُرَيّا ثَوْبًا جَديدًا لِلْعيدِ، وَثَلاثَ هَدايا ثَمينَةً لِإِخْوَتِها ثامِرٍ وَلَيْثٍ وَعُثْمانَ.":"007.mp3","حَرْفُ الثاء ما أَحْلاهُ، بِالْحَرَكاتِ زَيَّنّاهُ، فَتْحَةُ ثَ، ضَمَّةُ ثُ، كَسْرَةُ ثِ، بِالْحَرَكاتِ أَنْشَدْناهُ":"008.mp3","في يَوْمِ الْجُمُعَةِ، خَبَزَتْ جِنانُ لِجَدَّتِها كَعْكَةَ الْجَزَرِ الْمُزَيَّنَةَ بِالْجَوْزِ، شَكَرَتِ الْجَدَّةُ جِنانَ وَأَهْدَتْها جَوْهَرَةً جَميلَةً.":"009.mp3","حَرْفُ الجيم ما أَحْلاهُ، بِالْحَرَكاتِ زَيَّنّاهُ، فَتْحَةُ جَ، ضَمَّةُ جُ، كَسْرَةُ جِ، بِالْحَرَكاتِ أَنْشَدْناهُ":"010.mp3","يَمْلِكُ حَسَنٌ حَقْلَ قَمْحٍ، وَلَدَيْهِ حَظيرَةُ حَيَواناتٍ، فيها حِصانٌ وَحَمامٌ.":"011.mp3","حَرْفُ الحاء ما أَحْلاهُ، بِالْحَرَكاتِ زَيَّنّاهُ، فَتْحَةُ حَ، ضَمَّةُ حُ، كَسْرَةُ حِ، بِالْحَرَكاتِ أَنْشَدْناهُ":"012.mp3","مُنَبِّه":"013.mp3","هاتِف":"014.mp3","سَيّارَة":"015.mp3","عُصْفور":"016.mp3","حِصان":"017.mp3","أَسَد":"018.mp3","فَرَح":"019.mp3","غَضَب":"020.mp3","حُزْن":"021.mp3","الطَّبيب":"022.mp3","الشُّرْطِيّ":"023.mp3","الْمُعَلِّمَة":"024.mp3","الْعامِل":"025.mp3","الْمُزارِع":"026.mp3","الْأُمّ":"027.mp3","قَلَم":"028.mp3","دَفْتَر":"029.mp3","أَلْوان":"030.mp3","مِقَصّ":"031.mp3","مِمْحاة":"032.mp3","مِسْطَرَة":"033.mp3","حرف الألف":"034.mp3","أَ":"035.mp3","أُ":"036.mp3","إِ":"037.mp3","أَرانِب":"038.mp3","قِطَّة":"039.mp3","إِوَزَّة":"040.mp3","فيل":"041.mp3","حرف الباء":"042.mp3","بَ":"043.mp3","بُ":"044.mp3","بِ":"045.mp3","بَصَل":"046.mp3","مَوْز":"047.mp3","بِطّيخ":"048.mp3","تُفّاح":"049.mp3","بُرْتُقال":"050.mp3","حرف التاء":"051.mp3","تَ":"052.mp3","تُ":"053.mp3","تِ":"054.mp3","نَجْمَة":"055.mp3","شَجَرَة":"056.mp3","تُفّاحَة":"057.mp3","تِمْساح":"058.mp3","تاج":"059.mp3","حرف الثاء":"060.mp3","ثَ":"061.mp3","ثُ":"062.mp3","ثِ":"063.mp3","ثَوْب":"064.mp3","عِقْد":"065.mp3","ثَلاث هَدايا":"066.mp3","حرف الجيم":"067.mp3","جَ":"068.mp3","جُ":"069.mp3","جِ":"070.mp3","جَزَر":"071.mp3","جَوْز":"072.mp3","كَرَز":"073.mp3","جَوْهَرَة":"074.mp3","حرف الحاء":"075.mp3","حَ":"076.mp3","حُ":"077.mp3","حِ":"078.mp3","نَمِر":"079.mp3","سُلَحْفاة":"080.mp3","حَمامَة":"081.mp3","أَكَلَ":"082.mp3","كَأْسٌ":"083.mp3","بَيْتٌ":"084.mp3","حَبْلٌ":"085.mp3","تَعِبَ":"086.mp3","فَتَحَ":"087.mp3","ثَقَبَ":"088.mp3","كَثُرَ":"089.mp3","جَلَسَ":"090.mp3","حَجَبَ":"091.mp3","حَصَلَ":"092.mp3","سَحَبَ":"093.mp3","أرنب":"094.mp3","بطّة":"095.mp3","تفّاحة":"096.mp3","ثعلب":"097.mp3","جمل":"098.mp3","حصان":"099.mp3","حرف الخاء":"100.mp3","خَ":"101.mp3","خُ":"102.mp3","خِ":"103.mp3","خروف":"104.mp3","حرف الدال":"105.mp3","دَ":"106.mp3","دُ":"107.mp3","دِ":"108.mp3","دبّ":"109.mp3","حرف الذال":"110.mp3","ذَ":"111.mp3","ذُ":"112.mp3","ذِ":"113.mp3","ذرة":"114.mp3","حرف الراء":"115.mp3","رَ":"116.mp3","رُ":"117.mp3","رِ":"118.mp3","ريشة":"119.mp3","حرف الزاي":"120.mp3","زَ":"121.mp3","زُ":"122.mp3","زِ":"123.mp3","زرافة":"124.mp3","حرف السين":"125.mp3","سَ":"126.mp3","سُ":"127.mp3","سِ":"128.mp3","سمكة":"129.mp3","حرف الشين":"130.mp3","شَ":"131.mp3","شُ":"132.mp3","شِ":"133.mp3","شمس":"134.mp3","حرف الصاد":"135.mp3","صَ":"136.mp3","صُ":"137.mp3","صِ":"138.mp3","صقر":"139.mp3","حرف الضاد":"140.mp3","ضَ":"141.mp3","ضُ":"142.mp3","ضِ":"143.mp3","ضفدع":"144.mp3","حرف الطاء":"145.mp3","طَ":"146.mp3","طُ":"147.mp3","طِ":"148.mp3","طائرة":"149.mp3","حرف الظاء":"150.mp3","ظَ":"151.mp3","ظُ":"152.mp3","ظِ":"153.mp3","ظرف":"154.mp3","حرف العين":"155.mp3","عَ":"156.mp3","عُ":"157.mp3","عِ":"158.mp3","عنب":"159.mp3","حرف الغين":"160.mp3","غَ":"161.mp3","غُ":"162.mp3","غِ":"163.mp3","غيمة":"164.mp3","حرف الفاء":"165.mp3","فَ":"166.mp3","فُ":"167.mp3","فِ":"168.mp3","حرف القاف":"169.mp3","قَ":"170.mp3","قُ":"171.mp3","قِ":"172.mp3","قمر":"173.mp3","حرف الكاف":"174.mp3","كَ":"175.mp3","كُ":"176.mp3","كِ":"177.mp3","كتاب":"178.mp3","حرف اللام":"179.mp3","لَ":"180.mp3","لُ":"181.mp3","لِ":"182.mp3","ليمون":"183.mp3","حرف الميم":"184.mp3","مَ":"185.mp3","مُ":"186.mp3","مِ":"187.mp3","موز":"188.mp3","حرف النون":"189.mp3","نَ":"190.mp3","نُ":"191.mp3","نِ":"192.mp3","نحلة":"193.mp3","حرف الهاء":"194.mp3","هَ":"195.mp3","هُ":"196.mp3","هاتف":"197.mp3","حرف الواو":"198.mp3","وَ":"199.mp3","وُ":"200.mp3","وِ":"201.mp3","وردة":"202.mp3","حرف الياء":"203.mp3","يَ":"204.mp3","يُ":"205.mp3","يِ":"206.mp3","يد":"207.mp3","أحسنت":"208.mp3","هِ":"209.mp3"},_kA=null;
function kAud(t){t=String(t||"").replace(/\s+/g," ").trim();var f=KAUD[t];if(!f&&t.length<=2&&typeof LET!=="undefined"){var L=LET.filter(function(x){return x[0]===t||(x[0]==="ا"&&/^[أإآ]$/.test(t));})[0];if(L)f=KAUD["حرف ال"+L[1]];}if(!f)return false;try{if(window.speechSynthesis)speechSynthesis.cancel();if(_kA)_kA.pause();_kA=new Audio("audio/g1/"+f);var p=_kA.play();if(p&&p.catch)p.catch(function(){});return true;}catch(e){return false;}}
/*KAUD-END*/
function kSay(t,rate){if(kAud(t))return true;try{if(!window.speechSynthesis)return false;var ss=window.speechSynthesis;
  if(!_arVoice){var v=ss.getVoices();_arVoice=v.filter(function(x){return /^ar/i.test(x.lang);})[0]||null;}
  ss.cancel();var u=new SpeechSynthesisUtterance(t);u.lang=_arVoice?_arVoice.lang:"ar-SA";if(_arVoice)u.voice=_arVoice;u.rate=rate||.8;u.pitch=1.1;ss.speak(u);return true;}catch(e){return false;}}
if(window.speechSynthesis)try{speechSynthesis.onvoiceschanged=function(){_arVoice=null;};}catch(e){}
window.kSay=kSay;
var LET=[["ا","ألف","أرنب","🐰"],["ب","باء","بطّة","🦆"],["ت","تاء","تفّاحة","🍎"],["ث","ثاء","ثعلب","🦊"],["ج","جيم","جمل","🐪"],["ح","حاء","حصان","🐴"],["خ","خاء","خروف","🐑"],
 ["د","دال","دبّ","🐻"],["ذ","ذال","ذرة","🌽"],["ر","راء","ريشة","🪶"],["ز","زاي","زرافة","🦒"],["س","سين","سمكة","🐟"],["ش","شين","شمس","☀️"],["ص","صاد","صقر","🦅"],
 ["ض","ضاد","ضفدع","🐸"],["ط","طاء","طائرة","✈️"],["ظ","ظاء","ظرف","✉️"],["ع","عين","عنب","🍇"],["غ","غين","غيمة","☁️"],["ف","فاء","فيل","🐘"],["ق","قاف","قمر","🌙"],
 ["ك","كاف","كتاب","📖"],["ل","لام","ليمون","🍋"],["م","ميم","موز","🍌"],["ن","نون","نحلة","🐝"],["ه","هاء","هاتف","📱"],["و","واو","وردة","🌹"],["ي","ياء","يد","✋"]];
var NOJOIN="ادذرزوأإآ";
function forms(l){var b=l==="ا"?"أ":l,Z="\u200D";return NOJOIN.indexOf(l)>-1?[[b,"منفصل"],[Z+b,"متصل في الآخر"]]:[[b+Z,"أول الكلمة"],[Z+b+Z,"وسط الكلمة"],[Z+b,"آخر الكلمة متصل"],[b,"آخر الكلمة منفصل"]];}
var KC=["#f43f5e","#f97316","#eab308","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899"];
function kidBurst(host,x,y){var E=["⭐","🌟","✨","🎉","💛"];for(var i=0;i<12;i++){var s=document.createElement("i");s.className="k-burst";s.textContent=E[i%5];s.style.left=x+"px";s.style.top=y+"px";
  var a=Math.random()*Math.PI*2,d=60+Math.random()*90;s.style.setProperty("--dx",Math.cos(a)*d+"px");s.style.setProperty("--dy",Math.sin(a)*d+"px");host.appendChild(s);setTimeout(function(q){return function(){q.remove();};}(s),900);}}

/* ---------- الحروف التفاعلية ---------- */
function openABC(focus,title){var G=gxShell("kabc","الحروف التفاعلية","k-abc"),body=G.body;
  function board(){G.stat.innerHTML="";body.innerHTML='<p class="k-hint">اضغط على الحرف لتسمعه وتتعلّمه</p><div class="k-board">'+LET.map(function(L,i){var f=focus&&focus.indexOf(L[0])>-1;
      return '<button class="k-key'+(f?' focus':'')+'" style="--c:'+KC[i%8]+'" data-i="'+i+'"><b>'+(L[0]==="ا"?"أ":L[0])+'</b><small>'+L[1]+'</small></button>';}).join("")+'</div>';
    body.querySelectorAll(".k-key").forEach(function(b){b.onclick=function(){var L=LET[+b.getAttribute("data-i")];b.classList.remove("bop");void b.offsetWidth;b.classList.add("bop");kSay("حرف ال"+L[1]);setTimeout(function(){card(+b.getAttribute("data-i"));},350);};});}
  function card(i){var L=LET[i],c=KC[i%8],h=L[0]==="ا"?"أ":L[0],hv=L[0]==="ا"?["أَ","أُ","إِ"]:[L[0]+"َ",L[0]+"ُ",L[0]+"ِ"];
    body.innerHTML='<div class="k-card" style="--c:'+c+'"><button class="k-big" data-say="حرف ال'+L[1]+'"><b>'+h+'</b><small>حرف ال'+L[1]+' 🔊</small></button>'+
      '<p class="k-sec">أصوات الحرف بالحركات</p><div class="k-hv">'+hv.map(function(x,j){return '<button data-say="'+x+'"><b>'+x+'</b><small>'+["فتحة","ضمّة","كسرة"][j]+'</small></button>';}).join("")+'</div>'+
      '<p class="k-sec">أشكال الحرف في الكلمة</p><div class="k-fm">'+forms(L[0]).map(function(f){return '<div><b>'+f[0]+'</b><small>'+f[1]+'</small></div>';}).join("")+'</div>'+
      '<button class="k-word" data-say="'+L[2]+'"><span class="k-emo">'+L[3]+'</span><b>'+L[2]+'</b><small>🔊</small></button>'+
      '<div class="k-nav"><button class="gx-go alt" data-p>‹ السابق</button><button class="gx-go" data-b>كل الحروف</button><button class="gx-go alt" data-n>التالي ›</button></div></div>';
    body.querySelectorAll("[data-say]").forEach(function(b){b.onclick=function(){kSay(b.getAttribute("data-say"));b.classList.remove("bop");void b.offsetWidth;b.classList.add("bop");};});
    body.querySelector("[data-b]").onclick=board;body.querySelector("[data-p]").onclick=function(){card((i+27)%28);};body.querySelector("[data-n]").onclick=function(){card((i+1)%28);};
    G.stat.innerHTML='<span>'+an(i+1)+' / ٢٨</span>';}
  if(focus&&focus.length===1){var fi=LET.findIndex(function(L){return L[0]===focus[0]||(focus[0]==="أ"&&L[0]==="ا");});if(fi>-1)return card(fi);}
  board();}

/* ---------- أمرّر القلم: التتبّع على الخطوط المنقّطة ---------- */
var SHP2={
 hline:function(c,S){c.moveTo(S*.12,S*.5);c.lineTo(S*.88,S*.5);},
 vlines:function(c,S){for(var i=0;i<5;i++){var x=S*(.2+i*.15);c.moveTo(x,S*.25);c.lineTo(x,S*.75);}},
 zigzag:function(c,S){c.moveTo(S*.1,S*.62);for(var i=1;i<=6;i++)c.lineTo(S*(.1+i*.133),i%2?S*.38:S*.62);},
 wave:function(c,S){c.moveTo(S*.1,S*.5);for(var i=0;i<4;i++){var x=S*(.1+i*.2);c.quadraticCurveTo(x+S*.05,i%2?S*.66:S*.34,x+S*.1,S*.5);c.quadraticCurveTo(x+S*.15,i%2?S*.34:S*.66,x+S*.2,S*.5);}},
 loops:function(c,S){for(var i=0;i<4;i++){c.moveTo(S*(.24+i*.18)+S*.07,S*.5);c.arc(S*(.24+i*.18),S*.5,S*.07,0,Math.PI*2);}},
 circle:function(c,S){c.moveTo(S*.8,S*.5);c.arc(S*.5,S*.5,S*.3,0,Math.PI*2);},
 square:function(c,S){c.rect(S*.22,S*.22,S*.56,S*.56);},
 triangle:function(c,S){c.moveTo(S*.5,S*.18);c.lineTo(S*.82,S*.78);c.lineTo(S*.18,S*.78);c.closePath();},
 star:function(c,S){for(var i=0;i<=10;i++){var a=-Math.PI/2+i*Math.PI/5,r=i%2?S*.14:S*.33;var x=S*.5+Math.cos(a)*r,y=S*.52+Math.sin(a)*r;i?c.lineTo(x,y):c.moveTo(x,y);}},
 hexagon:function(c,S){for(var i=0;i<=6;i++){var a=Math.PI/6+i*Math.PI/3,x=S*.5+Math.cos(a)*S*.3,y=S*.5+Math.sin(a)*S*.3;i?c.lineTo(x,y):c.moveTo(x,y);}},
 fatha:function(c,S){c.moveTo(S*.68,S*.4);c.lineTo(S*.32,S*.6);},
 kasra:function(c,S){c.moveTo(S*.68,S*.42);c.lineTo(S*.32,S*.62);},
 vline:function(c,S){c.moveTo(S*.5,S*.18);c.lineTo(S*.5,S*.82);},
 slashF:function(c,S){c.moveTo(S*.66,S*.24);c.lineTo(S*.34,S*.76);},
 slashB:function(c,S){c.moveTo(S*.34,S*.24);c.lineTo(S*.66,S*.76);},
 cupUp:function(c,S){c.moveTo(S*.78,S*.38);c.arc(S*.5,S*.38,S*.28,0,Math.PI);},
 capDown:function(c,S){c.moveTo(S*.78,S*.64);c.arc(S*.5,S*.64,S*.28,0,Math.PI,true);},
 openRight:function(c,S){c.moveTo(S*.5,S*.22);c.arc(S*.5,S*.5,S*.28,-Math.PI/2,Math.PI/2,true);},
 openLeft:function(c,S){c.moveTo(S*.5,S*.22);c.arc(S*.5,S*.5,S*.28,-Math.PI/2,Math.PI/2,false);},
 bowl:function(c,S){c.moveTo(S*.84,S*.36);c.quadraticCurveTo(S*.86,S*.64,S*.62,S*.64);c.lineTo(S*.38,S*.64);c.quadraticCurveTo(S*.14,S*.64,S*.16,S*.4);},
 hook:function(c,S){c.moveTo(S*.3,S*.3);c.lineTo(S*.66,S*.3);c.quadraticCurveTo(S*.36,S*.36,S*.32,S*.56);c.quadraticCurveTo(S*.3,S*.78,S*.66,S*.76);}};
var SHN={hline:"خطّ مستقيم",vlines:"خطوط المطر",zigzag:"قمم الجبال",wave:"أمواج البحر",loops:"دوائر صغيرة",circle:"دائرة",square:"مربّع",triangle:"مثلّث",star:"نجمة",hexagon:"شكل سداسي",fatha:"الفتحة",kasra:"الكسرة",vline:"خطّ عمودي (مثل الألف)",slashF:"خطّ مائل /",slashB:"خطّ مائل \\",cupUp:"نصف دائرة فتحتها للأعلى",capDown:"نصف دائرة فتحتها للأسفل",
 openRight:"نصف دائرة فتحتها لليمين",openLeft:"نصف دائرة فتحتها لليسار",bowl:"قوس الباء والتاء والثاء",hook:"رأس الجيم والحاء"};
function openTrace(items,title){if(!items||!items.length)return;
  var G=gxShell("ktr","أمرّر القلم","k-tr"),body=G.body,idx=0,col=KC[5],stars={};
  body.innerHTML='<div class="tr-top"><div class="tr-name"></div><button class="tr-say" aria-label="استمع">🔊</button></div><div class="tr-wrap"><canvas class="tr-cv"></canvas><div class="tr-msg"></div></div>'+
    '<div class="tr-bar"><button class="gx-go alt" data-p>السابق</button><button class="gx-go alt" data-c>↺ أعد</button><div class="tr-cols">'+KC.slice(0,6).map(function(c){return '<button data-col="'+c+'" style="background:'+c+'"></button>';}).join("")+'</div><button class="gx-go" data-n>التالي</button></div>';
  var cv=body.querySelector(".tr-cv"),cx=cv.getContext("2d"),wrap=body.querySelector(".tr-wrap"),S=300,dpr=1,mask=null,targets=[],hit=null,hcx=null,strokes=[],cur=null,done=false;
  function item(){return items[idx];}
  function mk(w,h){var c=document.createElement("canvas");c.width=w;c.height=h;return c;}
  function layout(){var r=wrap.getBoundingClientRect();S=Math.floor(Math.min(r.width,r.height));dpr=Math.min(window.devicePixelRatio||1,2);cv.style.width=S+"px";cv.style.height=S+"px";cv.width=S*dpr;cv.height=S*dpr;prep();draw();}
  function glyphFont(it){var len=Array.from(it.v.replace(/\u200D/g,"")).length;return "800 "+Math.round(S*(len>2?.26:len>1?.42:.66))+"px 'Tajawal','Geeza Pro','Segoe UI',Tahoma,sans-serif";}
  function guide(c,it,mode){c.save();c.lineCap="round";c.lineJoin="round";
    if(it.t==="shape"){c.beginPath();SHP2[it.v](c,S);if(mode==="mask"){c.lineWidth=S*.05;c.strokeStyle="#000";c.stroke();}else if(mode==="fat"){c.lineWidth=S*.13;c.strokeStyle="#000";c.stroke();}
      else{c.setLineDash([S*.025,S*.025]);c.lineWidth=S*.03;c.strokeStyle="#94a3b8";c.stroke();}}
    else{c.font=glyphFont(it);c.textAlign="center";c.textBaseline="middle";c.direction="rtl";var y=S*.56;
      if(mode==="mask"){c.fillStyle="#000";c.fillText(it.v,S/2,y);}else if(mode==="fat"){c.lineWidth=S*.09;c.strokeStyle="#000";c.fillStyle="#000";c.strokeText(it.v,S/2,y);c.fillText(it.v,S/2,y);}
      else{c.fillStyle="#eef2ff";c.fillText(it.v,S/2,y);c.setLineDash([S*.018,S*.018]);c.lineWidth=S*.012;c.strokeStyle="#6366f1";c.strokeText(it.v,S/2,y);}}
    c.restore();}
  function prep(){var it=item();mask=mk(S,S);var m=mask.getContext("2d");guide(m,it,"mask");var d=m.getImageData(0,0,S,S).data,g=Math.max(4,Math.round(S/45));targets=[];
    for(var y=0;y<S;y+=g)for(var x=0;x<S;x+=g)if(d[(y*S+x)*4+3]>128)targets.push([x,y]);
    var fat=mk(S,S),f=fat.getContext("2d");guide(f,it,"fat");mask.fat=f.getImageData(0,0,S,S).data;
    hit=mk(S,S);hcx=hit.getContext("2d");strokes=[];done=false;body.querySelector(".tr-msg").className="tr-msg";
    body.querySelector(".tr-name").innerHTML=(it.t==="shape"?SHN[it.v]:'<b>'+it.v+'</b>')+(it.label?' <small>'+esc(it.label)+'</small>':'')+(stars[idx]?' ⭐':'');
    G.stat.innerHTML='<span>'+an(idx+1)+' / '+an(items.length)+'</span>';}
  function draw(){cx.setTransform(dpr,0,0,dpr,0,0);cx.clearRect(0,0,S,S);
    cx.fillStyle="#fff";cx.fillRect(0,0,S,S);cx.strokeStyle="#e0e7ff";cx.lineWidth=1;for(var y=S*.2;y<S;y+=S*.2){cx.beginPath();cx.moveTo(0,y);cx.lineTo(S,y);cx.stroke();}
    guide(cx,item(),"show");
    if(item().t==="shape"){var c2=mk(1,1);var st=startPt(item());if(st){cx.fillStyle="#22c55e";cx.beginPath();cx.arc(st[0],st[1],S*.03,0,7);cx.fill();cx.strokeStyle="#22c55e";cx.lineWidth=3;cx.beginPath();cx.arc(st[0],st[1],S*.05,0,7);cx.stroke();cx.fillStyle="#166534";cx.font="700 "+Math.round(S*.04)+"px Tajawal,sans-serif";cx.textAlign="center";cx.fillText("ابدأ",st[0],st[1]-S*.07);}}
    strokes.forEach(function(s){line(cx,s);});if(cur)line(cx,cur);}
  function startPt(it){var p={x:0,y:0,f:false},fake={moveTo:function(x,y){if(!p.f){p.x=x;p.y=y;p.f=true;}},lineTo:function(x,y){if(!p.f){p.x=x;p.y=y;p.f=true;}},arc:function(){},rect:function(x,y){if(!p.f){p.x=x;p.y=y;p.f=true;}},quadraticCurveTo:function(){},closePath:function(){}};
    SHP2[it.v](fake,S);return p.f?[p.x,p.y]:null;}
  function line(c,s){c.save();c.strokeStyle=s.c;c.lineWidth=S*.045;c.lineCap="round";c.lineJoin="round";c.beginPath();s.p.forEach(function(q,i){i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]);});if(s.p.length===1)c.lineTo(s.p[0][0]+.1,s.p[0][1]);c.stroke();c.restore();}
  function pos(e){var r=cv.getBoundingClientRect();return [(e.clientX-r.left)*S/r.width,(e.clientY-r.top)*S/r.height];}
  cv.addEventListener("pointerdown",function(e){e.preventDefault();if(done)return;try{cv.setPointerCapture(e.pointerId);}catch(_){}cur={c:col,p:[pos(e)]};draw();});
  function outside(q){var x=Math.round(q[0]),y=Math.round(q[1]);if(x<0||y<0||x>=S||y>=S)return true;return mask.fat[(y*S+x)*4+3]<50;}
  cv.addEventListener("pointermove",function(e){if(!cur)return;var evs=e.getCoalescedEvents?e.getCoalescedEvents():[e];evs.forEach(function(ev){var q=pos(ev);cur.p.push(q);
      if(!cur.err&&outside(q)){cur.err=true;cur.c="#ef4444";GS.buzz();var m=body.querySelector(".tr-msg");m.className="tr-msg no";m.textContent="✘ خطأ! خرجت عن الخط";wrap.classList.remove("shk");void wrap.offsetWidth;wrap.classList.add("shk");if(navigator.vibrate)try{navigator.vibrate(80);}catch(_){}}});draw();});
  function up(){if(!cur)return;
    if(cur.err){var bad=cur;cur=null;strokes.push(bad);draw();var m=body.querySelector(".tr-msg");m.className="tr-msg no";m.textContent="✘ خرجت عن الخط، امسح وأعد المحاولة على النقاط";
      setTimeout(function(){strokes=strokes.filter(function(x){return x!==bad;});draw();},900);return;}
    strokes.push(cur);hcx.save();hcx.strokeStyle="#000";hcx.lineWidth=S*.075;hcx.lineCap="round";hcx.lineJoin="round";hcx.beginPath();
    cur.p.forEach(function(q,i){i?hcx.lineTo(q[0],q[1]):hcx.moveTo(q[0],q[1]);});if(cur.p.length===1)hcx.lineTo(cur.p[0][0]+.1,cur.p[0][1]);hcx.stroke();hcx.restore();cur=null;draw();check();}
  cv.addEventListener("pointerup",up);cv.addEventListener("pointercancel",up);
  function check(){var d=hcx.getImageData(0,0,S,S).data,cov=0;targets.forEach(function(t){if(d[(t[1]*S+t[0])*4+3]>100)cov++;});var ratio=targets.length?cov/targets.length:0;
    var g=Math.max(4,Math.round(S/45)),ink=0,out=0,F=mask.fat;for(var y=0;y<S;y+=g)for(var x=0;x<S;x+=g){var k=(y*S+x)*4+3;if(d[k]>100){ink++;if(F[k]<50)out++;}}
    var stray=ink?out/ink:0,m=body.querySelector(".tr-msg");
    if(ratio>=.66&&stray<.4){done=true;stars[idx]=1;m.className="tr-msg ok";m.innerHTML="أحسنت! ⭐⭐⭐";GS.win();var r=cv.getBoundingClientRect(),wr=wrap.getBoundingClientRect();kidBurst(wrap,r.left-wr.left+r.width/2,r.top-wr.top+r.height/2);
      body.querySelector(".tr-name").innerHTML+=" ⭐";if(item().t!=="shape")kSay("أحسنت");}
    else if(stray>=.4&&ink>targets.length*.5){m.className="tr-msg no";m.textContent="حاول أن تمشي على النقاط 🙂";GS.buzz();}
    else{m.className="tr-msg go";m.textContent="هيّا… "+an(Math.round(ratio*100))+"٪";}}
  function go(i){idx=(i+items.length)%items.length;prep();draw();if(item().say)kSay(item().say);}
  body.querySelector("[data-p]").onclick=function(){go(idx-1);};body.querySelector("[data-n]").onclick=function(){go(idx+1);};
  body.querySelector("[data-c]").onclick=function(){prep();draw();};
  body.querySelectorAll("[data-col]").forEach(function(b){b.onclick=function(){col=b.getAttribute("data-col");body.querySelectorAll("[data-col]").forEach(function(x){x.classList.toggle("on",x===b);});};});
  body.querySelector('[data-col]').classList.add("on");col=KC[0];
  body.querySelector(".tr-say").onclick=function(){var it=item();kSay(it.say||(it.t==="shape"?SHN[it.v]:it.v));};
  var rt;function rs(){clearTimeout(rt);rt=setTimeout(layout,120);}window.addEventListener("resize",rs);
  var oc=G.onclose;G.onclose=function(){window.removeEventListener("resize",rs);if(oc)oc();};
  setTimeout(layout,30);}
window.KID={abc:openABC,trace:openTrace,say:kSay};
window.BLN={open:openBLN};window.TFG={open:openTF};window.WHL={open:openWHL};



/* ================= السبورة الاحترافية ================= */
/* كل ما يُرسم عنصرٌ مستقل يمكن تحديده وتحريكه وتكبيره وحذفه، مع أقلام متعددة وتسجيل فيديو بالصوت */
var WIC={
 sel:'<path d="M5 3l14 8-6 1.5L10 19Z"/>',
 pen:'<path d="M4 20l4-1 11-11-3-3L5 16Z"/><path d="m14 6 3 3"/>',
 ink:'<path d="M12 3c3 4 5 7 5 10a5 5 0 0 1-10 0c0-3 2-6 5-10Z"/><path d="M12 13v8"/>',
 cal:'<path d="m14 4 6 6-9 9H5v-6Z"/><path d="m5 19 5-5"/>',
 pcl:'<path d="M4 20l1.5-5L16 4.5 19.5 8 9 18.5Z"/><path d="m14 6.5 3.5 3.5M4 20l3.5-1"/>',
 mrk:'<path d="m9 15 6-6 3 3-6 6H9Z"/><path d="m15 9 2-5 3 3-5 2"/><path d="M4 21h8"/>',
 hl:'<path d="m9 11-5 5v4h4l5-5"/><path d="m9 11 6-6 4 4-6 6Z"/><path d="M14 20h6"/>',
 dsh:'<path d="M4 20 6 18M9 15l2-2M14 10l2-2M19 5l1-1"/>',
 las:'<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/>',
 er:'<path d="m7 21-4-4 10-10 7 7-7 7Z"/><path d="M7 21h13M9 11l7 7"/>',
 ep:'<path d="m7 21-4-4 10-10 7 7-7 7Z"/><path d="M7 21h13"/><circle cx="17" cy="5" r="2"/>',
 line:'<path d="M5 19 19 5"/>',arr:'<path d="M5 19 19 5M10 5h9v9"/>',darr:'<path d="M5 19 19 5M10 5h9v9M14 19H5v-9"/>',
 rect:'<rect x="4" y="6" width="16" height="12" rx="1"/>',ell:'<ellipse cx="12" cy="12" rx="8.5" ry="6.5"/>',tri:'<path d="M12 4 21 20H3Z"/>',
 star:'<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9Z"/>',
 shp:'<rect x="3" y="11" width="9" height="9" rx="1"/><circle cx="16.5" cy="7.5" r="4.5"/>',
 txt:'<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',img:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 17-5-5-9 8"/>',
 pan:'<path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/>',
 und:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',red:'<path d="m15 14 5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
 wipe:'<path d="M14.5 3.5l6 6-9.5 9.5H6l-3-3Z"/><path d="M9 8l6 6"/><path d="M6 20h14"/>', clr:'<path d="M4 7h16M10 11v6M14 11v6M5 7l1 13h12l1-13M9 7V4h6v3"/>',bg:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16M15 4v16"/>',
 save:'<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',x:'<path d="M6 6l12 12M18 6 6 18"/>',prev:'<path d="m9 6 6 6-6 6"/>',nxt:'<path d="m15 6-6 6 6 6"/>',add:'<path d="M12 5v14M5 12h14"/>',
 zin:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4M11 8v6M8 11h6"/>',zout:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4M8 11h6"/>',
 dup:'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
 up:'<path d="M12 19V5M5 12l7-7 7 7"/>',down:'<path d="M12 5v14M5 12l7 7 7-7"/>',paint:'<path d="M12 3a9 9 0 1 0 0 18c1 0 1.5-.8 1.5-1.6 0-1.2-1-1.4-1-2.4 0-.8.7-1.5 1.5-1.5H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3Z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7" r="1"/>',
 pause:'<path d="M8 5v14M16 5v14"/>',play:'<path d="M7 4v16l13-8Z"/>',stop:'<rect x="6" y="6" width="12" height="12" rx="2"/>',
 mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
 frame:'<path d="M3 8V5a2 2 0 0 1 2-2h3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M8 21H5a2 2 0 0 1-2-2v-3"/><circle cx="12" cy="12" r="2.5"/>',
 front:'<rect x="8" y="8" width="12" height="12" rx="2" fill="currentColor" fill-opacity=".35"/><path d="M4 16V5a1 1 0 0 1 1-1h11"/>',
 back:'<rect x="4" y="4" width="12" height="12" rx="2" fill="currentColor" fill-opacity=".35"/><path d="M20 8v11a1 1 0 0 1-1 1H8"/>',
 film:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>'};
function wico(n){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+(WIC[n]||"")+'</svg>';}
var BGS=[{k:"w",n:"أبيض",bg:"#ffffff",ln:""},{k:"lines",n:"مسطّر",bg:"#ffffff",ln:"lines"},{k:"grid",n:"مربعات",bg:"#ffffff",ln:"grid"},
 {k:"dots",n:"نقاط",bg:"#ffffff",ln:"dots"},{k:"green",n:"سبورة خضراء",bg:"#1f4d3a",ln:"",dark:1},{k:"black",n:"سبورة سوداء",bg:"#1b1d24",ln:"",dark:1}];
var COLS_L=["#1b2350","#000000","#e2557a","#c0392b","#3b4fc4","#0ea5e9","#13a59a","#27ae60","#f2a531","#d35400","#8e44ad","#7f8c8d","#ffffff"];
var COLS_D=["#ffffff","#ffe066","#ff8fab","#ff6b6b","#8ecbff","#b0f2ff","#a6f4a6","#7dffcf","#ffb86b","#fff2b3","#d7b8ff","#c8c8c8","#1b2350"];
var PENS=[["pen","قلم عادي"],["ink","قلم حبر"],["cal","قلم الخط العربي"],["pcl","قلم رصاص"],["mrk","ماركر"],["hl","قلم تظليل"],["dsh","قلم منقّط"],["las","قلم ليزر"]];
var SHAPES=[["line","خط"],["arr","سهم"],["darr","سهم مزدوج"],["rect","مستطيل"],["ell","دائرة"],["tri","مثلث"],["star","نجمة"]];
var WFONTS=[["Tajawal","تجوال"],["Amiri","أميري"],["Noto Naskh Arabic","نسخ"],["Cairo","القاهرة"]];
var RECAR={"16:9":[16,9],"4:3":[4,3],"1:1":[1,1],"9:16":[9,16]};
/* أبعاد الفيديو حسب الدقة ونسبة الإطار (الضلع القصير = 1080 أو 1440 أو 2160) */
function recDims(q,ar){var a=RECAR[ar]||RECAR["16:9"],sh=+q||1080,w,h;if(a[0]>=a[1]){h=sh;w=Math.round(sh*a[0]/a[1]/2)*2;}else{w=sh;h=Math.round(sh*a[1]/a[0]/2)*2;}
  var br=Math.round(w*h*30*0.26);return [w,h,Math.min(60e6,Math.max(8e6,br))];}

function openWB(key,title){
  var store="wb:"+(key||"x"),st,cfgKey="wb:cfg";
  try{st=JSON.parse(localStorage.getItem(store)||"null");}catch(e){st=null;}
  if(!st||!st.pages)st={pages:[{o:[]}],bg:"w",pg:0};
  st.imgs=st.imgs||{};
  var uid=0;function nid(){return "o"+Date.now().toString(36)+(uid++);}
  /* تحويل الرسومات المحفوظة بالنسخة القديمة */
  st.pages.forEach(function(p){p.o=(p.o||[]).map(function(o){if(o.t==="pen"||o.t==="hl")o={t:"s",pen:o.t,c:o.c,w:o.w,p:o.p};if(!o.id)o.id=nid();return o;});});
  var cfg={pen:"pen",shp:"rect",w:4,tz:44,tf:"Tajawal",fill:false,q:"1080",mic:true,cam:false,ar:"16:9",frame:true};
  try{var c0=JSON.parse(localStorage.getItem(cfgKey)||"null");if(c0)for(var k0 in c0)cfg[k0]=c0[k0];}catch(e){}
  function saveCfg(){try{localStorage.setItem(cfgKey,JSON.stringify(cfg));}catch(e){}}

  var el=document.createElement("div");el.id="wb";el.setAttribute("role","dialog");el.setAttribute("aria-label","السبورة");
  var tools=[["sel","تحديد وتحريك"],["pen","الأقلام"],["shp","الأشكال"],["txt","نص"],["er","ممحاة (تحذف العنصر كاملًا)"],["ep","ممحاة دقيقة"],["img","إدراج صورة"],["pan","تحريك اللوحة"]];
  el.innerHTML='<canvas class="wb-cv"></canvas>'+
   '<div class="wb-top">'+
    '<div class="wb-grp"><button class="wb-b" data-a="x" aria-label="إغلاق" title="إغلاق">'+wico("x")+'</button>'+
      '<button class="wb-b" data-a="win" aria-label="نافذة عائمة أو ملء الشاشة" title="نافذة عائمة / ملء الشاشة" style="font-size:22px;font-weight:800">⧉</button>'+
      '<button class="wb-b" data-a="c" aria-label="مسح الصفحة" title="مسح الصفحة">'+wico("clr")+'</button><button class="wb-b" data-a="s" aria-label="حفظ صورة" title="حفظ الصفحة صورة">'+wico("save")+'</button></div>'+
    '<div class="wb-grp"><button class="wb-b wb-rec wb-recst" data-a="recp" aria-label="تسجيل فيديو" title="تسجيل السبورة فيديو بالصوت"><span class="rc"></span></button><button class="wb-b wb-frb" data-a="frame" aria-label="إظهار أو إخفاء حدود التسجيل" title="إظهار / إخفاء حدود منطقة التسجيل">'+wico("frame")+'</button><button class="wb-b wb-edb" data-a="ed" aria-label="مونتاج الفيديو" title="مونتاج الفيديو المسجَّل" hidden>'+wico("film")+'</button>'+
      '<div class="wb-recbar"><span class="wb-rdot"></span><span class="wb-rt">00:00</span><button class="wb-b" data-a="rpause" aria-label="إيقاف مؤقت" title="إيقاف مؤقت / إكمال">'+wico("pause")+'</button>'+
      '<button class="wb-b wb-rec" data-a="rstop" aria-label="إنهاء التسجيل" title="إنهاء التسجيل وحفظ الفيديو">'+wico("stop")+'</button></div></div>'+
    '<div class="wb-grp wb-zoom"><button class="wb-b" data-a="zo" aria-label="تصغير العرض" title="تصغير العرض">'+wico("zout")+'</button><button class="wb-zv" data-a="z1" title="العودة إلى ١٠٠٪">100%</button>'+
      '<button class="wb-b" data-a="zi" aria-label="تكبير العرض" title="تكبير العرض">'+wico("zin")+'</button></div>'+
    '<div class="wb-grp"><button class="wb-b" data-a="pp" aria-label="الصفحة السابقة">'+wico("prev")+'</button><span class="wb-pg"></span><button class="wb-b" data-a="pn" aria-label="الصفحة التالية">'+wico("nxt")+'</button>'+
      '<button class="wb-b" data-a="pa" aria-label="صفحة جديدة" title="صفحة جديدة">'+wico("add")+'</button></div>'+
   '</div>'+
   '<div class="wb-bar">'+tools.map(function(t){return '<button class="wb-b" data-t="'+t[0]+'" aria-label="'+t[1]+'" title="'+t[1]+'">'+wico(t[0])+((t[0]==="pen"||t[0]==="shp")?'<i class="wb-more"></i>':'')+'</button>';}).join("")+
    '<span class="wb-sep"></span><button class="wb-b" data-a="col" aria-label="اللون والحجم" title="اللون والحجم ونوع الخط"><span class="wb-dot"></span></button><button class="wb-b" data-a="bgp" aria-label="الخلفية" title="الخلفية">'+wico("bg")+'</button>'+
    '<button class="wb-b" data-a="u" aria-label="تراجع" title="تراجع (Ctrl+Z)">'+wico("und")+'</button><button class="wb-b" data-a="r" aria-label="إعادة" title="إعادة">'+wico("red")+'</button><button class="wb-b wb-wipe" data-a="wipe" aria-label="مسح السبورة كاملة" title="مسح السبورة كاملة (يمكن التراجع)">'+wico("wipe")+'</button></div>'+
   '<div class="wb-pop" data-p="pens"><h4>نوع القلم</h4><div class="wb-opts">'+PENS.map(function(p){return '<button data-pen="'+p[0]+'">'+wico(p[0]==="las"?"las":p[0])+'<span>'+p[1]+'</span></button>';}).join("")+'</div>'+
     '<h4>السُّمك <output data-o="w"></output></h4><input type="range" min="1" max="60" step="1" data-r="w"><div class="wb-prev"><canvas width="300" height="44" style="width:300px;height:44px"></canvas></div></div>'+
   '<div class="wb-pop" data-p="shps"><h4>الأشكال</h4><div class="wb-opts">'+SHAPES.map(function(p){return '<button data-shp="'+p[0]+'">'+wico(p[0])+'<span>'+p[1]+'</span></button>';}).join("")+'</div>'+
     '<label class="wb-chk"><input type="checkbox" data-k="fill"> شكل مُعبّأ باللون</label><h4>سُمك الحدود <output data-o="w"></output></h4><input type="range" min="1" max="60" step="1" data-r="w"></div>'+
   '<div class="wb-pop" data-p="col"><h4>اللون</h4><div class="wb-cols"></div><h4>سُمك القلم <output data-o="w"></output></h4><input type="range" min="1" max="60" step="1" data-r="w">'+
     '<h4>حجم الكتابة <output data-o="tz"></output></h4><input type="range" min="14" max="240" step="2" data-r="tz"><h4>نوع خط الكتابة</h4><div class="wb-opts two">'+
     WFONTS.map(function(f){return '<button data-tf="'+f[0]+'" style="font-family:\''+f[0]+'\',Tajawal,sans-serif;font-size:15px">'+f[1]+'</button>';}).join("")+'</div></div>'+
   '<div class="wb-pop" data-p="bgp"><h4>خلفية السبورة</h4><div class="wb-opts">'+BGS.map(function(b){return '<button data-bg="'+b.k+'">'+b.n+'</button>';}).join("")+'</div></div>'+
   '<div class="wb-pop top" data-p="recp"><h4>🎬 تسجيل السبورة فيديو</h4><h4 style="margin-top:0">دقة الفيديو</h4><div class="wb-opts">'+
     '<button data-q="1080">Full HD<br>1080p</button><button data-q="1440">2K<br>1440p</button><button data-q="2160">4K<br>2160p</button></div>'+
     '<h4>شكل منطقة التسجيل</h4><div class="wb-opts" style="grid-template-columns:repeat(4,1fr)"><button data-ar="16:9">16:9<br>عريض</button><button data-ar="4:3">4:3</button><button data-ar="1:1">1:1<br>مربع</button><button data-ar="9:16">9:16<br>طولي</button></div>'+
     '<label class="wb-chk"><input type="checkbox" data-k="frame"> إظهار حدود منطقة التسجيل</label>'+
     '<label class="wb-chk"><input type="checkbox" data-k="mic"> تسجيل الصوت (المايكروفون)</label><label class="wb-chk"><input type="checkbox" data-k="cam"> إظهار الكاميرا في زاوية الفيديو</label>'+
     '<button class="wb-go" data-a="rstart">● ابدأ التسجيل</button><p class="wb-note">يُسجَّل ما داخل الحدود فقط مع صوتك، فيظهر الشرح كبيرًا وواضحًا. بعد الإنهاء تفتح نافذة المونتاج لقصّ المقاطع وترتيبها. يمكنك الإيقاف المؤقت والإكمال، وعند الإنهاء يُحفظ الفيديو على جهازك. دقة 4K تحتاج جهازًا قويًا.</p></div>'+
   '<div class="wb-sel"><button data-sa="del" class="del" title="حذف">'+wico("clr")+'</button><button data-sa="dup" title="نسخ">'+wico("dup")+'</button>'+
     '<button data-sa="big" title="تكبير">أ+</button><button data-sa="small" title="تصغير">أ−</button><button data-sa="col" title="تغيير لون العنصر">'+wico("paint")+'</button>'+
     '<button data-sa="up" title="وضعه فوق العناصر الأخرى">'+wico("front")+'</button><button data-sa="down" title="وضعه خلف العناصر الأخرى">'+wico("back")+'</button><div class="wb-selcol"></div></div>'+
   '<div class="wb-toast"></div><div class="wb-ed"><div class="ed-box"><div class="ed-head"><h3>🎬 مونتاج الفيديو</h3><button class="ed-x" data-ea="close" aria-label="إغلاق">✕</button></div>'+
     '<div class="ed-stage"><video class="ed-v" playsinline></video><div class="ed-busy"><b>جارٍ تصدير الفيديو…</b><div class="ed-bar"><i></i></div><span class="ed-pct">٠٪</span><button data-ea="cancel">إلغاء التصدير</button></div></div>'+
     '<div class="ed-ctrl"><button data-ea="play" class="ed-pl" aria-label="تشغيل">▶</button><div class="ed-sk"><div class="ed-tr"></div><input type="range" class="ed-seek" min="0" max="1000" value="0" step="1"></div><span class="ed-time">0:00</span></div>'+
     '<div class="ed-tl"></div>'+
     '<div class="ed-tools"><button data-ea="setin">⟦ ابدأ المقطع من هنا</button><button data-ea="setout">أنهِ المقطع هنا ⟧</button><button data-ea="split">✂️ قصّ إلى جزأين هنا</button>'+
     '<button data-ea="reset">↺ إلغاء القص</button><button data-ea="left">→ تقديم المقطع</button><button data-ea="right">تأخير المقطع ←</button><button data-ea="del" class="ed-del">🗑 حذف المقطع</button></div>'+
     '<div class="ed-foot"><button data-ea="more" class="ed-rec">● تسجيل مقطع جديد</button><button data-ea="playall">▶ معاينة الفيديو كاملًا</button><button data-ea="export" class="ed-exp">⬇️ تصدير الفيديو النهائي</button></div>'+
     '<p class="ed-info"></p></div></div>'+
   '<input type="file" accept="image/*" hidden class="wb-file">';
  document.body.appendChild(el);
  /* ===== السبورة نافذة عائمة: تُسحب من شريطها وتُكبَّر من زاويتها، ويبقى ما خلفها ظاهرًا وقابلًا للاستخدام ===== */
  var WIN={fl:1};try{var w0=JSON.parse(localStorage.getItem("wb:win")||"null");if(w0&&typeof w0==="object")WIN=w0;}catch(_){}if(/[?&]wbonly=1/.test(location.search))WIN.fl=0;
  var wbAct=true;
  var WINX=(function(){
    if(!document.getElementById("wb-win-css")){var cs=document.createElement("style");cs.id="wb-win-css";cs.textContent="#wb.wb-win{inset:auto;border:2px solid #1f4d3a;border-top:0;border-radius:0 0 16px 16px;box-shadow:0 24px 60px rgba(15,23,42,.35)}.wb-hd{position:fixed;z-index:2147483351;display:flex;align-items:center;gap:6px;height:34px;padding:0 10px 0 6px;background:linear-gradient(160deg,#2f8f6b,#1f4d3a);color:#fff;border-radius:14px 14px 0 0;font:800 14px/1 Tajawal,Tahoma,sans-serif;direction:rtl;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;box-sizing:border-box;box-shadow:0 -6px 20px rgba(15,23,42,.18)}.wb-hd.drg{cursor:grabbing}.wb-hd b{white-space:nowrap}.wb-hd small{font-weight:500;opacity:.85;font-size:12px;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.wb-hd button{flex:none;width:30px;height:26px;border:0;border-radius:8px;background:rgba(255,255,255,.18);color:#fff;font:800 15px/1 Tajawal,Tahoma,sans-serif;cursor:pointer;padding:0}.wb-hd button:hover{background:rgba(255,255,255,.34)}.wb-rz{position:fixed;z-index:2147483352;width:24px;height:24px;touch-action:none}.wb-rz[data-d=l]{cursor:nesw-resize}.wb-rz[data-d=r]{cursor:nwse-resize}.wb-rz:after{content:'';position:absolute;inset:6px;border:3px solid #1f4d3a;border-top:0;opacity:.6}.wb-rz[data-d=l]:after{border-right:0;border-radius:0 0 0 8px}.wb-rz[data-d=r]:after{border-left:0;border-radius:0 0 8px 0}.wb-hd[hidden],.wb-rz[hidden]{display:none}@media (max-width:600px){.wb-hd small{display:none}}";document.head.appendChild(cs);}
    var HD=34,hd=document.createElement("div");hd.className="wb-hd";hd.setAttribute("role","toolbar");hd.setAttribute("aria-label","شريط السبورة العائمة");
    hd.innerHTML='<span aria-hidden="true">⠿</span><b>✏️ السبورة</b><small>اسحبها إلى أي مكان • واسحب الزاوية لتغيير حجمها</small><button type="button" data-w="op" title="شفافية السبورة" aria-label="شفافية السبورة">◐</button><button type="button" data-w="fs" title="ملء الشاشة" aria-label="ملء الشاشة">⛶</button><button type="button" data-w="x" title="إغلاق السبورة" aria-label="إغلاق السبورة">×</button>';
    var rz=["l","r"].map(function(d){var g=document.createElement("div");g.className="wb-rz";g.setAttribute("data-d",d);g.title="اسحب لتغيير حجم السبورة";return g;});
    document.body.appendChild(hd);rz.forEach(function(g){document.body.appendChild(g);});
    var live=false,raf=0;
    function sv(){try{localStorage.setItem("wb:win",JSON.stringify(WIN));}catch(_){}}
    function place(){var vw=innerWidth,vh=innerHeight;
      WIN.w=Math.round(Math.max(320,Math.min(vw-8,WIN.w||Math.min(940,vw*.64))));WIN.h=Math.round(Math.max(240,Math.min(vh-HD-8,WIN.h||Math.min(660,vh*.7))));
      if(WIN.x==null)WIN.x=Math.max(4,Math.round((vw-WIN.w)/2));if(WIN.y==null)WIN.y=Math.max(HD+4,Math.round((vh-WIN.h+HD)/2));
      WIN.x=Math.round(Math.max(140-WIN.w,Math.min(vw-140,WIN.x)));WIN.y=Math.round(Math.max(HD+2,Math.min(vh-60,WIN.y)));
      var s=el.style;s.left=WIN.x+"px";s.top=WIN.y+"px";s.width=WIN.w+"px";s.height=WIN.h+"px";
      hd.style.left=WIN.x+"px";hd.style.top=(WIN.y-HD)+"px";hd.style.width=WIN.w+"px";
      rz[0].style.left=(WIN.x-6)+"px";rz[0].style.top=(WIN.y+WIN.h-18)+"px";rz[1].style.left=(WIN.x+WIN.w-18)+"px";rz[1].style.top=(WIN.y+WIN.h-18)+"px";}
    function rsz(){if(!live)return;cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){if(document.body.contains(el))resize();});}
    function mode(){var f=!!WIN.fl;el.classList.toggle("wb-win",f);hd.hidden=!f;rz.forEach(function(g){g.hidden=!f;});
      if(f){place();el.style.opacity=WIN.op||1;}else{["left","top","width","height","opacity"].forEach(function(k){el.style[k]="";});}
      if(typeof lock==="function")lock(!f);if(window.__lbarChk)window.__lbarChk();rsz();}
    /* في النافذة العائمة تُحسب نقاط الرسم من زاوية السبورة لا من زاوية الشاشة */
    ["pointerdown","pointermove","pointerup","pointercancel","wheel","click","dblclick"].forEach(function(t){el.addEventListener(t,function(e){if(!WIN.fl)return;var r=el.getBoundingClientRect(),X=e.clientX-r.left-el.clientLeft,Y=e.clientY-r.top-el.clientTop;
      try{Object.defineProperty(e,"clientX",{value:X,configurable:true});Object.defineProperty(e,"clientY",{value:Y,configurable:true});if(e.getCoalescedEvents){var g=e.getCoalescedEvents.bind(e),dx=r.left+el.clientLeft,dy=r.top+el.clientTop;Object.defineProperty(e,"getCoalescedEvents",{value:function(){return g().map(function(c){return {clientX:c.clientX-dx,clientY:c.clientY-dy,pressure:c.pressure,pointerType:c.pointerType,pointerId:c.pointerId,tiltX:c.tiltX,tiltY:c.tiltY,width:c.width,height:c.height,buttons:c.buttons,timeStamp:c.timeStamp};});},configurable:true});}}catch(_){}},true);});
    /* اختصارات لوحة المفاتيح للسبورة فقط حين يكون العمل عليها، وإلا فهي للمحتوى الذي خلفها */
    function focusIn(e){var t=e.target;wbAct=el.contains(t)||hd.contains(t)||rz.indexOf(t)>=0;}
    document.addEventListener("pointerdown",focusIn,true);
    function kcap(e){if(!WIN.fl||!wbAct||txtEl)return;var t=e.target;if(t&&t!==document.body&&!el.contains(t)&&(t.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)))return;if(el.contains(t)&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))return;e.__wb=true;e.stopPropagation();kd(e);}
    window.addEventListener("keydown",kcap,true);
    var dr=null;
    hd.addEventListener("pointerdown",function(e){if(e.button>0||e.target.closest("button"))return;dr={k:"m",sx:e.clientX,sy:e.clientY,x:WIN.x,y:WIN.y};try{hd.setPointerCapture(e.pointerId);}catch(_){}hd.classList.add("drg");e.preventDefault();});
    rz.forEach(function(g){g.addEventListener("pointerdown",function(e){if(e.button>0)return;dr={k:g.getAttribute("data-d"),sx:e.clientX,sy:e.clientY,x:WIN.x,y:WIN.y,w:WIN.w,h:WIN.h};try{g.setPointerCapture(e.pointerId);}catch(_){}e.preventDefault();});});
    function mv(e){if(!dr)return;var dx=e.clientX-dr.sx,dy=e.clientY-dr.sy;if(dr.k==="m"){WIN.x=dr.x+dx;WIN.y=dr.y+dy;place();return;}
      WIN.h=dr.h+dy;if(dr.k==="r")WIN.w=dr.w+dx;else{WIN.w=Math.max(320,dr.w-dx);WIN.x=dr.x+dr.w-WIN.w;}place();rsz();}
    function up(){if(!dr)return;var k=dr.k;dr=null;hd.classList.remove("drg");if(k!=="m")rsz();sv();}
    [hd].concat(rz).forEach(function(g){g.addEventListener("pointermove",mv);g.addEventListener("pointerup",up);g.addEventListener("pointercancel",up);});
    hd.addEventListener("dblclick",function(e){if(!e.target.closest("button"))tog();});
    hd.addEventListener("click",function(e){var b=e.target.closest("[data-w]");if(!b)return;var a=b.getAttribute("data-w");if(a==="x")return close();if(a==="fs")return tog();
      if(a==="op"){var L=[1,.85,.7,.55],i=L.indexOf(WIN.op||1);WIN.op=L[(i+1)%L.length];el.style.opacity=WIN.op;sv();toast("شفافية السبورة: "+Math.round(WIN.op*100)+"%",1300);}});
    function tog(){WIN.fl=WIN.fl?0:1;mode();sv();if(WIN.fl)toast("السبورة الآن نافذة عائمة: اسحبها من شريطها الأخضر",2200);}
    function onR(){if(WIN.fl)place();}window.addEventListener("resize",onR);
    return {on:function(){live=true;mode();},tog:tog,off:function(){hd.remove();rz.forEach(function(g){g.remove();});window.removeEventListener("resize",onR);window.removeEventListener("keydown",kcap,true);document.removeEventListener("pointerdown",focusIn,true);if(window.__lbarChk)setTimeout(window.__lbarChk,0);}};
  })();
  var cv=el.querySelector("canvas.wb-cv"),cx=cv.getContext("2d"),W=0,H=0,dpr=1,S=1,Z=1,ox=0,oy=0,tool="pen",color=null,draft=null,ptrs={},panLast=null,pinch=null,txtEl=null;
  var sel=[],drag=null,marquee=null,lasers=[],laserRAF=0,imgCache={},clip=null,erased=false;
  function bgo(){for(var i=0;i<BGS.length;i++)if(BGS[i].k===st.bg)return BGS[i];return BGS[0];}
  function page(){return st.pages[st.pg];}
  var saveWarned=false;
  function save(){var used={};st.pages.forEach(function(p){p.o.forEach(function(o){if(o.t==="img")used[o.src]=1;});});
    Object.keys(st.imgs).forEach(function(k){if(!used[k]&&!(clip&&clip.some(function(o){return o.src===k;})))delete st.imgs[k];});
    try{localStorage.setItem(store,JSON.stringify({pages:st.pages.map(function(p){return {o:p.o};}),bg:st.bg,pg:st.pg,imgs:st.imgs}));}
    catch(e){if(!saveWarned){saveWarned=true;toast("الصور كبيرة على ذاكرة المتصفح، فلن تُحفظ بعد الإغلاق. احفظ الصفحة صورة إن احتجت إليها.");}}}
  function palette(){return bgo().dark?COLS_D:COLS_L;}
  color=palette()[0];
  var tt;function toast(m,ms){var t=el.querySelector(".wb-toast");t.textContent=m;t.classList.add("show");clearTimeout(tt);tt=setTimeout(function(){t.classList.remove("show");},ms||2600);}
  function base(){return Math.min(W,H)/1000;}
  function resize(){var l=W?S2L(W/2,H/2):null;W=el.clientWidth;H=el.clientHeight;dpr=Math.min(window.devicePixelRatio||1,2.5);cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);S=base()*Z;
    if(l){ox=l[0]-W/2/S;oy=l[1]-H/2/S;}draw();}
  function S2L(x,y){return [x/S+ox,y/S+oy];}
  function L2S(x,y){return [(x-ox)*S,(y-oy)*S];}
  function setZoom(z,sx,sy){z=Math.max(.2,Math.min(6,z));if(sx==null){sx=W/2;sy=H/2;}var l=S2L(sx,sy);Z=z;S=base()*Z;ox=l[0]-sx/S;oy=l[1]-sy/S;
    el.querySelector(".wb-zv").textContent=Math.round(Z*100)+"%";draw();}
  /* ---------- الرسم ---------- */
  function drawBg(c,w,h,s,oX,oY){var b=bgo();c.fillStyle=b.bg;c.fillRect(0,0,w,h);if(!b.ln)return;var g=40*s;if(g<6)return;c.strokeStyle="#dfe4f2";c.fillStyle="#c9cfe6";c.lineWidth=Math.max(1,s*.9);
    var sx=-(((oX*s)%g)+g)%g,sy=-(((oY*s)%g)+g)%g;c.beginPath();
    if(b.ln==="lines"){for(var y=sy;y<h;y+=g){c.moveTo(0,y);c.lineTo(w,y);}c.stroke();}
    else if(b.ln==="grid"){for(var y2=sy;y2<h;y2+=g){c.moveTo(0,y2);c.lineTo(w,y2);}for(var x=sx;x<w;x+=g){c.moveTo(x,0);c.lineTo(x,h);}c.stroke();}
    else{var rr=Math.max(1.4,1.6*s);for(var y3=sy;y3<h;y3+=g)for(var x3=sx;x3<w;x3+=g){c.moveTo(x3+rr,y3);c.arc(x3,y3,rr,0,7);}c.fill();}}
  function fontOf(o,px){return "700 "+px+"px '"+(o.f||"Tajawal")+"', Tajawal, Tahoma, sans-serif";}
  function smooth(c,P,p){var a=P(p[0],p[1]);c.beginPath();c.moveTo(a[0],a[1]);if(p.length===2){c.lineTo(a[0]+.1,a[1]);return;}
    for(var i=2;i<p.length-2;i+=2){var q=P(p[i],p[i+1]),r=P((p[i]+p[i+2])/2,(p[i+1]+p[i+3])/2);c.quadraticCurveTo(q[0],q[1],r[0],r[1]);}
    var z=P(p[p.length-2],p[p.length-1]);c.lineTo(z[0],z[1]);}
  function arrowHead(c,a,b,hl){var an2=Math.atan2(b[1]-a[1],b[0]-a[0]);c.beginPath();c.moveTo(b[0],b[1]);c.lineTo(b[0]-hl*Math.cos(an2-.45),b[1]-hl*Math.sin(an2-.45));
    c.moveTo(b[0],b[1]);c.lineTo(b[0]-hl*Math.cos(an2+.45),b[1]-hl*Math.sin(an2+.45));c.stroke();}
  function getImg(id){var im=imgCache[id];if(!im&&st.imgs[id]){im=new Image();im.onload=function(){draw();};im.src=st.imgs[id];imgCache[id]=im;}return im;}
  function drawObj(c,o,s,oX,oY){var P=function(x,y){return [(x-oX)*s,(y-oY)*s];},p=o.p,i;c.save();c.strokeStyle=o.c;c.fillStyle=o.c;c.lineCap="round";c.lineJoin="round";c.lineWidth=Math.max(.6,o.w*s);
    if(o.t==="s"){var pen=o.pen;
      if(pen==="hl"){c.globalAlpha=.35;c.lineWidth=o.w*s*3;c.lineCap="butt";smooth(c,P,p);c.stroke();}
      else if(pen==="mrk"){c.globalAlpha=.9;c.lineWidth=o.w*s*1.8;c.lineCap="square";smooth(c,P,p);c.stroke();}
      else if(pen==="dsh"){c.setLineDash([o.w*s*2.4,o.w*s*2.2]);smooth(c,P,p);c.stroke();}
      else if(pen==="pcl"){c.globalAlpha=.75;c.lineWidth=Math.max(.6,o.w*s*.75);smooth(c,P,p);c.stroke();c.globalAlpha=.22;c.lineWidth=Math.max(.5,o.w*s*.35);
        var j=o.w*.32,P2=function(x,y){return P(x+j,y-j*.6);},P3=function(x,y){return P(x-j*.7,y+j*.5);};smooth(c,P2,p);c.stroke();smooth(c,P3,p);c.stroke();}
      else if(pen==="ink"){var pr=o.pr||[];if(p.length===2){var a0=P(p[0],p[1]);c.beginPath();c.arc(a0[0],a0[1],o.w*s*.5,0,7);c.fill();}
        for(i=0;i<p.length-2;i+=2){var f=((pr[i/2]||1)+(pr[i/2+1]||1))/2,a1=P(p[i],p[i+1]),b1=P(p[i+2],p[i+3]);c.lineWidth=Math.max(.6,o.w*s*f);c.beginPath();c.moveTo(a1[0],a1[1]);c.lineTo(b1[0],b1[1]);c.stroke();}}
      else if(pen==="cal"){var nx=Math.cos(-0.9)*o.w*s*.5,ny=Math.sin(-0.9)*o.w*s*.5;c.lineWidth=Math.max(.6,o.w*s*.14);
        if(p.length===2){var q0=P(p[0],p[1]);c.beginPath();c.moveTo(q0[0]+nx,q0[1]+ny);c.lineTo(q0[0]-nx,q0[1]-ny);c.stroke();}
        for(i=0;i<p.length-2;i+=2){var u=P(p[i],p[i+1]),v=P(p[i+2],p[i+3]);c.beginPath();c.moveTo(u[0]+nx,u[1]+ny);c.lineTo(v[0]+nx,v[1]+ny);c.lineTo(v[0]-nx,v[1]-ny);c.lineTo(u[0]-nx,u[1]-ny);c.closePath();c.fill();c.stroke();}}
      else{smooth(c,P,p);c.stroke();}}
    else if(o.t==="line"||o.t==="arr"||o.t==="darr"){var l1=P(p[0],p[1]),l2=P(p[2],p[3]);c.beginPath();c.moveTo(l1[0],l1[1]);c.lineTo(l2[0],l2[1]);c.stroke();
      var hl=Math.max(12,o.w*s*4);if(o.t!=="line")arrowHead(c,l1,l2,hl);if(o.t==="darr")arrowHead(c,l2,l1,hl);}
    else if(o.t==="rect"||o.t==="ell"||o.t==="tri"||o.t==="star"){var r1=P(p[0],p[1]),r2=P(p[2],p[3]),x0=Math.min(r1[0],r2[0]),y0=Math.min(r1[1],r2[1]),ww=Math.abs(r2[0]-r1[0]),hh=Math.abs(r2[1]-r1[1]);c.beginPath();
      if(o.t==="rect")c.rect(x0,y0,ww,hh);
      else if(o.t==="ell")c.ellipse(x0+ww/2,y0+hh/2,ww/2+.1,hh/2+.1,0,0,7);
      else if(o.t==="tri"){c.moveTo(x0+ww/2,y0);c.lineTo(x0+ww,y0+hh);c.lineTo(x0,y0+hh);c.closePath();}
      else{for(i=0;i<10;i++){var ang=-Math.PI/2+i*Math.PI/5,rad=i%2?.42:1;var sx2=x0+ww/2+Math.cos(ang)*ww/2*rad,sy2=y0+hh/2+Math.sin(ang)*hh/2*rad*1.05+hh*.03;if(i)c.lineTo(sx2,sy2);else c.moveTo(sx2,sy2);}c.closePath();}
      if(o.fl){c.globalAlpha=.9;c.fill();c.globalAlpha=1;}c.stroke();}
    else if(o.t==="txt"){var t1=P(p[0],p[1]);c.font=fontOf(o,o.z*s);c.textBaseline="top";try{c.direction="rtl";}catch(_){}c.textAlign="right";
      o.s.split("\n").forEach(function(ln,k){c.fillText(ln,t1[0],t1[1]+k*o.z*s*1.35);});}
    else if(o.t==="img"){var im=getImg(o.src),g1=P(p[0],p[1]);if(im&&im.complete&&im.naturalWidth)c.drawImage(im,g1[0],g1[1],p[2]*s,p[3]*s);else{c.strokeStyle="#c9cee6";c.strokeRect(g1[0],g1[1],p[2]*s,p[3]*s);}}
    c.restore();}
  function drawLasers(c,s,oX,oY){var now=performance.now();lasers.forEach(function(L){var age=(now-L.end)/1000;var a=L.end?Math.max(0,1-age/1.1):1;if(a<=0)return;
      c.save();c.globalAlpha=a;c.strokeStyle="#ff2d2d";c.shadowColor="#ff2d2d";c.shadowBlur=14;c.lineCap="round";c.lineJoin="round";c.lineWidth=Math.max(3,6*s);
      smooth(c,function(x,y){return [(x-oX)*s,(y-oY)*s];},L.p);c.stroke();c.restore();});}
  function bbox(o){var p=o.p,i,x1=Infinity,y1=Infinity,x2=-Infinity,y2=-Infinity,pad=(o.w||0)/2;
    if(o.t==="txt"){cx.save();cx.font=fontOf(o,o.z);var lines=o.s.split("\n"),mw=0;lines.forEach(function(l){mw=Math.max(mw,cx.measureText(l).width);});cx.restore();
      return [p[0]-mw,p[1],p[0],p[1]+lines.length*o.z*1.35];}
    if(o.t==="img")return [p[0],p[1],p[0]+p[2],p[1]+p[3]];
    if(o.t==="s"){pad*=o.pen==="hl"?3:o.pen==="mrk"?1.8:1;}
    for(i=0;i<p.length;i+=2){x1=Math.min(x1,p[i]);x2=Math.max(x2,p[i]);y1=Math.min(y1,p[i+1]);y2=Math.max(y2,p[i+1]);}
    return [x1-pad,y1-pad,x2+pad,y2+pad];}
  function selBox(){if(!sel.length)return null;var b=[Infinity,Infinity,-Infinity,-Infinity];sel.forEach(function(o){var q=bbox(o);b[0]=Math.min(b[0],q[0]);b[1]=Math.min(b[1],q[1]);b[2]=Math.max(b[2],q[2]);b[3]=Math.max(b[3],q[3]);});return b;}
  var HS=9;
  function handles(){var b=selBox();if(!b)return [];var a=L2S(b[0],b[1]),z=L2S(b[2],b[3]),m=6;a[0]-=m;a[1]-=m;z[0]+=m;z[1]+=m;
    return [[a[0],a[1],z[0],z[1]],[z[0],a[1],a[0],z[1]],[z[0],z[1],a[0],a[1]],[a[0],z[1],z[0],a[1]]];}/* [hx,hy, anchorX, anchorY] بالشاشة */
  function drawSel(){var b=selBox();if(!b)return;var a=L2S(b[0],b[1]),z=L2S(b[2],b[3]),m=6;cx.save();cx.strokeStyle="#3b4fc4";cx.lineWidth=1.5;cx.setLineDash([6,4]);
    cx.strokeRect(a[0]-m,a[1]-m,z[0]-a[0]+2*m,z[1]-a[1]+2*m);cx.setLineDash([]);cx.fillStyle="#fff";
    handles().forEach(function(h){cx.beginPath();cx.rect(h[0]-HS/1.2,h[1]-HS/1.2,HS*1.66,HS*1.66);cx.fill();cx.stroke();});cx.restore();}
  function drawMarquee(){if(!marquee)return;var m=marquee;cx.save();cx.fillStyle="rgba(59,79,196,.08)";cx.strokeStyle="#3b4fc4";cx.setLineDash([5,4]);cx.lineWidth=1.2;
    var x=Math.min(m[0],m[2]),y=Math.min(m[1],m[3]);cx.fillRect(x,y,Math.abs(m[2]-m[0]),Math.abs(m[3]-m[1]));cx.strokeRect(x,y,Math.abs(m[2]-m[0]),Math.abs(m[3]-m[1]));cx.restore();}
  function draw(){cx.setTransform(dpr,0,0,dpr,0,0);drawBg(cx,W,H,S,ox,oy);page().o.forEach(function(o){if(o!==editing)drawObj(cx,o,S,ox,oy);});if(draft)drawObj(cx,draft,S,ox,oy);
    drawLasers(cx,S,ox,oy);drawSel();drawMarquee();drawFrame();
    el.querySelector(".wb-pg").textContent=an(st.pg+1)+" / "+an(st.pages.length);
    el.querySelector('[data-a="u"]').disabled=!(page().u&&page().u.length);el.querySelector('[data-a="r"]').disabled=!(page().r&&page().r.length);
    el.querySelector(".wb-dot").style.background=color;placeSelBar();}
  /* منطقة التسجيل: إطار ثابت على الشاشة بنسبة الفيديو، وما خارجه لا يُسجَّل */
  function frameRect(){var ar=RECAR[rec?rec.ar:(proj.clips.length?proj.ar:cfg.ar)]||RECAR["16:9"],t=12,b=12,l=12,r=12;
    var top=el.querySelector(".wb-top"),bar=el.querySelector(".wb-bar"),ER=el.getBoundingClientRect();
    if(top){var tb=0;[].forEach.call(top.children,function(c){var q=c.getBoundingClientRect();if(q.height)tb=Math.max(tb,q.bottom-ER.top-el.clientTop);});t=Math.max(t,tb+26);}
    if(bar){var q=bar.getBoundingClientRect(),qL=q.left-ER.left-el.clientLeft,qT=q.top-ER.top-el.clientTop;if(q.height>q.width&&qL>W/2)r=Math.max(r,W-qL+10);else if(qT>H/2)b=Math.max(b,H-qT+10);}
    var aw=Math.max(80,W-l-r),ah=Math.max(60,H-t-b),w=aw,h=w*ar[1]/ar[0];if(h>ah){h=ah;w=h*ar[0]/ar[1];}
    return {x:l+(aw-w)/2,y:t+(ah-h)/2,w:w,h:h};}
  function drawFrame(){if(!cfg.frame&&!rec)return;var f=frameRect(),dark=bgo().dark;cx.save();
    if(cfg.frame){cx.fillStyle=dark?"rgba(0,0,0,.42)":"rgba(27,35,80,.16)";cx.fillRect(0,0,W,f.y);cx.fillRect(0,f.y+f.h,W,H-f.y-f.h);cx.fillRect(0,f.y,f.x,f.h);cx.fillRect(f.x+f.w,f.y,W-f.x-f.w,f.h);
      var fc=rec?"#dc2626":(dark?"#ffe066":"#3b4fc4");cx.strokeStyle=fc;cx.lineWidth=2;cx.setLineDash(rec?[]:[10,6]);cx.strokeRect(f.x,f.y,f.w,f.h);cx.setLineDash([]);
      var lb=rec?"● جارٍ التسجيل داخل الحدود":"منطقة التسجيل "+(proj.clips.length?proj.ar:cfg.ar);cx.font="700 12px Tajawal, Tahoma, sans-serif";var tw=cx.measureText(lb).width+16;
      cx.fillStyle=fc;cx.fillRect(f.x+f.w-tw,f.y-20,tw,20);cx.fillStyle=dark&&!rec?"#1b1d24":"#fff";cx.textAlign="center";cx.textBaseline="middle";cx.fillText(lb,f.x+f.w-tw/2,f.y-10);}
    else if(rec){cx.strokeStyle="rgba(220,38,38,.35)";cx.lineWidth=1;cx.setLineDash([4,6]);cx.strokeRect(f.x,f.y,f.w,f.h);}
    cx.restore();}
  var lastSelKey="";
  function placeSelBar(){var bar=el.querySelector(".wb-sel"),b=selBox(),k=sel.map(function(o){return o.id;}).join(",");if(k!==lastSelKey){lastSelKey=k;selColors(false);}
    if(!b||drag||tool!=="sel"){bar.classList.remove("show");return;}
    var a=L2S(b[0],b[1]),z=L2S(b[2],b[3]),x=Math.max(150,Math.min(W-150,(a[0]+z[0])/2)),y=a[1]-62;if(y<70)y=Math.min(H-170,z[1]+16);
    bar.style.left=x+"px";bar.style.top=y+"px";bar.classList.add("show");}
  /* ---------- التراجع والحفظ ---------- */
  function snap(){var p=page();p.u=p.u||[];p.u.push(JSON.stringify(p.o));if(p.u.length>80)p.u.shift();p.r=[];}
  function commit(o){snap();page().o.push(o);save();draw();}
  function restore(json){var ids=sel.map(function(o){return o.id;});page().o=JSON.parse(json);sel=page().o.filter(function(o){return ids.indexOf(o.id)>=0;});}
  /* ---------- الاختبار والتحويل الهندسي ---------- */
  function dist(px,py,ax,ay,bx,by){var dx=bx-ax,dy=by-ay,l=dx*dx+dy*dy,t=l?Math.max(0,Math.min(1,((px-ax)*dx+(py-ay)*dy)/l)):0;return Math.hypot(px-ax-t*dx,py-ay-t*dy);}
  function hit(o,x,y,r){var p=o.p,i;
    if(o.t==="txt"||o.t==="img"){var b=bbox(o);return x>=b[0]-r&&x<=b[2]+r&&y>=b[1]-r&&y<=b[3]+r;}
    r+=(o.w||0)/2;
    if(o.t==="s"){if(o.pen==="hl")r+=o.w;if(o.pen==="mrk")r+=o.w*.4;if(p.length===2)return Math.hypot(x-p[0],y-p[1])<r;for(i=0;i<p.length-2;i+=2)if(dist(x,y,p[i],p[i+1],p[i+2],p[i+3])<r)return true;return false;}
    if(o.t==="line"||o.t==="arr"||o.t==="darr")return dist(x,y,p[0],p[1],p[2],p[3])<r;
    var x0=Math.min(p[0],p[2]),x1=Math.max(p[0],p[2]),y0=Math.min(p[1],p[3]),y1=Math.max(p[1],p[3]);
    if(o.fl||o.t==="star"||o.t==="tri")return x>=x0-r&&x<=x1+r&&y>=y0-r&&y<=y1+r;
    if(o.t==="rect"){var c=[[x0,y0,x1,y0],[x1,y0,x1,y1],[x1,y1,x0,y1],[x0,y1,x0,y0]];return c.some(function(sg){return dist(x,y,sg[0],sg[1],sg[2],sg[3])<r;});}
    if(o.t==="ell"){var cxx=(x0+x1)/2,cyy=(y0+y1)/2,rx=(x1-x0)/2,ry=(y1-y0)/2,pr=null;for(i=0;i<=40;i++){var a=i/40*Math.PI*2,q=[cxx+rx*Math.cos(a),cyy+ry*Math.sin(a)];if(pr&&dist(x,y,pr[0],pr[1],q[0],q[1])<r)return true;pr=q;}return false;}
    return false;}
  function topAt(x,y){var o=page().o,r=10/S;for(var i=o.length-1;i>=0;i--)if(hit(o[i],x,y,r))return o[i];return null;}
  function moveObj(o,dx,dy){var p=o.p;if(o.t==="img"||o.t==="txt"){p[0]+=dx;p[1]+=dy;return;}for(var i=0;i<p.length;i+=2){p[i]+=dx;p[i+1]+=dy;}}
  function scaleObj(o,ax,ay,k){var p=o.p;if(o.t==="img"){p[0]=ax+(p[0]-ax)*k;p[1]=ay+(p[1]-ay)*k;p[2]*=k;p[3]*=k;return;}
    if(o.t==="txt"){p[0]=ax+(p[0]-ax)*k;p[1]=ay+(p[1]-ay)*k;o.z=Math.max(6,o.z*k);return;}
    for(var i=0;i<p.length;i+=2){p[i]=ax+(p[i]-ax)*k;p[i+1]=ay+(p[i+1]-ay)*k;}o.w=Math.max(.5,o.w*k);}
  /* ---------- الممحاة ---------- */
  function erase(x,y){var pg=page(),r=Math.max(10,cfg.w*1.5*Z)/S,before=pg.o.length,keep=pg.o.filter(function(o){return !hit(o,x,y,r);});
    if(keep.length!==before){if(!erased){snap();erased=true;}sel=[];pg.o=keep;draw();}}
  function erasePart(x,y){var pg=page(),r=Math.max(8,cfg.w*1.6*Z)/S,changed=false,out=[];
    pg.o.forEach(function(o){if(o.t!=="s"||!hit(o,x,y,r)){out.push(o);return;}changed=true;var seg=[],segP=[],p=o.p,pr=o.pr;
      function flush(){if(seg.length>=2){var n={t:"s",pen:o.pen,c:o.c,w:o.w,p:seg,id:nid()};if(pr)n.pr=segP;out.push(n);}seg=[];segP=[];}
      for(var i=0;i<p.length;i+=2){if(Math.hypot(p[i]-x,p[i+1]-y)<r+o.w/2){flush();}else{seg.push(p[i],p[i+1]);if(pr)segP.push(pr[i/2]);}}flush();});
    if(changed){if(!erased){snap();erased=true;}sel=[];pg.o=out;draw();}}
  /* ---------- النص ---------- */
  var editing=null;
  function closeTxt(commitIt){if(!txtEl)return;var v=txtEl.value.replace(/\s+$/,""),o=JSON.parse(txtEl.getAttribute("data-o")),orig=editing,te=txtEl;editing=null;txtEl=null;te.remove();
    if(orig){if(commitIt&&v!==orig.s){snap();if(v){orig.s=v;}else{page().o=page().o.filter(function(x){return x!==orig;});sel=[];}save();}draw();return;}
    if(commitIt&&v){o.s=v;o.id=nid();commit(o);if(tool==="sel")sel=[o];draw();}}
  function sizeTxt(){if(!txtEl)return;txtEl.style.height="auto";txtEl.style.height=txtEl.scrollHeight+"px";txtEl.style.width="auto";txtEl.style.width=Math.max(140,txtEl.scrollWidth+12)+"px";}
  function openTxt(sx,sy,obj){closeTxt(true);var o=obj?JSON.parse(JSON.stringify(obj)):null;
    if(!o){var l=S2L(sx,sy);o={t:"txt",c:color,w:2,z:cfg.tz,f:cfg.tf,p:[l[0],l[1]],s:""};}else{var q=L2S(o.p[0],o.p[1]);sx=q[0];sy=q[1];editing=obj;draw();}
    txtEl=document.createElement("textarea");txtEl.className="wb-txt";txtEl.rows=1;txtEl.value=o.s||"";txtEl.setAttribute("data-o",JSON.stringify(o));
    txtEl.style.cssText+="right:"+(W-sx-8)+"px;top:"+(sy-4)+"px;font-size:"+(o.z*S)+"px;color:"+o.c+";font-family:'"+(o.f||"Tajawal")+"',Tajawal,sans-serif";el.appendChild(txtEl);sizeTxt();try{txtEl.focus();}catch(_){}
    setTimeout(function(){if(txtEl){txtEl.focus();txtEl.setSelectionRange(txtEl.value.length,txtEl.value.length);}},30);
    txtEl.addEventListener("input",sizeTxt);
    txtEl.addEventListener("keydown",function(e){e.stopPropagation();if(e.key==="Escape")closeTxt(false);});txtEl.addEventListener("blur",function(){closeTxt(true);});}
  /* ---------- الصور ---------- */
  function addImage(file){if(!file||!/^image\//.test(file.type))return;var fr=new FileReader();fr.onload=function(){var im=new Image();im.onload=function(){
      var mx=1600,k=Math.min(1,mx/Math.max(im.width,im.height)),cw=Math.round(im.width*k),ch=Math.round(im.height*k),c=document.createElement("canvas");c.width=cw;c.height=ch;
      c.getContext("2d").drawImage(im,0,0,cw,ch);var png=/png|gif|svg/.test(file.type)&&cw*ch<1200*1200,url=c.toDataURL(png?"image/png":"image/jpeg",.88),id="i"+nid();
      st.imgs[id]=url;var vw=W/S,vh=H/S,f=Math.min(vw*.6/cw,vh*.6/ch,1/S*2),w=cw*f,h=ch*f,o={t:"img",src:id,p:[ox+vw/2-w/2,oy+vh/2-h/2,w,h],id:nid()};
      commit(o);setTool("sel");sel=[o];draw();};im.src=fr.result;};fr.readAsDataURL(file);}
  var fileIn=el.querySelector(".wb-file");fileIn.onchange=function(){addImage(fileIn.files[0]);fileIn.value="";};
  function onPaste(e){if(txtEl||(WIN.fl&&!wbAct))return;var it=(e.clipboardData&&e.clipboardData.items)||[];for(var i=0;i<it.length;i++)if(it[i].type.indexOf("image")===0){addImage(it[i].getAsFile());e.preventDefault();return;}}
  document.addEventListener("paste",onPaste);
  /* ---------- المؤشر ---------- */
  var lastTap=0,lastTapObj=null,lastPt=null;
  cv.addEventListener("pointerdown",function(e){e.preventDefault();closePops();ptrs[e.pointerId]=[e.clientX,e.clientY];try{cv.setPointerCapture(e.pointerId);}catch(_){}
    var ids=Object.keys(ptrs);
    if(ids.length===2){draft=null;erased=false;drag=null;marquee=null;var v=ids.map(function(k){return ptrs[k];});pinch={d:Math.hypot(v[0][0]-v[1][0],v[0][1]-v[1][1]),z:Z};panLast=mid();draw();return;}
    if(ids.length>2)return;
    var l=S2L(e.clientX,e.clientY),sx=e.clientX,sy=e.clientY;
    if(tool==="pan"||e.button===1){panLast=[sx,sy];cv.style.cursor="grabbing";return;}
    if(tool==="txt"){var t0=topAt(l[0],l[1]);if(t0&&t0.t==="txt")openTxt(0,0,t0);else openTxt(sx,sy);return;}
    if(tool==="er"){erased=false;erase(l[0],l[1]);return;}
    if(tool==="ep"){erased=false;erasePart(l[0],l[1]);return;}
    if(tool==="sel"){
      var hs=handles();for(var i=0;i<hs.length;i++){if(Math.abs(sx-hs[i][0])<16&&Math.abs(sy-hs[i][1])<16){var an0=S2L(hs[i][2],hs[i][3]);
        drag={m:"scale",ax:an0[0],ay:an0[1],d0:Math.hypot(l[0]-an0[0],l[1]-an0[1])||1,orig:JSON.stringify(sel),snapd:false,k:1};draw();return;}}
      var b=selBox(),inside=b&&l[0]>=b[0]-6/S&&l[0]<=b[2]+6/S&&l[1]>=b[1]-6/S&&l[1]<=b[3]+6/S,o=topAt(l[0],l[1]);
      var now=Date.now();if(o&&o.t==="txt"&&o===lastTapObj&&now-lastTap<380){lastTap=0;openTxt(0,0,o);return;}lastTap=now;lastTapObj=o;
      if(o&&sel.indexOf(o)<0&&!inside){sel=e.shiftKey?sel.concat([o]):[o];}
      else if(!o&&!inside){sel=[];marquee=[sx,sy,sx,sy];draw();return;}
      drag={m:"move",lx:l[0],ly:l[1],snapd:false};draw();return;}
    if(tool==="las"){lasers.push({p:[l[0],l[1]],end:0});runLaser();return;}
    if(tool==="shp"){draft={t:cfg.shp,c:color,w:cfg.w,p:[l[0],l[1],l[0],l[1]],fl:cfg.fill&&cfg.shp!=="line"&&cfg.shp!=="arr"&&cfg.shp!=="darr"};draw();return;}
    if(tool==="pen"){draft={t:"s",pen:cfg.pen,c:color,w:cfg.w,p:[l[0],l[1]]};if(cfg.pen==="ink"){draft.pr=[prs(e,0)];}lastPt={x:sx,y:sy,t:performance.now()};draw();}});
  function prs(e,speed){if(e.pointerType==="pen"&&e.pressure>0)return .35+e.pressure*1.15;var f=1.25-Math.min(1,speed/2.2)*.85;return f;}
  function mid(){var v=Object.keys(ptrs).map(function(k){return ptrs[k];});return [(v[0][0]+v[1][0])/2,(v[0][1]+v[1][1])/2];}
  cv.addEventListener("pointermove",function(e){if(!ptrs[e.pointerId]){if(tool==="sel")hoverCursor(e);return;}ptrs[e.pointerId]=[e.clientX,e.clientY];var ids=Object.keys(ptrs);
    if(ids.length===2&&pinch){var v=ids.map(function(k){return ptrs[k];}),d=Math.hypot(v[0][0]-v[1][0],v[0][1]-v[1][1]),m=mid();
      if(panLast){ox-=(m[0]-panLast[0])/S;oy-=(m[1]-panLast[1])/S;}panLast=m;setZoom(pinch.z*d/pinch.d,m[0],m[1]);return;}
    if(panLast&&(tool==="pan"||ids.length===1&&!draft&&!drag&&!marquee&&tool!=="er"&&tool!=="ep"&&tool!=="las")){ox-=(e.clientX-panLast[0])/S;oy-=(e.clientY-panLast[1])/S;panLast=[e.clientX,e.clientY];draw();return;}
    var l=S2L(e.clientX,e.clientY);
    if(tool==="er"){erase(l[0],l[1]);return;}
    if(tool==="ep"){erasePart(l[0],l[1]);return;}
    if(tool==="las"){var L=lasers[lasers.length-1];if(L&&!L.end){L.p.push(l[0],l[1]);}return;}
    if(drag){if(!drag.snapd){snap();drag.snapd=true;}
      if(drag.m==="move"){var dx=l[0]-drag.lx,dy=l[1]-drag.ly;sel.forEach(function(o){moveObj(o,dx,dy);});drag.lx=l[0];drag.ly=l[1];}
      else{var k=Math.max(.05,Math.hypot(l[0]-drag.ax,l[1]-drag.ay)/drag.d0),orig=JSON.parse(drag.orig);sel.forEach(function(o,i){var src=orig[i];o.p=src.p.slice();if(src.w!=null)o.w=src.w;if(src.z!=null)o.z=src.z;scaleObj(o,drag.ax,drag.ay,k);});}
      draw();return;}
    if(marquee){marquee[2]=e.clientX;marquee[3]=e.clientY;draw();return;}
    if(!draft)return;var evs=e.getCoalescedEvents?e.getCoalescedEvents():[e];
    if(draft.t==="s"){evs.forEach(function(ev){var q=S2L(ev.clientX,ev.clientY),n=draft.p.length;if(Math.hypot(q[0]-draft.p[n-2],q[1]-draft.p[n-1])>.6/Z){
        if(draft.pr){var now=performance.now(),sp=lastPt?Math.hypot(ev.clientX-lastPt.x,ev.clientY-lastPt.y)/Math.max(1,now-lastPt.t):0;lastPt={x:ev.clientX,y:ev.clientY,t:now};
          var pv=draft.pr[draft.pr.length-1],nv=prs(ev,sp);draft.pr.push(pv*.6+nv*.4);}
        draft.p.push(q[0],q[1]);}});}
    else{draft.p[2]=l[0];draft.p[3]=l[1];if(e.shiftKey&&draft.t!=="line"&&draft.t.indexOf("arr")<0){var dd=Math.max(Math.abs(l[0]-draft.p[0]),Math.abs(l[1]-draft.p[1]));draft.p[2]=draft.p[0]+dd*Math.sign(l[0]-draft.p[0]||1);draft.p[3]=draft.p[1]+dd*Math.sign(l[1]-draft.p[1]||1);}}
    draw();});
  function hoverCursor(e){var l=S2L(e.clientX,e.clientY),hs=handles();for(var i=0;i<hs.length;i++)if(Math.abs(e.clientX-hs[i][0])<16&&Math.abs(e.clientY-hs[i][1])<16){cv.style.cursor=(i%2?"nesw-resize":"nwse-resize");return;}
    cv.style.cursor=topAt(l[0],l[1])?"move":"default";}
  function up(e){if(!ptrs[e.pointerId])return;delete ptrs[e.pointerId];var n=Object.keys(ptrs).length;
    if(n<2)pinch=null;if(n===0){panLast=null;if(tool==="pan")cv.style.cursor="grab";
      if(tool==="er"||tool==="ep"){if(erased)save();erased=false;}
      if(tool==="las"){var L=lasers[lasers.length-1];if(L&&!L.end)L.end=performance.now();runLaser();}
      if(drag){var was=drag.snapd;drag=null;if(was)save();draw();}
      if(marquee){var a=S2L(Math.min(marquee[0],marquee[2]),Math.min(marquee[1],marquee[3])),b=S2L(Math.max(marquee[0],marquee[2]),Math.max(marquee[1],marquee[3]));marquee=null;
        if(b[0]-a[0]>2/S||b[1]-a[1]>2/S)sel=page().o.filter(function(o){var q=bbox(o);return q[0]<b[0]&&q[2]>a[0]&&q[1]<b[1]&&q[3]>a[1];});draw();}
      if(draft){var d=draft;draft=null;d.id=nid();if(d.t==="s"||Math.hypot(d.p[2]-d.p[0],d.p[3]-d.p[1])>3/S)commit(d);else draw();}}}
  cv.addEventListener("pointerup",up);cv.addEventListener("pointercancel",up);
  cv.addEventListener("wheel",function(e){e.preventDefault();if(e.ctrlKey||e.metaKey){setZoom(Z*Math.exp(-e.deltaY*.0022),e.clientX,e.clientY);}else{ox+=e.deltaX/S;oy+=e.deltaY/S;draw();}},{passive:false});
  function runLaser(){if(laserRAF)return;(function f(){var now=performance.now();lasers=lasers.filter(function(L){return !L.end||now-L.end<1100;});draw();
      laserRAF=lasers.length?requestAnimationFrame(f):0;})();}
  /* ---------- أدوات التحديد ---------- */
  /* لوحة ألوان صغيرة تحت شريط العنصر المحدد */
  function selColors(show){var box=el.querySelector(".wb-selcol");if(!show){box.classList.remove("show");return;}
    box.innerHTML=palette().map(function(c){return '<button data-sc="'+c+'" style="background:'+c+'" aria-label="لون"></button>';}).join("")+'<label title="لون مخصص"><input type="color" value="'+(/^#[0-9a-f]{6}$/i.test(color)?color:"#3b4fc4")+'"></label>';
    var ci=box.querySelector("input");ci.oninput=function(){recolor(ci.value,true);};ci.onchange=function(){recolor(ci.value);};box.classList.add("show");}
  var recolorSnap=false;
  function recolor(c,live){if(!sel.length)return;if(!recolorSnap){snap();recolorSnap=true;}sel.forEach(function(o){if(o.t!=="img")o.c=c;});color=c;if(!live){recolorSnap=false;save();}draw();}
  function selAct(a){if(!sel.length)return;if(a==="col"){selColors(!el.querySelector(".wb-selcol").classList.contains("show"));return;}var pg=page();snap();
    if(a==="del"){pg.o=pg.o.filter(function(o){return sel.indexOf(o)<0;});sel=[];}
    else if(a==="dup"){var cp=sel.map(function(o){var n=JSON.parse(JSON.stringify(o));n.id=nid();moveObj(n,24/S,24/S);return n;});pg.o=pg.o.concat(cp);sel=cp;}
    else if(a==="big"||a==="small"){var b=selBox(),k=a==="big"?1.15:1/1.15,ax=(b[0]+b[2])/2,ay=(b[1]+b[3])/2;sel.forEach(function(o){scaleObj(o,ax,ay,k);});}

    else if(a==="up"){pg.o=pg.o.filter(function(o){return sel.indexOf(o)<0;}).concat(sel);toast("صار العنصر فوق العناصر الأخرى",1300);}
    else if(a==="down"){pg.o=sel.concat(pg.o.filter(function(o){return sel.indexOf(o)<0;}));toast("صار العنصر خلف العناصر الأخرى",1300);}
    save();draw();}
  /* ---------- الواجهة ---------- */
  function closePops(){el.querySelectorAll(".wb-pop").forEach(function(p){p.classList.remove("open");});}
  function openPop(n){var pop=el.querySelector('[data-p="'+n+'"]'),was=pop.classList.contains("open");closePops();if(!was){syncUI();pop.classList.add("open");}}
  function setTool(t){if(t==="img"){fileIn.click();return;}tool=t;closeTxt(true);if(t!=="sel"){sel=[];}
    el.querySelectorAll("[data-t]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-t")===t);});
    el.querySelector('[data-t="pen"]').innerHTML=wico(cfg.pen)+'<i class="wb-more"></i>';el.querySelector('[data-t="shp"]').innerHTML=wico(cfg.shp)+'<i class="wb-more"></i>';
    cv.style.cursor=t==="pan"?"grab":t==="txt"?"text":t==="sel"?"default":"crosshair";draw();}
  function previewPen(){var pc=el.querySelector('[data-p="pens"] .wb-prev canvas');if(!pc)return;var g=pc.getContext("2d");g.clearRect(0,0,300,44);
    var pts=[];for(var i=0;i<=40;i++){pts.push(20+i*6.5,22+Math.sin(i/40*Math.PI*2)*10);}var o={t:"s",pen:cfg.pen==="las"?"pen":cfg.pen,c:cfg.pen==="las"?"#ff2d2d":color,w:Math.min(cfg.w,30),p:pts};
    if(o.pen==="ink"){o.pr=pts.filter(function(_,k){return k%2===0;}).map(function(_,k){return .5+Math.abs(Math.sin(k/6))*.8;});}drawObj(g,o,.5,0,0);}
  function syncUI(){var pal=palette();el.querySelector(".wb-cols").innerHTML=pal.map(function(c){return '<button data-c="'+c+'" style="background:'+c+'" class="'+(c===color?'on':'')+'" aria-label="لون"></button>';}).join("")+
      '<label title="لون مخصص"><input type="color" value="'+(/^#[0-9a-f]{6}$/i.test(color)?color:"#3b4fc4")+'"></label>';
    var ci=el.querySelector('.wb-cols input');ci.oninput=function(){color=ci.value;draw();};
    el.querySelectorAll("[data-r]").forEach(function(r){r.value=cfg[r.getAttribute("data-r")];});
    el.querySelectorAll("[data-o]").forEach(function(o){o.textContent=an(cfg[o.getAttribute("data-o")]);});
    el.querySelectorAll("[data-pen]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-pen")===cfg.pen);});
    el.querySelectorAll("[data-shp]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-shp")===cfg.shp);});
    el.querySelectorAll("[data-tf]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-tf")===cfg.tf);});
    el.querySelectorAll("[data-q]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-q")===(proj.clips.length?proj.q:cfg.q));});
    el.querySelectorAll("[data-ar]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-ar")===(proj.clips.length?proj.ar:cfg.ar));});
    var fb=el.querySelector(".wb-frb");if(fb)fb.classList.toggle("on",!!cfg.frame);
    el.querySelectorAll("[data-bg]").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-bg")===st.bg);});
    el.querySelectorAll("[data-k]").forEach(function(c){c.checked=!!cfg[c.getAttribute("data-k")];});previewPen();}
  el.addEventListener("input",function(e){var r=e.target.closest("[data-r]");if(!r)return;var k=r.getAttribute("data-r");cfg[k]=+r.value;saveCfg();
    el.querySelectorAll('[data-o="'+k+'"]').forEach(function(o){o.textContent=an(cfg[k]);});el.querySelectorAll('[data-r="'+k+'"]').forEach(function(x){if(x!==r)x.value=cfg[k];});
    if(k==="tz"&&sel.length&&sel.every(function(o){return o.t==="txt";})){sel.forEach(function(o){o.z=cfg.tz;});save();draw();}
    if(k==="tz"&&txtEl){var o=JSON.parse(txtEl.getAttribute("data-o"));o.z=cfg.tz;txtEl.setAttribute("data-o",JSON.stringify(o));txtEl.style.fontSize=(o.z*S)+"px";if(editing)editing.z=cfg.tz;sizeTxt();}
    previewPen();});
  el.addEventListener("change",function(e){var c=e.target.closest("[data-k]");if(!c)return;cfg[c.getAttribute("data-k")]=c.checked;saveCfg();if(c.getAttribute("data-k")==="frame"){syncUI();draw();}});
  function close(){if(rec){toast("أنهِ التسجيل أولًا (زر الإيقاف الأحمر) ليُحفظ الفيديو.",3200);return;}if(exp)return;
    if(ed.classList.contains("show")){closeEd();return;}
    if(proj.clips.length&&proj.dirty&&!confirm("لديك فيديو لم تُصدِّره بعد، وسيُحذف عند إغلاق السبورة. هل تريد الإغلاق؟"))return;closeTxt(true);save();window.removeEventListener("resize",rs);document.removeEventListener("keydown",kd);document.removeEventListener("paste",onPaste);
    el.remove();WINX.off();if(typeof lock==="function")lock(false);}
  function kd(e){if(WIN.fl&&!e.__wb)return;if(txtEl)return;var k=e.key.toLowerCase(),mod=e.ctrlKey||e.metaKey;
    if(ed.classList.contains("show")){if(e.key==="Escape")edAct("close");if(e.key===" "){e.preventDefault();edAct("play");}return;}
    if(e.key==="Escape"){if(el.querySelector(".wb-pop.open")){closePops();return;}if(sel.length){sel=[];draw();return;}close();return;}
    if(mod&&k==="z"){e.preventDefault();act(e.shiftKey?"r":"u");return;}
    if(mod&&k==="y"){e.preventDefault();act("r");return;}
    if((e.key==="Delete"||e.key==="Backspace")&&sel.length){e.preventDefault();selAct("del");return;}
    if(mod&&k==="d"&&sel.length){e.preventDefault();selAct("dup");return;}
    if(mod&&k==="c"&&sel.length){clip=JSON.parse(JSON.stringify(sel));return;}
    if(mod&&k==="v"&&clip){e.preventDefault();snap();var cp=clip.map(function(o){var n=JSON.parse(JSON.stringify(o));n.id=nid();moveObj(n,24/S,24/S);return n;});clip=JSON.parse(JSON.stringify(cp));page().o=page().o.concat(cp);setTool("sel");sel=cp;save();draw();return;}
    if(mod&&k==="a"){e.preventDefault();setTool("sel");sel=page().o.slice();draw();return;}
    if(sel.length&&/^arrow/.test(k)){e.preventDefault();var st2=(e.shiftKey?20:3)/S;snap();sel.forEach(function(o){moveObj(o,k==="arrowleft"?-st2:k==="arrowright"?st2:0,k==="arrowup"?-st2:k==="arrowdown"?st2:0);});save();draw();return;}
    if(!mod&&!e.altKey){var map={v:"sel",p:"pen",t:"txt",e:"er",h:"pan",l:"las"};if(map[k]){if(k==="l"){cfg.pen="las";setTool("pen");}else setTool(map[k]);}}}
  document.addEventListener("keydown",kd);
  function act(a){var p=page();
    if(a==="x")return close();
    if(a==="win"){WINX.tog();return;}
    if(a==="u"&&p.u&&p.u.length){p.r=p.r||[];p.r.push(JSON.stringify(p.o));restore(p.u.pop());save();draw();}
    if(a==="r"&&p.r&&p.r.length){p.u=p.u||[];p.u.push(JSON.stringify(p.o));restore(p.r.pop());save();draw();}
    if(a==="wipe"){if(!p.o.length){toast("السبورة فارغة بالفعل",1600);}else{snap();p.o=[];sel=[];save();draw();toast("مُسحت السبورة كاملة – اضغط ↶ تراجع لاستعادتها",2600);}}
    if(a==="c"&&p.o.length&&confirm("مسح كل ما في هذه الصفحة؟")){snap();p.o=[];sel=[];save();draw();}
    if(a==="pp"&&st.pg>0){st.pg--;sel=[];ox=oy=0;save();draw();}
    if(a==="pn"&&st.pg<st.pages.length-1){st.pg++;sel=[];ox=oy=0;save();draw();}
    if(a==="pa"){st.pages.splice(st.pg+1,0,{o:[]});st.pg++;sel=[];ox=oy=0;save();draw();}
    if(a==="zi")setZoom(Z*1.25);if(a==="zo")setZoom(Z/1.25);if(a==="z1"){setZoom(1);}
    if(a==="s"){var c=document.createElement("canvas"),k=2;c.width=W*k;c.height=H*k;var g=c.getContext("2d");g.scale(k,k);drawBg(g,W,H,S,ox,oy);p.o.forEach(function(o){drawObj(g,o,S,ox,oy);});
      var aEl=document.createElement("a");aEl.download=(title||"السبورة")+" - صفحة "+(st.pg+1)+".png";aEl.href=c.toDataURL("image/png");document.body.appendChild(aEl);aEl.click();aEl.remove();}
    if(a==="col"||a==="bgp"||a==="recp")openPop(a);
    if(a==="rstart"){closePops();startRec();}
    if(a==="rpause")pauseRec();
    if(a==="rstop")stopRec();
    if(a==="frame"){cfg.frame=!cfg.frame;saveCfg();syncUI();draw();toast(cfg.frame?"إظهار حدود منطقة التسجيل":"أُخفيت الحدود — التسجيل يبقى لما داخلها",1800);}
    if(a==="ed")openEd();}
  el.addEventListener("click",function(e){var sc=e.target.closest("[data-sc]");if(sc){recolor(sc.getAttribute("data-sc"));return;}var sb=e.target.closest("[data-sa]");if(sb){selAct(sb.getAttribute("data-sa"));return;}
    if(e.target.closest(".wb-ed"))return;var b=e.target.closest("[data-a],[data-t],[data-c],[data-bg],[data-pen],[data-shp],[data-tf],[data-q],[data-ar]");if(!b)return;
    if(b.hasAttribute("data-t")){var t=b.getAttribute("data-t");if((t==="pen"||t==="shp")&&tool===t){openPop(t==="pen"?"pens":"shps");return;}setTool(t);return;}
    if(b.hasAttribute("data-pen")){cfg.pen=b.getAttribute("data-pen");saveCfg();setTool("pen");syncUI();return;}
    if(b.hasAttribute("data-shp")){cfg.shp=b.getAttribute("data-shp");saveCfg();setTool("shp");syncUI();return;}
    if(b.hasAttribute("data-tf")){cfg.tf=b.getAttribute("data-tf");saveCfg();syncUI();loadWF(cfg.tf);
      if(sel.length&&sel.every(function(o){return o.t==="txt";})){snap();sel.forEach(function(o){o.f=cfg.tf;});save();draw();}return;}
    if(b.hasAttribute("data-q")){if(proj.clips.length){toast("الدقة ثابتة لكل مقاطع هذا الفيديو.");return;}cfg.q=b.getAttribute("data-q");saveCfg();syncUI();return;}
    if(b.hasAttribute("data-ar")){if(proj.clips.length){toast("شكل الإطار ثابت لكل مقاطع هذا الفيديو.");return;}cfg.ar=b.getAttribute("data-ar");saveCfg();syncUI();draw();return;}
    if(b.hasAttribute("data-c")){color=b.getAttribute("data-c");if(sel.length&&tool==="sel"){recolor(color);syncUI();return;}if(tool==="er"||tool==="ep"||tool==="pan"||tool==="img")setTool("pen");syncUI();draw();return;}
    if(b.hasAttribute("data-bg")){var wasDark=!!bgo().dark;st.bg=b.getAttribute("data-bg");if(!!bgo().dark!==wasDark)color=palette()[0];save();syncUI();draw();return;}
    act(b.getAttribute("data-a"));});
  function loadWF(f){if(f!=="Noto Naskh Arabic"&&f!=="Cairo")return;var id="wbf-"+f.replace(/\s/g,"");if(document.getElementById(id))return;var l=document.createElement("link");l.id=id;l.rel="stylesheet";
    l.href="https://fonts.googleapis.com/css2?family="+f.replace(/\s/g,"+")+":wght@700&display=swap";l.onload=function(){setTimeout(draw,300);};document.head.appendChild(l);}
  loadWF(cfg.tf);
  /* ---------- تسجيل الفيديو بالصوت ---------- */
  var rec=null;
  function pickMime(){var L=['video/mp4;codecs="avc1.640033,mp4a.40.2"','video/mp4;codecs=avc1,mp4a.40.2','video/mp4;codecs=avc1,opus','video/mp4','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];
    for(var i=0;i<L.length;i++)try{if(MediaRecorder.isTypeSupported(L[i]))return L[i];}catch(e){}return "";}
  function fmt(ms){var s=Math.floor(ms/1000),m=Math.floor(s/60);s%=60;var h=Math.floor(m/60);m%=60;return (h?h+":"+(m<10?"0":""):"")+(m<10&&!h?"0":"")+m+":"+(s<10?"0":"")+s;}
  /* ---------- مشروع الفيديو (المقاطع المسجّلة) ---------- */
  var proj={clips:[],sel:0,ar:"16:9",q:"1080",dirty:false},ed=el.querySelector(".wb-ed"),ev=ed.querySelector(".ed-v"),eseek=ed.querySelector(".ed-seek"),pv=null,exp=null;
  function renderRec(){var R=rec,g=R.g,VW=R.VW,VH=R.VH,f=frameRect(),sv=VW/(f.w/S),offX=ox+f.x/S,offY=oy+f.y/S;
    g.setTransform(1,0,0,1,0,0);drawBg(g,VW,VH,sv,offX,offY);page().o.forEach(function(o){if(o!==editing)drawObj(g,o,sv,offX,offY);});if(draft)drawObj(g,draft,sv,offX,offY);
    if(txtEl){var o=JSON.parse(txtEl.getAttribute("data-o"));o.s=txtEl.value;if(o.s)drawObj(g,o,sv,offX,offY);}
    drawLasers(g,sv,offX,offY);
    if(R.camV&&R.camV.readyState>=2){var d=Math.round(Math.min(VW,VH)*.26),x=Math.round(VW*.025),y=VH-d-Math.round(VH*.04);g.save();g.beginPath();g.arc(x+d/2,y+d/2,d/2,0,7);g.closePath();g.clip();
      var vw=R.camV.videoWidth,vh=R.camV.videoHeight,sq=Math.min(vw,vh);g.translate(x+d,y);g.scale(-1,1);g.drawImage(R.camV,(vw-sq)/2,(vh-sq)/2,sq,sq,0,0,d,d);g.restore();
      g.save();g.lineWidth=Math.max(4,VH*.006);g.strokeStyle="#fff";g.beginPath();g.arc(x+d/2,y+d/2,d/2,0,7);g.stroke();g.restore();}}
  function tick(){if(!rec)return;renderRec();
    var t=rec.acc+(rec.paused?0:performance.now()-rec.t0);el.querySelector(".wb-rt").textContent=fmt(t);rec.raf=requestAnimationFrame(tick);}
  function startRec(){if(rec)return;if(!window.MediaRecorder||!HTMLCanvasElement.prototype.captureStream){toast("المتصفح لا يدعم تسجيل الفيديو. استخدم Chrome أو Edge أو Safari حديثًا.",3600);return;}
    if(!proj.clips.length){proj.ar=cfg.ar;proj.q=cfg.q;}
    var q=recDims(proj.q,proj.ar),rc=document.createElement("canvas");rc.width=q[0];rc.height=q[1];
    rec={VW:q[0],VH:q[1],br:q[2],ar:proj.ar,cv:rc,g:rc.getContext("2d"),chunks:[],acc:0,t0:performance.now(),paused:false,starting:true};draw();
    var want={audio:cfg.mic?{echoCancellation:true,noiseSuppression:true,autoGainControl:true}:false,video:cfg.cam?{width:{ideal:640},height:{ideal:480},facingMode:"user"}:false};
    var go=function(ms){if(!rec)return;var vs=rc.captureStream(30),tracks=vs.getVideoTracks();rec.track=tracks[0];rec.media=ms;
      if(ms){ms.getAudioTracks().forEach(function(t){tracks.push(t);});if(ms.getVideoTracks().length){var v=document.createElement("video");v.muted=true;v.playsInline=true;v.srcObject=new MediaStream(ms.getVideoTracks());v.play().catch(function(){});rec.camV=v;}}
      var mime=pickMime(),opt={videoBitsPerSecond:rec.br,audioBitsPerSecond:192000};if(mime)opt.mimeType=mime;
      try{rec.mr=new MediaRecorder(new MediaStream(tracks),opt);}catch(e){try{rec.mr=new MediaRecorder(new MediaStream(tracks));}catch(e2){toast("تعذّر بدء التسجيل على هذا المتصفح.");cleanRec();return;}}
      rec.mime=rec.mr.mimeType||mime||"video/webm";
      rec.mr.ondataavailable=function(ev2){if(ev2.data&&ev2.data.size)rec.chunks.push(ev2.data);};
      rec.mr.onstop=finishRec;rec.mr.start(1000);rec.t0=performance.now();rec.starting=false;el.classList.add("recording");el.classList.remove("rec-paused");
      el.querySelector('[data-a="rpause"]').innerHTML=wico("pause");tick();draw();toast("🔴 بدأ التسجيل — يُسجَّل ما داخل الحدود فقط",1600);};
    if(want.audio||want.video){if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){toast("لا يمكن الوصول إلى المايكروفون هنا؛ سيُسجَّل الفيديو بلا صوت.",3200);go(null);return;}
      navigator.mediaDevices.getUserMedia(want).then(go).catch(function(){if(want.video&&want.audio){navigator.mediaDevices.getUserMedia({audio:want.audio}).then(function(m){toast("لم يُسمح بالكاميرا؛ سيُسجَّل الصوت فقط.",3000);go(m);}).catch(function(){toast("لم يُسمح بالمايكروفون؛ سيُسجَّل الفيديو بلا صوت.",3200);go(null);});}
        else{toast(want.audio?"لم يُسمح بالمايكروفون؛ سيُسجَّل الفيديو بلا صوت.":"لم يُسمح بالكاميرا.",3200);go(null);}});}
    else go(null);}
  function pauseRec(){if(!rec||!rec.mr)return;if(!rec.paused){try{rec.mr.pause();}catch(e){}rec.acc+=performance.now()-rec.t0;rec.paused=true;el.classList.add("rec-paused");el.querySelector('[data-a="rpause"]').innerHTML=wico("play");toast("⏸️ توقّف التسجيل مؤقتًا — اضغط ▶ للإكمال",1800);}
    else{try{rec.mr.resume();}catch(e){}rec.t0=performance.now();rec.paused=false;el.classList.remove("rec-paused");el.querySelector('[data-a="rpause"]').innerHTML=wico("pause");toast("🔴 استُؤنف التسجيل",1200);}}
  function stopRec(){if(!rec||!rec.mr)return;try{if(rec.paused)rec.mr.resume();}catch(e){}try{rec.mr.requestData();}catch(e){}try{rec.mr.stop();}catch(e){finishRec();}}
  function cleanRec(){if(!rec)return;cancelAnimationFrame(rec.raf);if(rec.media)rec.media.getTracks().forEach(function(t){t.stop();});if(rec.track)rec.track.stop();rec=null;el.classList.remove("recording","rec-paused");draw();}
  function finishRec(){if(!rec)return;var R=rec,dur=(R.acc+(R.paused?0:performance.now()-R.t0))/1000,th="";
    try{var tc=document.createElement("canvas"),tw=240;tc.width=tw;tc.height=Math.round(tw*R.VH/R.VW);tc.getContext("2d").drawImage(R.cv,0,0,tc.width,tc.height);th=tc.toDataURL("image/jpeg",.7);}catch(e){}
    cleanRec();if(!R.chunks.length){toast("لم يُسجَّل شيء.");return;}
    var blob=new Blob(R.chunks,{type:R.mime.split(";")[0]});
    proj.clips.push({id:nid(),blob:blob,url:URL.createObjectURL(blob),mime:R.mime,dur:dur,in:0,out:dur,w:R.VW,h:R.VH,th:th,br:R.br});proj.sel=proj.clips.length-1;proj.dirty=true;
    el.querySelector(".wb-edb").hidden=false;openEd();}
  /* ---------- مونتاج الفيديو: قصّ المقاطع وتقسيمها وترتيبها ثم تصدير فيديو واحد ---------- */
  function fs(x){x=Math.max(0,x||0);var m=Math.floor(x/60),s2=Math.floor(x%60),ds=Math.floor((x*10)%10);return m+":"+(s2<10?"0":"")+s2+"."+ds;}
  function cur(){return proj.clips[proj.sel];}
  function total(){return proj.clips.reduce(function(a,c){return a+Math.max(0,c.out-c.in);},0);}
  function openEd(){closePops();ed.classList.add("show");drawTL();loadClip();}
  function closeEd(){stopPv();ev.pause();ed.classList.remove("show");}
  /* ملفات WebM من المتصفح لا تحمل مدتها؛ هذه الحيلة تجعل المتصفح يحسبها ليعمل التنقّل */
  function whenReady(v,url,cb){if(v.getAttribute("data-u")===url&&v.readyState>=1&&isFinite(v.duration)){cb();return;}
    v.setAttribute("data-u",url);v.onloadedmetadata=function(){v.onloadedmetadata=null;if(!isFinite(v.duration)){v.ondurationchange=function(){if(isFinite(v.duration)){v.ondurationchange=null;cb();}};v.currentTime=1e7;}else cb();};v.src=url;}
  function loadClip(keepT){var c=cur();if(!c){ev.removeAttribute("src");ev.removeAttribute("data-u");try{ev.load();}catch(e){}updSeek();return;}
    whenReady(ev,c.url,function(){ev.currentTime=keepT!=null?keepT:c.in;updSeek();});updSeek();}
  function updSeek(){var c=cur(),tr=ed.querySelector(".ed-tr");tr.style.cssText=c?"left:"+(c.in/c.dur*100)+"%;right:"+Math.max(0,100-c.out/c.dur*100)+"%":"display:none";
    if(c&&document.activeElement!==eseek)eseek.value=Math.round(Math.min(1,(ev.currentTime||0)/c.dur)*1000);
    ed.querySelector(".ed-time").textContent=c?fs(Math.min(ev.currentTime||0,c.dur))+" / "+fs(c.dur):"0:00";
    ed.querySelector(".ed-pl").textContent=ev.paused?"▶":"⏸";
    ed.querySelector(".ed-info").textContent=proj.clips.length?("عدد المقاطع "+an(proj.clips.length)+" • مدة الفيديو النهائي "+fs(total())+" • الدقة "+cur().w+"×"+cur().h+" • الجزء الملوّن في الشريط هو ما سيبقى في الفيديو"):"لا توجد مقاطع بعد.";}
  function drawTL(){var tl=ed.querySelector(".ed-tl"),T=total()||1;
    tl.innerHTML=proj.clips.map(function(c,i){var d=Math.max(0,c.out-c.in);return '<button class="ed-clip'+(i===proj.sel?' on':'')+'" data-ci="'+i+'" style="flex-grow:'+Math.max(.6,d/T*10).toFixed(2)+'">'+
      (c.th?'<img src="'+c.th+'" alt="">':'')+'<span>'+an(i+1)+' • '+fs(d)+'</span></button>';}).join("")||'<p class="ed-empty">سجّل مقطعًا ليظهر هنا.</p>';
    ed.querySelectorAll(".ed-tools button,[data-ea=export],[data-ea=playall]").forEach(function(b){b.disabled=!proj.clips.length;});updSeek();}
  ev.addEventListener("timeupdate",function(){var c=cur();if(c&&!pv&&!ev.paused&&ev.currentTime>=c.out-0.03){ev.pause();ev.currentTime=c.out;}updSeek();});
  ev.addEventListener("play",updSeek);ev.addEventListener("pause",updSeek);ev.addEventListener("seeked",updSeek);
  eseek.addEventListener("input",function(){var c=cur();if(!c)return;stopPv();ev.currentTime=eseek.value/1000*c.dur;updSeek();});
  function stopPv(){if(pv){pv=null;ev.pause();ed.querySelector('[data-ea="playall"]').textContent="▶ معاينة الفيديو كاملًا";}}
  function playAll(){if(pv){stopPv();return;}var segs=proj.clips.filter(function(c){return c.out-c.in>0.05;});if(!segs.length)return;var me={i:0};pv=me;ed.querySelector('[data-ea="playall"]').textContent="⏹ إيقاف المعاينة";
    (function next(){if(pv!==me)return;if(me.i>=segs.length){stopPv();return;}var c=segs[me.i];proj.sel=proj.clips.indexOf(c);drawTL();
      whenReady(ev,c.url,function(){if(pv!==me)return;ev.currentTime=c.in;ev.play().catch(function(){});
        var w=function(){if(pv!==me){ev.removeEventListener("timeupdate",w);return;}if(ev.currentTime>=c.out-0.05||ev.ended){ev.removeEventListener("timeupdate",w);me.i++;next();}};ev.addEventListener("timeupdate",w);});})();}
  function edAct(a){var c=cur(),t=ev.currentTime||0;
    if(a==="close"){if(exp)return;closeEd();return;}
    if(a==="play"){stopPv();if(!c)return;if(ev.paused){if(t>=c.out-0.05||t<c.in)ev.currentTime=c.in;ev.play().catch(function(){});}else ev.pause();return;}
    if(a==="playall"){playAll();return;}
    if(a==="more"){closeEd();startRec();return;}
    if(a==="export"){exportAll();return;}
    if(a==="cancel"){if(exp)exp.cancel=true;return;}
    if(!c)return;stopPv();
    if(a==="setin"){if(t>=c.out-0.2){toast("اختر نقطة قبل نهاية المقطع.");return;}c.in=Math.max(0,t);}
    else if(a==="setout"){if(t<=c.in+0.2){toast("اختر نقطة بعد بداية المقطع.");return;}c.out=Math.min(c.dur,t);}
    else if(a==="reset"){c.in=0;c.out=c.dur;}
    else if(a==="split"){if(t<=c.in+0.2||t>=c.out-0.2){toast("حرّك المؤشر إلى نقطة داخل المقطع ثم اضغط «قصّ».",2600);return;}
      var n={};for(var k in c)n[k]=c[k];n.id=nid();n.in=t;c.out=t;proj.clips.splice(proj.sel+1,0,n);toast("✂️ قُسِّم المقطع إلى جزأين",1400);}
    else if(a==="del"){if(!confirm("حذف هذا المقطع من الفيديو؟"))return;var gone=proj.clips.splice(proj.sel,1)[0];if(!proj.clips.some(function(x){return x.url===gone.url;}))try{URL.revokeObjectURL(gone.url);}catch(e){}
      proj.sel=Math.max(0,Math.min(proj.sel,proj.clips.length-1));if(!proj.clips.length)el.querySelector(".wb-edb").hidden=true;}
    else if(a==="left"&&proj.sel>0){proj.clips.splice(proj.sel-1,0,proj.clips.splice(proj.sel,1)[0]);proj.sel--;}
    else if(a==="right"&&proj.sel<proj.clips.length-1){proj.clips.splice(proj.sel+1,0,proj.clips.splice(proj.sel,1)[0]);proj.sel++;}
    proj.dirty=true;drawTL();loadClip(a==="setout"?Math.max(c.in,t-0.01):a==="split"?t:a==="setin"?t:null);}
  ed.addEventListener("click",function(e){var ci=e.target.closest("[data-ci]");if(ci){stopPv();proj.sel=+ci.getAttribute("data-ci");drawTL();loadClip();return;}
    var b=e.target.closest("[data-ea]");if(b&&!b.disabled)edAct(b.getAttribute("data-ea"));});
  function vname(ext){var d=new Date();return (title||"السبورة")+" – "+d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+d.getHours()+"-"+(d.getMinutes()<10?"0":"")+d.getMinutes()+"."+ext;}
  function download(blob,mime){var u=URL.createObjectURL(blob),a=document.createElement("a");a.href=u;a.download=vname(/mp4/.test(mime)?"mp4":"webm");document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(u);},120000);}
  /* التصدير: تشغيل المقاطع المقصوصة بالترتيب وتسجيلها في فيديو واحد بنفس الدقة والصوت */
  function exportAll(){var segs=proj.clips.filter(function(c){return c.out-c.in>0.05;});if(!segs.length||exp)return;stopPv();ev.pause();
    if(segs.length===1&&segs[0].in<0.05&&segs[0].out>segs[0].dur-0.05){download(segs[0].blob,segs[0].mime);proj.dirty=false;toast("✅ حُفظ الفيديو على جهازك",2000);return;}
    var W0=segs[0].w,H0=segs[0].h,oc=document.createElement("canvas");oc.width=W0;oc.height=H0;var g=oc.getContext("2d"),ac=null,dest=null,mr,chunks=[],T=segs.reduce(function(a,c){return a+c.out-c.in;},0),done=0;
    var vv=document.createElement("video");vv.playsInline=true;vv.preload="auto";
    try{ac=new (window.AudioContext||window.webkitAudioContext)();dest=ac.createMediaStreamDestination();ac.createMediaElementSource(vv).connect(dest);if(ac.resume)ac.resume();}catch(e){ac=null;dest=null;}
    var tracks=oc.captureStream(30).getVideoTracks();if(dest)dest.stream.getAudioTracks().forEach(function(t){tracks.push(t);});
    var mime=pickMime(),opt={videoBitsPerSecond:segs[0].br||16e6,audioBitsPerSecond:192000};if(mime)opt.mimeType=mime;
    try{mr=new MediaRecorder(new MediaStream(tracks),opt);}catch(e){toast("تعذّر التصدير على هذا المتصفح.");return;}
    exp={cancel:false};ed.classList.add("busy");var bar=ed.querySelector(".ed-bar i"),pct=ed.querySelector(".ed-pct");bar.style.width="0";pct.textContent="٠٪";
    mr.ondataavailable=function(e){if(e.data&&e.data.size)chunks.push(e.data);};
    var raf=0;(function paint(){if(!exp)return;if(vv.readyState>=2&&vv.videoWidth){var k=Math.min(W0/vv.videoWidth,H0/vv.videoHeight),dw=vv.videoWidth*k,dh=vv.videoHeight*k;g.fillStyle="#000";g.fillRect(0,0,W0,H0);g.drawImage(vv,(W0-dw)/2,(H0-dh)/2,dw,dh);}raf=requestAnimationFrame(paint);})();
    var started=false,i=0;
    function fin(ok){cancelAnimationFrame(raf);vv.pause();exp=null;ed.classList.remove("busy");
      if(!ok||!started){try{mr.stop();}catch(e){}try{if(ac)ac.close();}catch(e){}if(!ok)toast("أُلغي التصدير.");return;}
      mr.onstop=function(){try{if(ac)ac.close();}catch(e){}var out=new Blob(chunks,{type:(mr.mimeType||mime||"video/webm").split(";")[0]});download(out,mr.mimeType||mime);proj.dirty=false;toast("✅ صُدِّر الفيديو النهائي وحُفظ على جهازك",2800);};
      try{mr.resume();}catch(e){}try{mr.requestData();}catch(e){}try{mr.stop();}catch(e){}}
    function seg(){if(!exp)return;if(exp.cancel)return fin(false);if(i>=segs.length)return fin(true);var c=segs[i];
      whenReady(vv,c.url,function(){if(!exp)return;vv.onseeked=function(){if(Math.abs(vv.currentTime-c.in)>0.6)return;vv.onseeked=null;if(!exp)return;if(!started){mr.start(1000);started=true;}else try{mr.resume();}catch(e){}
          vv.play().then(watch).catch(function(){toast("تعذّر تشغيل أحد المقاطع.");fin(false);});};vv.currentTime=c.in;});
      function watch(){(function chk(){if(!exp)return;if(exp.cancel){fin(false);return;}var p=(done+Math.max(0,vv.currentTime-c.in))/T;bar.style.width=Math.min(100,p*100)+"%";pct.textContent=an(Math.round(Math.min(1,p)*100))+"٪";
          if(vv.currentTime>=c.out-0.03||vv.ended){vv.pause();try{mr.pause();}catch(e){}done+=c.out-c.in;i++;seg();return;}setTimeout(chk,20);})();}}
    seg();}
  var rt;function rs(){clearTimeout(rt);rt=setTimeout(resize,80);}window.addEventListener("resize",rs);
  WINX.on();setTool(cfg.pen==="las"?"pen":"pen");resize();el.querySelector(".wb-zv").textContent="100%";
}
window.WB={open:openWB};
/* ================= عرض الكتاب: تقليب الصفحات، والإجابة تظهر في مكانها عند الضغط ================= */
/* شكل البيانات: {id,title,base,w,h,pages:[{n:رقم الصفحة,src:"p54.jpg",items:[
     {r:[x,y,w,h], t:"الإجابة", q:[x,y,w,h]}   ← مربع إجابة (والسؤال اختياري: الضغط عليه يُظهر الإجابة)
     {k:"b", q:[x,y,w,h], t:"الإجابة"}         ← سؤال شفهي: تظهر الإجابة في فقاعة تحته
     {k:"o", r:[x,y,w,h], ok:true|false}         ← خيار يُضغط عليه (صح/خطأ)
   ]}]}  — كل الإحداثيات نِسَب مئوية من عرض الصفحة وارتفاعها */
var BKI={next:'<path d="m15 6-6 6 6 6"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
 spot:'<rect x="3" y="7" width="18" height="10" rx="2" stroke-dasharray="3 2"/>',zin:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4M11 8v6M8 11h6"/>',zout:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4M8 11h6"/>',
 x:'<path d="M6 6l12 12M18 6 6 18"/>',fs:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>'};
function bki(n){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'+BKI[n]+'</svg>';}
function openBook(B,title,startN){
  if(!B||!B.pages||!B.pages.length)return;
  var EDIT=/bkedit/.test(location.hash+location.search);try{if(localStorage.getItem("bk:edit")==="1")EDIT=true;}catch(e){}
  var pages=B.pages,ekey="bk:edit:"+(B.id||"x");
  if(EDIT){try{var sv=JSON.parse(localStorage.getItem(ekey)||"null");if(sv&&sv.length===pages.length)pages=sv;}catch(e){}pages=JSON.parse(JSON.stringify(pages));}
  var N=pages.length,el=document.createElement("div");el.id="bk";el.setAttribute("role","dialog");el.setAttribute("aria-label","عرض الكتاب");
  el.innerHTML='<div class="bk-top"><button class="bk-b" data-a="x" aria-label="إغلاق">'+bki("x")+'</button><div class="bk-ttl">📖 '+esc(title||B.title||"عرض الكتاب")+'</div>'+
    '<span class="bk-pn"></span><button class="bk-b" data-a="hint" title="إظهار أماكن الإجابات">'+bki("spot")+'<span class="tx">أماكن الإجابات</span></button>'+
    '<button class="bk-b" data-a="all" title="إظهار كل الإجابات">'+bki("eye")+'<span class="tx">كل الإجابات</span></button>'+
    '<button class="bk-b" data-a="zo" aria-label="تصغير">'+bki("zout")+'</button><button class="bk-b" data-a="zi" aria-label="تكبير">'+bki("zin")+'</button>'+
    (window.AFSET?'<button class="bk-b bk-afs" data-a="font" title="نوع خط الإجابات">أأ<span class="tx">الخط</span></button>':'')+
    (window.FLIPV?'<button class="bk-b" data-a="flip" title="تقليب واقعي للصفحات مع صوت الورق">📖<span class="tx">تقليب واقعي</span></button>':'')+
    (EDIT?'<button class="bk-b" data-a="exp" style="background:#f97316">نسخ البيانات</button>':'')+'</div>'+
    '<div class="bk-view"><div class="bk-zoom"><div class="bk-book"></div></div><button class="bk-nav bk-next" data-a="next" aria-label="الصفحة التالية">‹</button><button class="bk-nav bk-prev" data-a="prev" aria-label="الصفحة السابقة">›</button></div>'+
    '<div class="bk-bot"><input type="range" min="0" step="1" value="0" aria-label="الانتقال إلى صفحة"><span class="bk-tip">اضغط على السؤال أو الفراغ لتظهر الإجابة • استخدم الأسهم للتقليب</span></div>';
  document.body.appendChild(el);if(typeof lock==="function")lock(true);
  var book=el.querySelector(".bk-book"),zoomBox=el.querySelector(".bk-zoom"),rng=el.querySelector(".bk-bot input"),view=el.querySelector(".bk-view");
  var idx=0,spread=false,pw=0,ph=0,Z=1,anim=false,rev={},showAll=false,AP=null,sub=null;
  if(startN!=null)for(var s0=0;s0<N;s0++)if(pages[s0].n==startN){idx=s0;break;}
  var base=B.base||"",ar=(B.w||1000)/(B.h||1414);
  function src(p){return /^(https?:|data:|\/)/.test(p.src)?p.src:base+p.src;}
  function key(pi,ii){return pi+":"+ii;}
  if(!EDIT&&window.BOOKANS)BOOKANS.load(B).then(function(ch){if(ch&&document.body.contains(el))render();});
  var OVR={};if(!EDIT&&window.CUST)(window.STP&&STP.ready?STP.ready:Promise.resolve()).then(function(){if(!CUST.ok())return;
    CUST.get("bk:"+String(B.id||"").replace(/[^a-zA-Z0-9:_\-.]/g,"")).then(function(v){if(v&&typeof v==="object"&&document.body.contains(el)){OVR=v;render();}});});
  function pct(r){return "right:"+(100-r[0]-r[2])+"%;top:"+r[1]+"%;width:"+r[2]+"%;height:"+r[3]+"%";}
  function pageHTML(pi){if(pi<0||pi>=N)return '<div class="bk-pg blank"></div>';var P=pages[pi],h='<div class="bk-pg" data-pi="'+pi+'"><img src="'+esc(src(P))+'" alt="صفحة '+(P.n||pi+1)+'" draggable="false" decoding="async" fetchpriority="high">';
    (P.items||[]).forEach(function(it,ii){var k=key(pi,ii),on=rev[k]!==undefined?!!rev[k]:showAll,T=OVR[k]!==undefined?OVR[k]:it.t;
      if(it.k==="o"){h+='<div class="bk-o'+(rev[k]==="g"?' good':rev[k]==="b"?' bad':'')+'" data-k="'+k+'" style="'+pct(it.r)+'"></div>';return;}
      if(it.k==="b"){var side=it.q[0]>24,bs=side?"right:"+(100-it.q[0]+1.2)+"%;top:"+(it.q[1]-.4)+"%;max-width:"+(it.q[0]-4)+"%":"right:"+(100-it.q[0]-it.q[2])+"%;top:"+(it.q[1]+it.q[3]+.6)+"%";
        h+='<div class="bk-q" data-k="'+k+'" style="'+pct(it.q)+'"></div><div class="bk-bub'+(on?' on':'')+(side?' side':'')+'" data-k="'+k+'" style="'+bs+'">'+esc(T)+'</div>';return;}
      if(it.q)h+='<div class="bk-q" data-k="'+k+'" style="'+pct(it.q)+'"></div>';
      var mk=/^[√✓×✗xX]$/.test(T);h+='<div class="bk-a'+(on?' on':'')+(mk?' mark'+(/[×✗xX]/.test(T)?' x':''):'')+'" data-k="'+k+'" style="'+pct(it.r)+'"><span>'+esc(T)+'</span></div>';});
    var DT=window.BOOK_DATES&&BOOK_DATES[B.id]&&BOOK_DATES[B.id][String(P.src).split("/").pop()];
    if(DT&&window.BKDATE)DT.forEach(function(d){h+='<div class="bk-dt fitme t-'+d[0]+'" style="'+pct(d.slice(1))+'"><span>'+esc(BKDATE(d[0]))+'</span></div>';});
    return h+'</div>';}
  /* تكبير النص ليملأ الفراغ ثم تصغيره حتى يتّسع */
  function fit(scope){(scope||book).querySelectorAll(".bk-a.on span,.bk-a.fitme span,.bk-dt span").forEach(function(sp){var bx=sp.parentNode,h=bx.clientHeight,w=bx.clientWidth;if(!h||!w)return;
      var f=Math.min(h*.7,w*.5),g=0;sp.style.fontSize=f+"px";while((sp.scrollWidth>w+1||sp.scrollHeight>h+1)&&f>6&&g++<40){f*=.92;sp.style.fontSize=f+"px";}});
    (scope||book).querySelectorAll(".bk-bub").forEach(function(b){b.style.fontSize=Math.max(11,ph*.019)+"px";});}
  function layout(){var vw=view.clientWidth-(window.innerWidth<=700?12:128),vh=view.clientHeight-20;spread=vw/vh>ar*1.55&&vw>=640;
    if(spread){ph=Math.min(vh,vw/2/ar);pw=ph*ar;}else{pw=Math.min(vw,vh*ar);ph=pw/ar;}pw=Math.floor(pw*Z);ph=Math.floor(ph*Z);
    if(spread&&idx%2)idx--;book.style.width=(spread?pw*2:pw)+"px";book.style.height=ph+"px";book.classList.toggle("spread",spread);el.classList.toggle("zoomed",Z>1);
    rng.max=spread?Math.ceil(N/2)-1:N-1;}
  function half(cls,pi){var d=document.createElement("div");d.className="bk-half "+cls;d.style.width=pw+"px";d.innerHTML=pageHTML(pi);return d;}
  function render(){book.innerHTML="";if(spread){book.appendChild(half("R",idx));book.appendChild(half("L",idx+1));}else book.appendChild(half("S",idx));
    var a=pages[idx],b=spread?pages[idx+1]:null;el.querySelector(".bk-pn").textContent="صفحة "+an(a.n||idx+1)+(b?" – "+an(b.n||idx+2):"")+"  ("+an(idx+1)+" من "+an(N)+")";
    rng.value=spread?idx/2:idx;el.querySelector('[data-a="next"]').disabled=idx+(spread?2:1)>=N;el.querySelector('[data-a="prev"]').disabled=idx<=0;
    requestAnimationFrame(function(){fit();});preload();}
  /* تحميل الصفحات مسبقًا بطابور هادئ (صفحتان معًا) مع إعادة المحاولة عند الفشل، ليكون التقليب فوريًّا */
  var IMC={},QUE=[],busy=0;
  function load(i){if(i<0||i>=N)return Promise.resolve();if(IMC[i])return IMC[i].p;var o={};o.p=new Promise(function(res){var im=new Image(),tries=0;im.decoding="async";
      function go(){im.src=src(pages[i])+(tries?(pages[i].src.indexOf("?")<0?"?r=":"&r=")+tries:"");}
      im.onload=function(){o.ok=true;(im.decode?im.decode():Promise.resolve()).catch(function(){}).then(res);};
      im.onerror=function(){if(++tries<3)setTimeout(go,600*tries);else res();};go();o.im=im;});IMC[i]=o;return o.p;}
  function pump(){while(busy<2&&QUE.length){var i=QUE.shift();if(IMC[i])continue;busy++;load(i).then(function(){busy--;pump();});}}
  function preload(){var st=spread?2:1,want=[];for(var k=0;k<6;k++)want.push(idx+st+k);want.push(idx-1,idx-2,idx-3,idx-4);
    QUE=want.filter(function(i){return i>=0&&i<N&&!IMC[i];});pump();}
  function ready(list,ms){return Promise.race([Promise.all(list.map(load)),new Promise(function(r){setTimeout(r,ms||1500);})]);}
  function turn(dir){if(anim)return;var st=spread?2:1,ni=idx+dir*st;if(ni<0||ni>=N)return;
    var need=[ni,ni+1,idx,idx+1].filter(function(i){return i>=0&&i<N;});
    if(!need.every(function(i){return IMC[i]&&IMC[i].ok;})){anim=true;el.classList.add("bk-wait");ready(need,1800).then(function(){el.classList.remove("bk-wait");anim=false;turn2(dir);});return;}
    turn2(dir);}
  function turn2(dir){if(anim)return;var st=spread?2:1,ni=idx+dir*st;if(ni<0||ni>=N)return;
    var red=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;if(red){idx=ni;render();return;}
    anim=true;if(typeof tone==="function")try{tone([[300,0,.05,"sine"],[240,.05,.08,"sine"]]);}catch(e){}
    var leaf=document.createElement("div");leaf.className="bk-leaf";leaf.style.width=pw+"px";
    function face(c,pi){return '<div class="bk-face '+c+'">'+pageHTML(pi)+'</div>';}
    var from,to;
    if(spread){book.innerHTML="";
      if(dir>0){book.appendChild(half("R",idx));book.appendChild(half("L",ni+1));leaf.style.left="0";leaf.style.transformOrigin="right center";leaf.innerHTML=face("f",idx+1)+face("b",ni);from="rotateY(0deg)";to="rotateY(180deg)";}
      else{book.appendChild(half("R",ni));book.appendChild(half("L",idx+1));leaf.style.right="0";leaf.style.transformOrigin="left center";leaf.innerHTML=face("f",idx)+face("b",ni+1);from="rotateY(0deg)";to="rotateY(-180deg)";}}
    else{book.innerHTML="";leaf.style.right="0";leaf.style.transformOrigin="right center";
      if(dir>0){book.appendChild(half("S",ni));leaf.innerHTML=face("f",idx)+face("b",-1);from="rotateY(0deg)";to="rotateY(165deg)";}
      else{book.appendChild(half("S",idx));leaf.innerHTML=face("f",ni)+face("b",-1);from="rotateY(165deg)";to="rotateY(0deg)";}}
    leaf.style.transition="none";leaf.style.transform=from;book.appendChild(leaf);fit(leaf);void leaf.offsetWidth;leaf.style.transition="";
    requestAnimationFrame(function(){leaf.style.transform=to;if(!spread&&dir>0)leaf.style.opacity="0.2";if(!spread&&dir<0){leaf.style.opacity="1";}});
    var done=false;function end(){if(done)return;done=true;idx=ni;anim=false;render();}
    leaf.addEventListener("transitionend",end);setTimeout(end,900);}
  /* الضغط على الأسئلة والفراغات */
  book.addEventListener("click",function(e){if(EDIT&&edited){edited=false;return;}var t=e.target.closest("[data-k]");if(!t||anim)return;var k=t.getAttribute("data-k"),p=k.split(":"),it=pages[+p[0]].items[+p[1]];
    if(it.k==="o"){if(rev[k]==="g")return;if(it.ok){rev[k]="g";t.classList.add("good");snd(true);}else{t.classList.remove("bad");rev[k]="b";void t.offsetWidth;t.classList.add("bad");snd(false);}return;}
    var was=rev[k]!==undefined?!!rev[k]:showAll;rev[k]=!was;
    book.querySelectorAll('[data-k="'+k+'"]').forEach(function(x){if(x.classList.contains("bk-a")||x.classList.contains("bk-bub"))x.classList.toggle("on",!!rev[k]);});
    if(rev[k]){snd(true,1);fit();}});
  function snd(ok,soft){if(typeof tone!=="function")return;try{tone(ok?(soft?[[660,0,.06,"triangle"],[880,.06,.1,"triangle"]]:[[523,0,.08,"triangle"],[659,.08,.08,"triangle"],[784,.16,.14,"triangle"]]):[[220,0,.12,"sawtooth"],[180,.1,.16,"sawtooth"]]);}catch(e){}}
  /* السحب للتقليب: لليمين = الصفحة التالية (كتاب عربي) */
  var sx=null,sy=0;view.addEventListener("pointerdown",function(e){if(e.target.closest(".bk-nav"))return;sx=e.clientX;sy=e.clientY;});
  view.addEventListener("pointerup",function(e){var tch=false;try{tch=localStorage.getItem("flip:touch")==="1";}catch(_){}if(sx===null||Z>1||EDIT||!tch){sx=null;return;}var dx=e.clientX-sx,dy=e.clientY-sy;sx=null;if(Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.3)turn(dx>0?1:-1);});
  var rt=null;rng.addEventListener("input",function(){var v=+rng.value,ni=spread?v*2:v,a=pages[ni];el.querySelector(".bk-pn").textContent="صفحة "+an(a?(a.n||ni+1):"");
    clearTimeout(rt);rt=setTimeout(function(){idx=ni;render();},160);});
  /* إعادة تحميل صورة الصفحة إذا تعذّر ظهورها */
  book.addEventListener("error",function(e){var im=e.target;if(!im||im.tagName!=="IMG")return;var n=+(im.getAttribute("data-r")||0);if(n>=3)return;im.setAttribute("data-r",n+1);
    setTimeout(function(){var s0=im.src.replace(/[?&]r=\d+$/,"");im.src=s0+(s0.indexOf("?")<0?"?r=":"&r=")+(n+1);},500*(n+1));},true);
  function setZ(z){Z=Math.max(1,Math.min(3,z));layout();render();}
  el.addEventListener("click",function(e){var b=e.target.closest("[data-a]");if(!b)return;var a=b.getAttribute("data-a");
    if(a==="x")return close();if(a==="next")turn(1);if(a==="prev")turn(-1);
    if(a==="hint"){var on=el.classList.toggle("hint");b.classList.toggle("on",on);}
    if(a==="all"){showAll=!showAll;rev={};b.classList.toggle("on",showAll);b.querySelector(".tx").textContent=showAll?"إخفاء الإجابات":"كل الإجابات";render();}
    if(a==="zi")setZ(Z+.5);if(a==="zo")setZ(Z-.5);
    if(a==="font"&&AP){e.stopPropagation();AP.toggle();}
    if(a==="flip"&&window.FLIPV){var pg_=B.pages[idx];FLIPV.open(B,title,pg_?pg_.n:null);}
    if(a==="exp")exportData();});
  if(window.AFSET){AP=AFSET.panel(el,el.querySelector(".bk-afs"));sub=function(){AFSET.applyTo(el);setTimeout(function(){fit();},60);};AFSET.on(sub);}
  function kd(e){if(e.key==="Escape"){if(AP&&!AP.el.hidden)return AP.show(false);close();}else if(e.key==="ArrowLeft"){e.preventDefault();turn(1);}else if(e.key==="ArrowRight"){e.preventDefault();turn(-1);}}
  document.addEventListener("keydown",kd);
  var rt;function rs(){clearTimeout(rt);rt=setTimeout(function(){layout();render();},120);}window.addEventListener("resize",rs);
  function close(){window.removeEventListener("resize",rs);document.removeEventListener("keydown",kd);if(sub)AFSET.off(sub);el.remove();if(typeof lock==="function")lock(false);}
  /* ---------- وضع التحرير (لإضافة مربعات الإجابات للكتب): يُفعَّل بإضافة ‎#bkedit‎ لرابط الصفحة ---------- */
  var edited=false;
  if(EDIT){el.classList.add("editing");var dr=null,box=null;
    book.addEventListener("pointerdown",function(e){var pg=e.target.closest(".bk-pg[data-pi]");if(!pg||e.button===2)return;var r=pg.getBoundingClientRect();dr={pg:pg,r:r,x:e.clientX,y:e.clientY};
      box=document.createElement("div");box.className="bk-edit";pg.appendChild(box);e.preventDefault();});
    window.addEventListener("pointermove",function(e){if(!dr)return;var r=dr.r,x0=Math.min(dr.x,e.clientX),y0=Math.min(dr.y,e.clientY),w=Math.abs(e.clientX-dr.x),h=Math.abs(e.clientY-dr.y);
      box.style.cssText="left:"+((x0-r.left)/r.width*100)+"%;top:"+((y0-r.top)/r.height*100)+"%;width:"+(w/r.width*100)+"%;height:"+(h/r.height*100)+"%";});
    window.addEventListener("pointerup",function(e){if(!dr)return;var d=dr;dr=null;var r=d.r,w=Math.abs(e.clientX-d.x),h=Math.abs(e.clientY-d.y);box.remove();if(w<8||h<6)return;edited=true;
      var R=[+(((Math.min(d.x,e.clientX)-r.left)/r.width)*100).toFixed(1),+(((Math.min(d.y,e.clientY)-r.top)/r.height)*100).toFixed(1),+(w/r.width*100).toFixed(1),+(h/r.height*100).toFixed(1)];
      var v=prompt("اكتب الإجابة لهذا المربع.\n• اكتب: صح  أو  خطأ  لخيار يُضغط عليه.\n• ابدأ بـ * لسؤال شفهي تظهر إجابته في فقاعة (المربع = السؤال).\n• ابدأ بـ ؟ لتجعل المربع منطقةَ سؤالٍ لآخر مربع إجابة.");if(v===null||!v.trim())return;v=v.trim();
      var P=pages[+d.pg.getAttribute("data-pi")];P.items=P.items||[];
      if(v==="صح"||v==="خطأ")P.items.push({k:"o",r:R,ok:v==="صح"});
      else if(v[0]==="*")P.items.push({k:"b",q:R,t:v.slice(1).trim()});
      else if(v[0]==="؟"&&P.items.length){P.items[P.items.length-1].q=R;}
      else P.items.push({r:R,t:v});
      try{localStorage.setItem(ekey,JSON.stringify(pages));}catch(_){}render();});
    book.addEventListener("contextmenu",function(e){var t=e.target.closest("[data-k]");if(!t)return;e.preventDefault();var p=t.getAttribute("data-k").split(":");
      if(confirm("حذف هذا المربع؟")){pages[+p[0]].items.splice(+p[1],1);try{localStorage.setItem(ekey,JSON.stringify(pages));}catch(_){}render();}});}
  function exportData(){var o=document.createElement("div");o.className="bk-out";var data=JSON.stringify(pages.map(function(p){return {n:p.n,src:p.src,items:p.items||[]};}));
    o.innerHTML='<b>انسخ البيانات وأرسلها لإضافتها إلى الموقع:</b><textarea readonly></textarea><div style="display:flex;gap:8px"><button class="bk-b" style="background:#3b4fc4" data-c>نسخ</button><button class="bk-b" style="background:#64748b" data-z>إغلاق</button><button class="bk-b" style="background:#dc2626" data-r>مسح التعديلات المحفوظة</button></div>';
    o.querySelector("textarea").value=data;el.appendChild(o);
    o.querySelector("[data-c]").onclick=function(){var t=o.querySelector("textarea");t.select();try{navigator.clipboard.writeText(t.value);}catch(e){document.execCommand("copy");}};
    o.querySelector("[data-z]").onclick=function(){o.remove();};o.querySelector("[data-r]").onclick=function(){if(confirm("مسح كل المربعات المحفوظة على هذا الجهاز لهذا الكتاب؟")){try{localStorage.removeItem(ekey);}catch(e){}o.remove();}};}
  layout();render();
  if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){if(document.body.contains(el))fit();});
}
/* عدة كتب للدرس الواحد: نافذة لاختيار الكتاب */
/* كل الكتب تُفتح بالتقليب الواقعي (مع الإجابات التفاعلية)، والعرض الكلاسيكي متاح من زر داخلها أو في وضع التحرير */
function openPref(B,title,n){var ed=/bkedit/.test(location.hash+location.search);try{if(localStorage.getItem("bk:edit")==="1")ed=true;}catch(e){}
  if(window.FLIPV&&!ed)return FLIPV.open(B,title,n);return openBook(B,title,n);}
function openBooks(list,title,starts){if(!Array.isArray(list))return openPref(list,title,typeof starts==="object"&&starts?starts[list.id]:starts);
  list=list.filter(function(b){return b&&b.pages&&b.pages.length;});var MAIN=starts&&starts._main;
  if(MAIN)list=list.slice().sort(function(a,b){return (b.id===MAIN)-(a.id===MAIN);});
  if(list.length===1)return openPref(list[0],title,starts&&starts[list[0].id]);
  var el=document.createElement("div");el.id="bkc";el.setAttribute("role","dialog");el.setAttribute("aria-label","اختر الكتاب");
  el.innerHTML='<div class="bkc-box"><div class="bkc-h"><b>📚 اختر الكتاب</b><button type="button" data-x aria-label="إغلاق">✕</button></div><div class="bkc-grid">'+list.map(function(b,i){var c=b.pages[0];
    return '<button type="button" class="bkc-b'+(b.id===MAIN?' main':'')+'" data-i="'+i+'">'+(b.id===MAIN?'<em>📌 كتاب هذا الدرس</em>':'')+'<img src="'+esc((b.base||"")+c.src)+'" alt="" loading="lazy"><span>'+esc(b.title)+'</span>'+(starts&&starts[b.id]!=null?'<small>يفتح على صفحة '+an(starts[b.id])+'</small>':'')+'</button>';}).join("")+'</div></div>';
  document.body.appendChild(el);if(typeof lock==="function")lock(true);
  function close(){el.remove();document.removeEventListener("keydown",kd);if(typeof lock==="function")lock(false);}
  function kd(e){if(e.key==="Escape")close();}document.addEventListener("keydown",kd);
  el.addEventListener("click",function(e){if(e.target===el||e.target.closest("[data-x]"))return close();var b=e.target.closest("[data-i]");if(!b)return;var B=list[+b.getAttribute("data-i")];close();openPref(B,B.title,starts&&starts[B.id]);});}
window.BOOKV={open:openBooks,one:openBook};
})();
